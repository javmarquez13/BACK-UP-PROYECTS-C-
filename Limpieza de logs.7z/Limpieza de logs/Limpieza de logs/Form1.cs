﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using iFactoryInfo.SQL;
using System.Diagnostics;
using System.Text.RegularExpressions;

namespace Limpieza_de_logs
{
    public partial class Form1 : Form
    {

        iFactoryInfo.iFactoryInfo _iFactoryInfo = new iFactoryInfo.iFactoryInfo();

        public Form1()
        {
            InitializeComponent();
            InicializarDGV();
            FillComboBox();
        }


        int _totalFiles = 1;

        void InicializarDGV()
        {
            dgvTests.Columns.Add("Count", "Count");
            dgvTests.Columns.Add("Tracer", "Tracer");
            dgvTests.Columns.Add("Process", "Process");
            dgvTests.Columns["Count"].Width = 30;
            dgvTests.Columns["Tracer"].Width = 150;
            dgvTests.Columns["PRocess"].Width = 250;

            dgvTests.RowHeadersVisible = false;
        }

        void WriteDGV(int count,string Tracer, string Process)
        {
            dgvTests.Rows.Add(new Object[]
                   {
                          count, Tracer, Process
                   });
            dgvTests.Rows[dgvTests.Rows.Count - 1].DefaultCellStyle.BackColor = Color.LightGreen;
            dgvTests.CurrentCell = dgvTests.Rows[dgvTests.Rows.Count - 1].Cells[0];
            this.Update();         
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            dgvTests.Rows.Clear();
            GetAllFiles();
        }

        void GetAllFiles()
        {
            string _path = comboBox1.Text;
            DirectoryInfo _dirInfo = new DirectoryInfo(_path);
            FileInfo[] _files = _dirInfo.GetFiles("*.ejl");
            int _countFiles = 1;

            foreach(FileInfo _file in _files)
            {
                if(_file.CreationTime < DateTime.Now)
                {                  
                    string _tracer = _file.Name.Substring(0, 8);
                    string[] _infoUnit = _iFactoryInfo.GetSCMC(_tracer);
                    DataSet _ds = _iFactoryInfo.GetHistory(_infoUnit[0]);

                    DataTable _dt = _ds.Tables[0];
                    int _dataRows = 0;
                    int _loops = 1;

                    _dataRows = _dt.Rows.Count;
                    _dataRows--;

                    while (_loops <= _dataRows)
                    {
                        var varArrivalTime = _dt.Rows[_loops]["ArrivalTime"];
                        var varProcessName = _dt.Rows[_loops]["ProcessName"];
                        var varProcessResult = _dt.Rows[_loops]["ProcessResult"];

                        if (varProcessName.Equals("SHIPPING"))
                        {
                            WriteDGV(_countFiles, _tracer, varProcessName.ToString());
                            _totalFiles++;
                            lblTotalFiles.Text = "Total Files: " + _totalFiles.ToString();
                            break;
                        }

                        _loops++;
                    }
                
                    this.Refresh();
                    _countFiles++;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ProcessStartInfo _proc = new ProcessStartInfo();
            _proc.Arguments = NewScripts + comboBox2.Text + " " + OldScripts;
            _proc.FileName = @"C:\Program Files\WinMerge\WinMergeU.exe";
            //_proc.FileName = @"C:\Program Files (x86)\Notepad++\notepad++.exe";

            using (Process exeProcess = Process.Start(_proc))
            {
                //System.Threading.Thread.Sleep(500);
                //_proc.Arguments = OldScripts + comboBox2.Text;
                //exeProcess.Start();
            }
        }


        string NewScripts = @"\\mxchim0pangea01\diskbld\NewPangea1.9.4\Miguel Derma\custome\TestScript\";
        string OldScripts = @"C:\Trunk\PangaeaFinancial_UAT\PangaeaFinancial\GUI\CustomScripts\TestScripts\";
        string OKScritps = @"\\mxchim0pangea01\diskbld\NewPangea1.9.4\Miguel Derma\custome\TestScript\!OK";


        void FillComboBox()
        {                  
            DirectoryInfo _dirInfo = new DirectoryInfo(NewScripts);         
            FileInfo[] _files = _dirInfo.GetFiles("*.cs").OrderBy(x => x.Name).ToArray();

            foreach (FileInfo _scriptNew in _files)
            {
                comboBox2.Items.Add(_scriptNew.Name);
            }
        }

        private void comboBox2_MouseClick(object sender, MouseEventArgs e)
        {
            comboBox2.Items.Clear();
            FillComboBox();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            File.Move(NewScripts + comboBox2.Text, OKScritps + comboBox2.Text);
            comboBox2.Items.Clear();
            FillComboBox();
        }
    }
}
