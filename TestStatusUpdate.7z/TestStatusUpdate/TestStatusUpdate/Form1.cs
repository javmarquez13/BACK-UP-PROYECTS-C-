﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using iFactoryInfo;


namespace TestStatusUpdate
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            

            if (Directory.Exists(@"C:\PangaeaLTOSwitcher\"))
            {
                _Plataforma = "ATM";
                timerATM.Start();
            }
            else
            {
                _Plataforma = "SSCO";
                timer.Start();
            }
        }

        IniFiles IniFiles = new IniFiles();
        ReportingSem reportingSem = new ReportingSem();
        iFactoryInfo.iFactoryInfo IFactoryInfo = new iFactoryInfo.iFactoryInfo();

        string _Plataforma;

        int TD_7350R6Lite = 28;
        int TD_7358R6;


        string _TRACER;
        string _CLASSMC;
        string _SlotInfo;
        string _OperatorInfo;
        string _PROGRESS;
        string[] _info;


        void ReadEJL()
        {
            DirectoryInfo _dirInfo = new DirectoryInfo(@"C:\Mavis\");
            FileInfo[] _filesInfo = _dirInfo.GetFiles("*.ejl");

            if (_filesInfo.Length <= 0) return;

            List<string> _TestProgress = new List<string>();
            List<string> _TestProgressCopy = new List<string>();
            string[] _TestProgressArr = { "" };
            string[] _TestProgressArrCopy = { "" };
            string _File = _filesInfo[0].FullName;
            string _FileCopy = string.Empty;
            string _FileText = "";

            //if (CheckIsBusy(_filesInfo[0].FullName)) return;

            if (!Directory.Exists(@"C:\JABIL\MavisEJL\MasterCopy\"))
            {
                Directory.CreateDirectory(@"C:\JABIL\MavisEJL\MasterCopy\");
            }


            ///////////////////////////////// File copy ///////////////////////////////////////////
            var inStream = new FileStream(_filesInfo[0].FullName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);

            using (StreamReader reader = new StreamReader(inStream))
            {
                _FileText = reader.ReadToEnd();
                reader.Close();
                inStream.Dispose();
                inStream.Close();
            }

            using (StreamWriter sw = File.CreateText(@"C:\JABIL\MavisEJL\MasterCopy\" + _filesInfo[0].Name))
            {
                sw.WriteLine(_FileText);   
                sw.Close();
            }
            ///////////////////////////////////////////////////////////////////////////////////////

            _dirInfo = new DirectoryInfo(@"C:\JABIL\MavisEJL\MasterCopy\");
            _filesInfo = _dirInfo.GetFiles("*.ejl");

            string[] EjlText = File.ReadAllLines(_filesInfo[0].FullName);


            if (!File.Exists(@"C:\Jabil\MavisEJL\" + _filesInfo[0].Name))
            {
                File.Copy(_filesInfo[0].FullName, @"C:\Jabil\MavisEjl\" + _filesInfo[0].Name, true);
            }

            _dirInfo = new DirectoryInfo(@"C:\JABIL\MavisEJL\");
            _filesInfo = _dirInfo.GetFiles("*.ejl");
            string[] EjlTextCopy = File.ReadAllLines(_filesInfo[0].FullName);
            _FileCopy = _filesInfo[0].Name;

            if (EjlText.Length != EjlTextCopy.Length)
            {
                foreach (string _line in EjlText)
                {
                    if (_line.Contains("TABLE -"))
                    {
                        _TestProgress.Add(_line);
                    }
                }

                foreach (string _line in EjlTextCopy)
                {
                    if (_line.Contains("TABLE -"))
                    {
                        _TestProgressCopy.Add(_line);
                    }
                }

                _TestProgressArr = _TestProgress.ToArray();
                _TestProgressArrCopy = _TestProgressCopy.ToArray();
                _PROGRESS = GetProgress(_TestProgressArr.Length);


                if (_TestProgressArr.Length != _TestProgressArrCopy.Length)
                {
                    int indice = _TestProgressArr.Length - 1;

                    string status = _TestProgressArr[indice];

                    _info = GetTracerInfo();
                    _CLASSMC = _info[1] + "MC" + _info[2];
                    _SlotInfo = GetSlotInfo();
                    _OperatorInfo = GetOperatorInfo();
                    ReportingSemaphore(string.Empty,_OperatorInfo, _TRACER, _CLASSMC, _SlotInfo, "", status, "YELLOW",_PROGRESS);
                    lblStep.Text = "TEST STEP: " + status;
                    File.Copy(_File, @"C:\Jabil\MavisEjl\" + _FileCopy, true);
                }
            }
        }


        void CopyBusyFile(string yourlockedfile, string destination)
        {
            System.Diagnostics.Process _proc = new System.Diagnostics.Process();
            _proc.StartInfo.UseShellExecute = false;
            _proc.StartInfo.RedirectStandardOutput = true;
            _proc.StartInfo.FileName = "cmd.exe";
            _proc.StartInfo.Arguments = "/C copy \"" + yourlockedfile + "\" \"" + destination + "\"";
            _proc.Start();
            _proc.WaitForExit();
            _proc.Close();
        }

        string GetProgress(int CountTests)
        {
            int TotalTests = 0;
            int progress = 0;

            if(CountTests < 80)
            {
                progress = CountTests * 90 / 33;
            }
            if (CountTests >= 80)
            {
                progress = CountTests * 90 / 115;
            }

            return progress + "%";
        }

        string[] GetTracerInfo()
        {
            DirectoryInfo _dirInfo = new DirectoryInfo(@"C:\JABIL\UnitInfo\");
            FileInfo[] _filesInfo = _dirInfo.GetFiles();
            string[] _unitInfo = File.ReadAllLines(_filesInfo[0].FullName);
            _TRACER = _unitInfo[0];
            _unitInfo = IFactoryInfo.GetSCMC(_unitInfo[0]);

            return _unitInfo;
        }

        string GetSlotInfo()
        {
            DirectoryInfo _dirInfo = new DirectoryInfo(@"C:\JABIL\UnitInfo\");
            FileInfo[] _filesInfo = _dirInfo.GetFiles();
            string[] _unitInfo = File.ReadAllLines(_filesInfo[0].FullName);
            return _unitInfo[3];
        }

        string GetOperatorInfo()
        {
            DirectoryInfo _dirInfo = new DirectoryInfo(@"C:\JABIL\UnitInfo\");
            FileInfo[] _filesInfo = _dirInfo.GetFiles();
            string[] _unitInfo = File.ReadAllLines(_filesInfo[0].FullName);
            return _unitInfo[1] + "-" + _unitInfo[2];
        }

        void ReportingSemaphore(string START_TIME,string OPERATOR, string TRACER, string CLASSMC, string SlotID, string IpAdress, string STATUS, string COLOR, string PROGRESS)
        {
            reportingSem.XMLSSCO();
            reportingSem.CreateXML(START_TIME, OPERATOR, TRACER, CLASSMC, SlotID, IpAdress, STATUS, COLOR, PROGRESS);
        }

        bool CheckIsBusy(string FilePathName) //function to validate if the file is busy for another process
        {
            FileStream fileStream = null;
            FileInfo fileInfo = new FileInfo(FilePathName);

            try
            {
                fileStream = fileInfo.Open(FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            }
            catch (Exception ex)
            {
                return true;
            }
            finally
            {
                if (fileStream != null)
                {
                    fileStream.Close();
                }
            }
            return false;
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            try
            {
                ReadEJL();
            }

            catch (Exception ex)
            {
                
            }
        }

        void HideApplication()
        {
            timer.Interval = 10000;
            timer.Start();
            this.WindowState = FormWindowState.Minimized;
            this.Visible = false;
            this.Hide();

            System.Threading.Thread.Sleep(200);

            if (this.WindowState != FormWindowState.Minimized)
            {
                this.WindowState = FormWindowState.Minimized;
                this.Visible = false;
                this.Hide();
            }
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            if(_Plataforma == "ATM" || _Plataforma == "SSCO")
            {
                this.WindowState = FormWindowState.Minimized;
                this.Visible = false;
                this.Hide();

                System.Threading.Thread.Sleep(200);

                if (this.WindowState != FormWindowState.Minimized)
                {
                    this.WindowState = FormWindowState.Minimized;
                    this.Visible = false;
                    this.Hide();
                }
            }         
        }

        bool UpdatePosition(int Slot)
        {
            string Path = @"C:\JABIL\UnitInfo\";
            string[] _UnitInfo = { };
            bool flag =false;
        
            DirectoryInfo _dirInfo = new DirectoryInfo(Path);

            if (!_dirInfo.Exists)
            {
                _dirInfo.Create();
            }

            FileInfo[] _files = _dirInfo.GetFiles();

            if(_files.Length > 0)
            {
                _UnitInfo = File.ReadAllLines(_files[0].FullName);
                _UnitInfo[3] = Slot.ToString();

                using (StreamWriter sw = File.CreateText(_files[0].FullName))
                {
                    sw.WriteLine(_UnitInfo[0]);
                    sw.WriteLine(_UnitInfo[1]);
                    sw.WriteLine(_UnitInfo[2]);
                    sw.WriteLine(_UnitInfo[3]);
                    sw.Close();               
                }

                flag = true;
            }
            return flag;
        }

        private void sscos_slot1_Click(object sender, EventArgs e)
        {
            bool flag = UpdatePosition(1);
            if (flag) HideApplication();
        }

        private void sscos_slot2_Click(object sender, EventArgs e)
        {
            bool flag = UpdatePosition(2);
            if (flag) HideApplication();
        }

        private void sscos_slot3_Click(object sender, EventArgs e)
        {
            bool flag = UpdatePosition(3);
            if (flag) HideApplication();
        }

        private void sscos_slot4_Click(object sender, EventArgs e)
        {
            bool flag = UpdatePosition(4);
            if (flag) HideApplication();
        }

        private void sscos_slot5_Click(object sender, EventArgs e)
        {
            bool flag = UpdatePosition(5);
            if (flag) HideApplication();
        }

        private void sscos_slot6_Click(object sender, EventArgs e)
        {
            bool flag = UpdatePosition(6);
            if (flag) HideApplication();
        }

        private void sscos_slot7_Click(object sender, EventArgs e)
        {
            bool flag = UpdatePosition(7);
            if (flag) HideApplication();
        }

        private void sscos_slot8_Click(object sender, EventArgs e)
        {
            bool flag = UpdatePosition(8);
            if (flag) HideApplication();
        }

        private void sscos_slot9_Click(object sender, EventArgs e)
        {
            bool flag = UpdatePosition(9);
            if (flag) HideApplication();
        }

        private void sscos_slot10_Click(object sender, EventArgs e)
        {
            bool flag = UpdatePosition(10);
            if (flag) HideApplication();
        }

        private void sscos_slot11_Click(object sender, EventArgs e)
        {
            bool flag = UpdatePosition(11);
            if (flag) HideApplication();
        }

        private void sscos_slot12_Click(object sender, EventArgs e)
        {
            bool flag = UpdatePosition(12);
            if (flag) HideApplication();
        }

        private void sscos_slot13_Click(object sender, EventArgs e)
        {
            bool flag = UpdatePosition(13);
            if (flag) HideApplication();
        }

        private void sscos_slot14_Click(object sender, EventArgs e)
        {
            bool flag = UpdatePosition(14);
            if (flag) HideApplication();
        }

        private void sscos_slot15_Click(object sender, EventArgs e)
        {
            bool flag = UpdatePosition(15);
            if (flag) HideApplication();
        }

        private void sscos_slot16_Click(object sender, EventArgs e)
        {
            bool flag = UpdatePosition(16);
            if (flag) HideApplication();
        }

        private void sscos_slot17_Click(object sender, EventArgs e)
        {
            bool flag = UpdatePosition(17);
            if (flag) HideApplication();
        }

        private void sscos_slot18_Click(object sender, EventArgs e)
        {
            bool flag = UpdatePosition(18);
            if(flag) HideApplication();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Width = tabPage1.Width;
            this.Location = new Point((Screen.PrimaryScreen.WorkingArea.Width - this.ClientSize.Width) / 2, (Screen.PrimaryScreen.WorkingArea.Height - this.ClientSize.Height) /2);

            if (_Plataforma == "ATM")
            {
                tabControl1.SelectedTab = tabPage1;
            }

            if (_Plataforma == "ATM")
            {
                tabControl1.SelectedTab = tabPage2;
            }
            //panel1.Left = (this.ClientSize.Width - panel1.Width) / 2;
            //panel1.Top = (this.ClientSize.Height - panel1.Height) / 2;
        }

        private void timerATM_Tick(object sender, EventArgs e)
        {
            if (File.Exists(@"C:\Pangaea\PangaeaFinancialLogs\TestLogs\SAFETY_ATM.log"))
            {
                timerATM.Stop();
                this.Visible = true;
                this.WindowState = FormWindowState.Normal;
                this.Show();
            }
        }

    }
}
