﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;


namespace MAP_SERVER
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            contenedor.Left = (this.ClientSize.Width - pictureBox1.Width) / 2;
            contenedor.Top = (this.ClientSize.Height - pictureBox1.Width) / 2;

            OK:
            {            
                MessageBox.Show("Remueva el usb para continuar...", "Server mapped successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //Create directory with UnitInfo.
                bool _dongle = false;

                string _dongleA = @"A:\BOOT\ETFSBOOT.COM";
                if (File.Exists(_dongleA))
                {
                    _dongle = true;
                }

                string _dongleB = @"B:\BOOT\ETFSBOOT.COM";
                if (File.Exists(_dongleB))
                {
                    _dongle = true;
                }
               
                string _dongleC = @"C:\BOOT\ETFSBOOT.COM";
                if (File.Exists(_dongleC))
                {
                    _dongle = true;
                }

                string _dongleD = @"D:\BOOT\ETFSBOOT.COM";
                if (File.Exists(_dongleD))
                {
                    _dongle = true;
                }

                string _dongleE = @"E:\BOOT\ETFSBOOT.COM";
                if (File.Exists(_dongleE))
                {
                    _dongle = true;
                }
                
                string _dongleF = @"F:\BOOT\ETFSBOOT.COM";
                if (File.Exists(_dongleF))
                {
                    _dongle = true;
                }
                
                string _dongleG = @"G:\BOOT\ETFSBOOT.COM";
                if (File.Exists(_dongleG))
                {
                    _dongle = true;
                }
                
                string _dongleH = @"H:\BOOT\ETFSBOOT.COM";
                if (File.Exists(_dongleH))
                {
                    _dongle = true;
                }
                
                string _dongleI = @"I:\BOOT\ETFSBOOT.COM";
                if (File.Exists(_dongleI))
                {
                    _dongle = true;
                }
               
                string _dongleJ = @"J:\BOOT\ETFSBOOT.COM";
                if (File.Exists(_dongleJ))
                {
                    _dongle = true;
                }

                if (_dongle)
                {
                    goto OK;
                }

                timer1.Start();
                timer2.Start();
                lblStatus.Text = "Copying files...";

                Task<int> task = new Task<int>(CopyImagesServerToX);
                task.Start();
                int response = await task;


                lblStatus.Text = "Initializing...";
                this.Refresh();

                Task<int> task1 = new Task<int>(WaitForImageServer);
                task1.Start();
                response = await task;


                ExternalExe(@"X:\ImagesServer\ImagesServer_v2.0.exe", string.Empty);
                this.Refresh();

                Task<int> task3 = new Task<int>(WaitForImageServer);
                task3.Start();
                response = await task3;
                        

                timer1.Stop();

                Environment.Exit(0);
            }
        }


        int WaitForImageServer()
        {
            System.Threading.Thread.Sleep(5000);
            return 1;
        }

        int CopyImagesServerToX()
        {
            string _from = @"\\mxchim0pangea01\AUTOMATION_SSCO\IMAGES_SERVER_2.0\Release\";
            string _to = @"X:\ImagesServer\";

            DirectoryInfo _dirInfo = new DirectoryInfo(_from);
            FileInfo[] _filesInfo = _dirInfo.GetFiles();

            try
            {
                foreach (FileInfo _file in _filesInfo)
                {
                    lblStatus.Invoke(new MethodInvoker(delegate { lblStatus.Text = "Downloading files: " + _file.Name; }));
                    //lblStatus.Text = "Downloading files: " + _file.Name;
                    //this.Refresh();
                    File.Copy(_file.FullName, _to + _file.Name, true);
                    //this.Refresh();
                    Thread.Sleep(150);
                }
            }
            catch (Exception ex)
            {

            }


            return 1;

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        int MapNewDrive(string Args)
        {
            string _NetProc = "net.exe";
            int _result = ExternalExe(_NetProc, Args);
            return _result;
        }

        //Function to initialize an external application and wait for finish process and return the exit code from external application
        int ExternalExe(string FileName, string Args)
        {
            int _result = 0;

            try
            {
                Process _process = new Process();
                _process.StartInfo.FileName = FileName;
                _process.StartInfo.Arguments = Args;
                _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                _process.Start();
                //_process.WaitForExit();
                //_result = _process.ExitCode;
            }
            catch (Exception ex)
            {

            }
          
            return _result;
        }


        int[] rainSpeeds = { 4, 6, 8, 3, 5, 6, 7, 4 };
        int loadingSpeed = 1;
        float initialPercentage = 0;

        private  void timer1_Tick(object sender, EventArgs e)
        {
            Timer1Function();
        }

        void Timer1Function()
        {
            for (int i = 0; i < 8; i++)
            {
                switch (i)
                {
                    case 0:
                        //animation for rain 1
                        pictureBox3.Location = new Point(pictureBox3.Location.X, pictureBox3.Location.Y + rainSpeeds[i]);
                        if (pictureBox3.Location.Y > panel1.Size.Height + pictureBox3.Size.Height)
                        {
                            pictureBox3.Location = new Point(pictureBox3.Location.X, 0 - pictureBox3.Size.Height);
                        }
                        break;
                    case 1:
                        //animation for rain 2
                        pictureBox4.Location = new Point(pictureBox4.Location.X, pictureBox4.Location.Y + rainSpeeds[i]);
                        if (pictureBox4.Location.Y > panel1.Size.Height + pictureBox4.Size.Height)
                        {
                            pictureBox4.Location = new Point(pictureBox4.Location.X, 0 - pictureBox4.Size.Height);
                        }
                        break;
                    case 2:
                        //animation for rain 3
                        pictureBox5.Location = new Point(pictureBox5.Location.X, pictureBox5.Location.Y + rainSpeeds[i]);
                        if (pictureBox5.Location.Y > panel1.Size.Height + pictureBox5.Size.Height)
                        {
                            pictureBox5.Location = new Point(pictureBox5.Location.X, 0 - pictureBox5.Size.Height);
                        }
                        break;
                    case 3:
                        //animation for rain 4
                        pictureBox6.Location = new Point(pictureBox6.Location.X, pictureBox6.Location.Y + rainSpeeds[i]);
                        if (pictureBox6.Location.Y > panel1.Size.Height + pictureBox6.Size.Height)
                        {
                            pictureBox6.Location = new Point(pictureBox6.Location.X, 0 - pictureBox6.Size.Height);
                        }
                        break;
                    case 4:
                        //animation for rain 5
                        pictureBox7.Location = new Point(pictureBox7.Location.X, pictureBox7.Location.Y + rainSpeeds[i]);
                        if (pictureBox7.Location.Y > panel1.Size.Height + pictureBox7.Size.Height)
                        {
                            pictureBox7.Location = new Point(pictureBox7.Location.X, 0 - pictureBox7.Size.Height);
                        }
                        break;
                    case 5:
                        //animation for rain 6
                        pictureBox8.Location = new Point(pictureBox8.Location.X, pictureBox8.Location.Y + rainSpeeds[i]);
                        if (pictureBox8.Location.Y > panel1.Size.Height + pictureBox8.Size.Height)
                        {
                            pictureBox8.Location = new Point(pictureBox8.Location.X, 0 - pictureBox8.Size.Height);
                        }
                        break;
                    case 6:
                        //animation for rain 7
                        pictureBox9.Location = new Point(pictureBox9.Location.X, pictureBox9.Location.Y + rainSpeeds[i]);
                        if (pictureBox9.Location.Y > panel1.Size.Height + pictureBox9.Size.Height)
                        {
                            pictureBox9.Location = new Point(pictureBox9.Location.X, 0 - pictureBox9.Size.Height);
                        }
                        break;
                    case 7:
                        //animation for rain 8
                        pictureBox10.Location = new Point(pictureBox10.Location.X, pictureBox10.Location.Y + rainSpeeds[i]);
                        if (pictureBox10.Location.Y > panel1.Size.Height + pictureBox10.Size.Height)
                        {
                            pictureBox10.Location = new Point(pictureBox10.Location.X, 0 - pictureBox10.Size.Height);
                        }
                        break;
                }
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            Timer2Function();
        }

        private void Timer2Function()
        {
            initialPercentage += loadingSpeed;
            float percentage = initialPercentage / pictureBox2.Height * 100;

            label1.Text = (int)percentage + " %";

            panel2.Location = new Point(panel2.Location.X, panel2.Location.Y + loadingSpeed);
            if (panel2.Location.Y > pictureBox2.Location.Y + pictureBox2.Height)
            {
                label1.Text = "100 %";
                this.timer2.Stop();
            }  
            
        }
    
    }
}
