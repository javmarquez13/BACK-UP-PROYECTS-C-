﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace NCRCheckProcess
{
    /// <summary>
    /// Interaction logic for DeskNotify.xaml
    /// </summary>
    public partial class DeskNotify : Window
    {
        double _x, _y;
        string _notification;
        SolidColorBrush _ColorOnError = new SolidColorBrush(Color.FromRgb(244, 67, 54));
        SolidColorBrush _ColorOnAlert = new SolidColorBrush(Color.FromRgb(255, 235, 59));
        SolidColorBrush _ColorOnSuccess = new SolidColorBrush(Color.FromRgb(102, 187, 106));

        public enum NotifyType
        {
            OnError,
            OnAlert,
            OnSuccess
        }
     
        public DeskNotify(double x, double y, string text, NotifyType notifyType)
        {
            InitializeComponent();
            _x = x;
            _y = y;
            _notification = text;

            if (notifyType == NotifyType.OnError) Grid.Background = _ColorOnError;
            if (notifyType == NotifyType.OnAlert) Grid.Background = _ColorOnAlert;
            if (notifyType == NotifyType.OnSuccess) Grid.Background = _ColorOnSuccess;
        }

  
        DispatcherTimer _timer = new DispatcherTimer();

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {           
            var desktopWorkingArea = System.Windows.SystemParameters.WorkArea;
            this.Left = desktopWorkingArea.Right - this.Width;
            this.Top = _y;
            lblNotify.Content = _notification;
            
            _timer.Interval = new TimeSpan(0, 0, 4);
            _timer.Tick += dispatcherTimer_Tick;
            _timer.Start();
            InvalidateVisual();
        }

        private void dispatcherTimer_Tick(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            Closing -= Window_Closing;
            e.Cancel = true;
            var anim = new DoubleAnimation(0, (Duration)TimeSpan.FromSeconds(1));
            anim.Completed += (s, _) => this.Close();
            this.BeginAnimation(UIElement.OpacityProperty, anim);
        }
    }
}
