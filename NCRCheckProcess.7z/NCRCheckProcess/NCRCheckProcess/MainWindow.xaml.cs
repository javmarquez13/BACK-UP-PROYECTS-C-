﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using iFactoryInfo;
using System.IO;
using System.Data;
using SendAttributes;
using System.Reflection;
using System.Threading;

namespace NCRCheckProcess
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// 
    /// 
    /// 26 AGOSTO 2020 
    /// PRIMERA REVISION 
    /// 1.0.0.5
    /// 
    /// 
    /// 
    /// 
    /// 
    /// 
    /// </summary>
    /// 
    public partial class MainWindow : Window
    {
        string _ver = "1.0.0.5";


        public MainWindow()
        {
            InitializeComponent();
        }

        //Variables Globales
        string _tracerOrWip;
        string _tracer;
        string _wip;
        string _class;
        bool _CQAIndicator;
        iFactoryInfo.iFactoryInfo _iFactoryInfo = new iFactoryInfo.iFactoryInfo();
        SendAttributes.SendAttributes _attrib = new SendAttributes.SendAttributes();
        SolidColorBrush _GreenMaterial = new SolidColorBrush(Color.FromRgb(220, 237, 200));
        SCO_Stations _SCO_Stations = new SCO_Stations();

        //process stations
        public object[] STATION_1 = new object[2] { "STATION 1 MAIN LINE", false };
        public object[] STATION_2 = new object[2] { "STATION 2 MAIN LINE", false };
        public object[] STATION_3 = new object[2] { "STATION 3 MAIN LINE", false };
        public object[] STATION_4 = new object[2] { "STATION 4 MAIN LINE", false };
        public object[] STATION_5 = new object[2] { "STATION 5 MAIN LINE", false };
        public object[] STATION_6 = new object[2] { "STATION 6 MAIN LINE", false };
        public object[] STATION_7 = new object[2] { "STATION 7 MAIN LINE", false };
        public object[] STATION_8 = new object[2] { "STATION 8 MAIN LINE", false };
        public object[] STATION_9 = new object[2] { "STATION 9 MAIN LINE", false };        
        public object[] STATION_10 = new object[2] { "STATION 10 MAIN LINE", false };
        public object[] STATION_11 = new object[2] { "STATION 11 MAIN LINE", false };
        public object[] FINAL_INSPECION = new object[2] { "FINAL INSPECTION ", false };
 
        //test stations
        public object[] HIPOT = new object[2] { "HIPOT", false };
        public object[] FVT = new object[2] { "FVT", false };

        public class SCO_Stations
        {
            public bool STATION_1;
            public bool STATION_2;
            public bool STATION_3;
            public bool STATION_4;
            public bool STATION_5;
            public bool STATION_6;
            public bool STATION_7;
            public bool STATION_8;
            public bool STATION_9;
            public bool STATION_10;

            public SCO_Stations()
            {
                this.STATION_1 = false;
                this.STATION_2 = false;
                this.STATION_3 = false;
                this.STATION_4 = false;
                this.STATION_5 = false;
                this.STATION_6 = false;
                this.STATION_7 = false;
                this.STATION_8 = false;
                this.STATION_9 = false;
                this.STATION_10 = false;
            }
        }
   
        public struct MyData
        {
            public string ArrivalTime { set; get; }
            public string ProcessName { set; get; }
            public string ProcessResult { set; get; }
        }

        void InicializarDataGrid()
        {
            DataGridTextColumn ArrivalTime = new DataGridTextColumn();
            ArrivalTime.Header = "Arrival Time";
            ArrivalTime.Binding = new Binding("ArrivalTime");
            ArrivalTime.Width = 200;
            ArrivalTime.IsReadOnly = true;

            DataGridTextColumn ProcessName = new DataGridTextColumn();
            ProcessName.Header = "Process Name";
            ProcessName.Binding = new Binding("ProcessName");
            ProcessName.Width = 200;
            ProcessName.IsReadOnly = true;

            DataGridTextColumn ProcessResult = new DataGridTextColumn();
            ProcessResult.Header = "Process Result";
            ProcessResult.Binding = new Binding("ProcessResult");
            ProcessResult.Width = 200;
            ProcessResult.IsReadOnly = true;

            dgvHistory.Columns.Add(ArrivalTime);
            dgvHistory.Columns.Add(ProcessName);
            dgvHistory.Columns.Add(ProcessResult);
        }

        void WriteDgv(String _ArrivalTime, string _ProcessName, string _ProcessResult)
        {
            Dispatcher.Invoke(() =>
            {
                dgvHistory.Items.Add(new MyData { ArrivalTime = _ArrivalTime, ProcessName = _ProcessName, ProcessResult = _ProcessResult });
                if (dgvHistory.Items.Count > 0)
                {
                    var border = VisualTreeHelper.GetChild(dgvHistory, 0) as Decorator;
                    if (border != null)
                    {
                        var scroll = border.Child as ScrollViewer;
                        if (scroll != null) scroll.ScrollToEnd();
                    }
                }
                dgvHistory.Items.Refresh();
                InvalidateVisual();
            });
        }

        private void DgvHistory_LoadingRow(object sender, DataGridRowEventArgs e)
        {
            var row = e.Row;
            MyData _mydata = new MyData();
            _mydata = (MyData)row.DataContext;

            if (_mydata.ProcessResult.Contains("Failed"))
            {
                row.Background = new SolidColorBrush(Colors.PaleVioletRed);
                _CQAIndicator = false;
            }

            if (_mydata.ProcessResult.Contains("Passed"))
            {
                row.Background = _GreenMaterial;
                _CQAIndicator = false;
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            lblVersion.Content = "NCR CQA Check Point " + _ver; 
            txtBoxScan.Focus();
            InicializarDataGrid();
        }

        private async void TxtBoxScan_KeyDown(object sender, KeyEventArgs e)
        {
            string[] _unitInfo = { "" };

            //If operator press a wrong key skip the process
            if (e.Key != Key.Enter) return;

            _tracerOrWip = txtBoxScan.Text;
            _unitInfo = _iFactoryInfo.GetSCMC(_tracerOrWip);

            //Get Unit information by Tracer or Wip
            if (_unitInfo[0] != "Serial Not Found")
            {
                _tracer = _tracerOrWip;
                _wip = _unitInfo[0];
                _class = _unitInfo[1] + "MC" + _unitInfo[2];
                goto Next;
            }

            _unitInfo = _iFactoryInfo.GetWIPInfo(_tracerOrWip);

            if (_unitInfo[0] != "Serial Not Found")
            {
                _tracer = _unitInfo[1];
                _wip = _unitInfo[0];
                _class = _unitInfo[3];
                goto Next;
            }

            CreateToast(this.Width,
                0, "UNIDAD NO ENCONTRADA EN IFACTORY",
                DeskNotify.NotifyType.OnError);

            txtBoxScan.Clear();
            txtBoxScan.Focus();
            return;

            Next:
            dgvHistory.Items.Clear();
            Task<int> _Task = new Task<int>(AsyncWriteData);
            _Task.Start();
            int response = await _Task;

            validateStations();

            lblLastTracer.Content = "TRACER: " + _tracer;
            lblLasWIp.Content = "      WIP: " + _wip;
            txtBoxScan.Clear();
            txtBoxScan.Focus();
        }

        void CreateToast(double _Width, double _Height, string Text, DeskNotify.NotifyType type)
        {
            DeskNotify deskNotifyWin = new DeskNotify(_Width, _Height, Text, type);
            deskNotifyWin.Show();
        }

        int AsyncWriteData()
        {
            DataSet _ds;
            DataTable _dt;
            int _dataRows = 0;
            int _loops = 1;

            _ds = _iFactoryInfo.GetHistory(_wip);
            _dt = _ds.Tables[0];

            _dataRows = _dt.Rows.Count;
            _dataRows--;

            while (_loops <= _dataRows)
            {
                var varArrivalTime = _dt.Rows[_loops]["ArrivalTime"];
                var varProcessName = _dt.Rows[_loops]["ProcessName"];
                var varProcessResult = _dt.Rows[_loops]["ProcessResult"];

                if((string)varProcessResult == "Passed") SetSCO_Stations(varProcessName.ToString());

                WriteDgv(varArrivalTime.ToString(), varProcessName.ToString(), varProcessResult.ToString());

                _loops++;
                System.Threading.Thread.Sleep(80);
            }      
            return 0;
        }


        void SetSCO_Stations(string ProcessName)
        {
            if (ProcessName == (string)STATION_1[0])
                STATION_1[1] = true;
            if (ProcessName == (string)STATION_2[0])
                STATION_2[1] = true;
            if (ProcessName == (string)STATION_3[0])
                STATION_3[1] = true;
            if (ProcessName == (string)STATION_4[0])
                STATION_4[1] = true;
            if (ProcessName == (string)STATION_5[0])
                STATION_5[1] = true;
            if (ProcessName == (string)STATION_6[0])
                STATION_6[1] = true;
            if (ProcessName == (string)STATION_7[0])
                STATION_7[1] = true;
            if (ProcessName == (string)STATION_8[0])
                STATION_8[1] = true;
            if (ProcessName == (string)STATION_9[0])
                STATION_9[1] = true;
            if (ProcessName == (string)STATION_10[0])
                STATION_10[1] = true;
            if (ProcessName == (string)STATION_11[0])
                STATION_11[1] = true;

            //Quality station
            if (ProcessName == (string)FINAL_INSPECION[0])
                FINAL_INSPECION[1] = true;

            //Test stations
            if (ProcessName == (string)HIPOT[0])
                HIPOT[1] = true;
            if (ProcessName == (string)FVT[0])
                FVT[1] = true;
        }

        void validateStations()
        {
            List<string> missingStations = new List<string>();

            if (!(bool)STATION_1[1])
                missingStations.Add((string)STATION_1[0]);
            if (!(bool)STATION_2[1])
                missingStations.Add((string)STATION_2[0]);
            if (!(bool)STATION_3[1])
                missingStations.Add((string)STATION_3[0]);
            if (!(bool)STATION_4[1])
                missingStations.Add((string)STATION_4[0]);
            if (!(bool)STATION_5[1])
                missingStations.Add((string)STATION_5[0]);
            if (!(bool)STATION_6[1])
                missingStations.Add((string)STATION_6[0]);
            if (!(bool)STATION_7[1])
                missingStations.Add((string)STATION_7[0]);
            if (!(bool)STATION_8[1])
                missingStations.Add((string)STATION_8[0]);
            if (!(bool)STATION_9[1])
                missingStations.Add((string)STATION_9[0]);
            if (!(bool)STATION_10[1])
                missingStations.Add((string)STATION_10[0]);
            if (!(bool)STATION_11[1])
                missingStations.Add((string)STATION_11[0]);
            if (!(bool)FINAL_INSPECION[1])
                missingStations.Add((string)FINAL_INSPECION[0]);
            if (!(bool)HIPOT[1])
                missingStations.Add((string)HIPOT[0]);
            if (!(bool)FVT[1])
                missingStations.Add((string)FVT[0]);

            double position = 0;
            foreach (string ProcessMissing in missingStations)
            {
                CreateToast(this.Width,
                    position,
                    ProcessMissing.ToUpper(),
                    DeskNotify.NotifyType.OnError);
                position += 75;
                Thread.Sleep(500);
            }
        }
   
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            Environment.Exit(1);
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            Environment.Exit(1);
        }

        private void BtnMinMax_Click(object sender, RoutedEventArgs e)
        {
            if (this.WindowState == WindowState.Normal)
            {
                this.WindowState = WindowState.Minimized;
                return;
            }

            if (this.WindowState == WindowState.Minimized)
            {
                this.WindowState = WindowState.Normal;
                return;
            } 
        }

        private void BtnMinMaximizar_Click(object sender, RoutedEventArgs e)
        {
            //if(this.WindowState == WindowState.Normal)
            //{
            //    this.WindowState = WindowState.Maximized;
            //    return;
            //}
            //if(this.WindowState == WindowState.Maximized)
            //{
            //    this.WindowState = WindowState.Normal;
            //    return;
            //}
        }


        void newlabel()
        {
            Label todo = new Label();
            todo.Content = "hola 1";

            StackPanel1.Children.Add(todo); 
        }
    }
}
