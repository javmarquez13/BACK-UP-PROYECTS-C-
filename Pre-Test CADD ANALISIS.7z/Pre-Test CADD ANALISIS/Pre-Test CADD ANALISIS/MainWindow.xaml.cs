﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;

namespace Pre_Test_CADD_ANALISIS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        #region Variables Globales
        string PathData;
        string PathDataCADD = @"\\mxchim0pangea01\SSCO_IMAGES\LOGS\CADDChecker\";
        string PathDataUSB = @"\\mxchim0pangea01\SSCO_IMAGES\LOGS\USBCHECKER\";
        string PreTest = "CADD_ANALISIS";


        #endregion

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            InicializarDataGrid();
        }


        #region Obtener archivos sorteados por fecha

        string _From = string.Empty;
        string _To = string.Empty;
        DateTime _FromDate;
        DateTime _ToDate;

        private void DatePickerFrom_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            _From = datePickerFrom.SelectedDate.Value.ToString("MM_yyyy_dd");
            _FromDate = datePickerFrom.SelectedDate.Value.Date;

        }

        private void DatePickerTo_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            _To = datePickerTo.SelectedDate.Value.ToString("MM_yyyy_dd");
            _ToDate = datePickerTo.SelectedDate.Value.Date;
        }


        int QueryData()
        {
            string[] _Dates = { string.Empty };
            DirectoryInfo[] _Hours;
            FileInfo[] _Files;
            TimeSpan _timeSpan = _ToDate - _FromDate;

            List<string> _ListDates = new List<string>();


            Dispatcher.Invoke(() => {
                // Code causing the exception or requires UI thread access
                lblDataFrom.Content = "Last Query:" + "\n"
                                 + "FROM: " + _FromDate.ToShortDateString() + "\n"
                                 + "TO: " + _ToDate.ToShortDateString();
            });
           

            try
            {

                _ListDates.Add(_FromDate.ToString("MM_yyyy_dd"));

                for(int i =1; i<_timeSpan.Days; i++)
                {
                   _ListDates.Add(_FromDate.AddDays(i).ToString("MM_yyyy_dd"));
                }

                if(_FromDate != _ToDate)
                {
                    _ListDates.Add(_ToDate.ToString("MM_yyyy_dd"));
                }
                
                _Dates = _ListDates.ToArray();

                foreach(string Date in _Dates)
                {
                    if (PreTest == "CADD_ANALISIS") PathData = PathDataCADD;
                    if (PreTest == "USB_CHECKER") PathData = PathDataUSB;

                    DirectoryInfo _dir = new DirectoryInfo(PathData + Date);

                    if (!_dir.Exists) goto Skip;

                    _Hours = _dir.GetDirectories();

                    foreach (DirectoryInfo _Hour in _Hours)
                    {
                        _Files = _Hour.GetFiles();

                        foreach (FileInfo _File in _Files)
                        {
                            if(PreTest == "CADD_ANALISIS") ReadXML(_File.FullName);
                            if(PreTest == "USB_CHECKER") ReadXMLUSB(_File.FullName);
                        }
                    }
                    Skip: { };
                }               
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            return 1;
        }


        void ReadXMLUSB(string FileName)
        {
            try
            {
                string Content = File.ReadAllText(FileName);

                if (!Content.Contains("DESCONECTADO")) return;
                if (!FileName.Contains("START")) return;

                XmlDocument xml = new XmlDocument();
                xml.Load(FileName);


                //XmlNodeList xnList = xml.SelectNodes("U" + TRACER);
                XmlNodeList xnList = xml.GetElementsByTagName("USB_LOG");
                foreach (XmlNode xn in xnList)
                {
                    string _DATE = xn["DATE"].InnerText;
                    string _TRACER = xn["TRACER"].InnerText;
                    string _STATUS = xn["STATUS"].InnerText;
                    string _MODULE = xn["MODULE"].InnerText;
                    string _PIDVID = xn["PIDVID"].InnerText;
                    string _COMMENTS = xn["COMMENTS"].InnerText;

                    if (_COMMENTS.Contains("DESCONECTADO")) WriteDgvUSB(_DATE, _TRACER, _STATUS, _MODULE, _PIDVID, _COMMENTS);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void ReadXML(string FileName)
        {
            try
            {
                string Content = File.ReadAllText(FileName);

                if (!Content.Contains("Last failure:")) return;

                XmlDocument xml = new XmlDocument();
                xml.Load(FileName);


                //XmlNodeList xnList = xml.SelectNodes("U" + TRACER);
                XmlNodeList xnList = xml.GetElementsByTagName("CADD_LOG");
                foreach (XmlNode xn in xnList)
                {
                    string _DATE = xn["DATE"].InnerText;
                    string _TRACER = xn["TRACER"].InnerText;
                    string _MODULE = xn["MODULE"].InnerText;
                    string _COMMENTS = xn["COMMENTS"].InnerText;
                    string _USER = xn["USER"].InnerText;
                    string _DIAGNOSTIC = xn["DIAGNOSTIC"].InnerText;
                    string _SERIALNUMBER = xn["SERIALNUMBER"].InnerText;

                    if (_COMMENTS.Contains("Last failure:")) WriteDgv(_DATE.Trim(), _TRACER.Trim(), _MODULE.Trim(), _COMMENTS.Trim(), _USER.Trim(), _DIAGNOSTIC.Trim(), _SERIALNUMBER.Trim());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private async void BtnQuery_Click(object sender, RoutedEventArgs e)
        {
            IMSIProgressBar.Value = 0;
            dgvHistory.Items.Clear();
            Task<int> _Task = new Task<int>(QueryData);
            _Task.Start();
            int response = await _Task;
            // QueryData();

            Task<int> _Task2 = new Task<int>(FillProgressBar);
            _Task2.Start();
            response = await _Task2;

            MessageBox.Show("DONE");
        }


        int FillProgressBar()
        {
            Dispatcher.Invoke(() =>
            {
                for (double i = IMSIProgressBar.Value; i < 1000; i++)
                {
                    IMSIProgressBar.Value++;
                }
            });
          
            return 1;
        }

        #endregion


        #region Ajustar formulario y diseno 
        private void Grid_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            myCanvas.Width = e.NewSize.Width;
            myCanvas.Height = e.NewSize.Height;

            double xChange = 1, yChange = 1;

            if (e.PreviousSize.Width != 0)
                xChange = (e.NewSize.Width / e.PreviousSize.Width);

            if (e.PreviousSize.Height != 0)
                yChange = (e.NewSize.Height / e.PreviousSize.Height);

            foreach (FrameworkElement fe in myCanvas.Children)
            {
                /*because I didn't want to resize the grid I'm having inside the canvas in this particular instance. (doing that from xaml) */
                if (fe is Grid == false)
                {
                    fe.Height = fe.ActualHeight * yChange;
                    fe.Width = fe.ActualWidth * xChange;

                    Canvas.SetTop(fe, Canvas.GetTop(fe) * yChange);
                    Canvas.SetLeft(fe, Canvas.GetLeft(fe) * xChange);
                }
            }
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                this.DragMove();
        }
        #endregion

        #region Mostrar datos en data grid

        void InicializarDataGrid()
        {
            dgvHistory.Items.Clear();
            dgvHistory.Columns.Clear();  

            if(PreTest == "CADD_ANALISIS")
            {
                DataGridTextColumn Date = new DataGridTextColumn();
                Date.Header = "DATE";
                Date.Binding = new Binding("Date");
                Date.Width = 150;
                Date.IsReadOnly = true;

                DataGridTextColumn Tracer = new DataGridTextColumn();
                Tracer.Header = "TRACER";
                Tracer.Binding = new Binding("Tracer");
                Tracer.Width = 100;
                Tracer.IsReadOnly = true;

                DataGridTextColumn Module = new DataGridTextColumn();
                Module.Header = "MODULE";
                Module.Binding = new Binding("Module");
                Module.Width = 100;
                Module.IsReadOnly = true;

                DataGridTextColumn Comments = new DataGridTextColumn();
                Comments.Header = "COMMENTS";
                Comments.Binding = new Binding("Comments");
                Comments.Width = 350;
                Comments.IsReadOnly = true;

                DataGridTextColumn User = new DataGridTextColumn();
                User.Header = "USER";
                User.Binding = new Binding("User");
                User.Width = 100;
                User.IsReadOnly = true;

                DataGridTextColumn Diagnostic = new DataGridTextColumn();
                Diagnostic.Header = "DIAGNOSTIC";
                Diagnostic.Binding = new Binding("Diagnostic");
                Diagnostic.Width = 350;
                Diagnostic.IsReadOnly = true;

                DataGridTextColumn SerialNumber = new DataGridTextColumn();
                SerialNumber.Header = "SERIALNUMBER";
                SerialNumber.Binding = new Binding("SerialNumber");
                SerialNumber.Width = 100;
                SerialNumber.IsReadOnly = true;

                dgvHistory.Columns.Add(Date);
                dgvHistory.Columns.Add(Tracer);
                dgvHistory.Columns.Add(Module);
                dgvHistory.Columns.Add(Comments);
                dgvHistory.Columns.Add(User);
                dgvHistory.Columns.Add(Diagnostic);
                dgvHistory.Columns.Add(SerialNumber);
            }


            if (PreTest == "USB_CHECKER")
            {
                DataGridTextColumn Date = new DataGridTextColumn();
                Date.Header = "DATE";
                Date.Binding = new Binding("Date");
                Date.Width = 150;
                Date.IsReadOnly = true;

                DataGridTextColumn Tracer = new DataGridTextColumn();
                Tracer.Header = "TRACER";
                Tracer.Binding = new Binding("Tracer");
                Tracer.Width = 100;
                Tracer.IsReadOnly = true;

                DataGridTextColumn Status = new DataGridTextColumn();
                Status.Header = "STATUS";
                Status.Binding = new Binding("Status");
                Status.Width = 100;
                Status.IsReadOnly = true;

                DataGridTextColumn Module = new DataGridTextColumn();
                Module.Header = "MODULE";
                Module.Binding = new Binding("Module");
                Module.Width = 350;
                Module.IsReadOnly = true;

                DataGridTextColumn PidVid = new DataGridTextColumn();
                PidVid.Header = "PIDVID";
                PidVid.Binding = new Binding("PidVid");
                PidVid.Width = 100;
                PidVid.IsReadOnly = true;

                DataGridTextColumn Comments = new DataGridTextColumn();
                Comments.Header = "COMMENTS";
                Comments.Binding = new Binding("Comments");
                Comments.Width = 350;
                Comments.IsReadOnly = true;

                dgvHistory.Columns.Add(Date);
                dgvHistory.Columns.Add(Tracer);
                dgvHistory.Columns.Add(Status);
                dgvHistory.Columns.Add(Module);
                dgvHistory.Columns.Add(PidVid);
                dgvHistory.Columns.Add(Comments);
            }

        }

        public struct MyData
        {
            public string Date { set; get; }
            public string Tracer { set; get; }
            public string Module { set; get; }
            public string Comments { set; get; }
            public string User { set; get; }
            public string Diagnostic { set; get; }
            public string SerialNumber { set; get; }
        }

        public struct MyDataUSB
        {
            public string Date { set; get; }
            public string Tracer { set; get; }
            public string Status { set; get; }
            public string Module { set; get; }
            public string PidVid { set; get; }
            public string Comments { set; get; }
        }

        void WriteDgv(string _date, string _tracer, string _Module, string _Comments, string _User, string _Diagnostic, string _SerialNumber)
        {
            Dispatcher.Invoke(() => 
            {
                dgvHistory.Items.Add(new MyData { Date = _date, Tracer = _tracer, Module = _Module, Comments = _Comments, User = _User, Diagnostic = _Diagnostic, SerialNumber = _SerialNumber });

                if (dgvHistory.Items.Count > 0)
                {
                    var border = VisualTreeHelper.GetChild(dgvHistory, 0) as Decorator;
                    if (border != null)
                    {
                        var scroll = border.Child as ScrollViewer;
                        if (scroll != null) scroll.ScrollToEnd();
                    }
                }

                IMSIProgressBar.Value = IMSIProgressBar.Value + 3;
                dgvHistory.Items.Refresh();
                InvalidateVisual();
            });              
        }

        void WriteDgvUSB(string _date, string _tracer, string _Status, string _Module, string _PidVid, string _Comments)
        {
            Dispatcher.Invoke(() =>
            {
                dgvHistory.Items.Add(new MyDataUSB { Date = _date, Tracer = _tracer, Status = _Status, Module = _Module, PidVid = _PidVid, Comments = _Comments });

                if (dgvHistory.Items.Count > 0)
                {
                    var border = VisualTreeHelper.GetChild(dgvHistory, 0) as Decorator;
                    if (border != null)
                    {
                        var scroll = border.Child as ScrollViewer;
                        if (scroll != null) scroll.ScrollToEnd();
                    }
                }

                IMSIProgressBar.Value = IMSIProgressBar.Value + 3;
                dgvHistory.Items.Refresh();
                InvalidateVisual();
            });           
        }

        private void DgvHistory_LoadingRow(object sender, DataGridRowEventArgs e)
        {

        }
        #endregion



        private void BtnSwitch_Checked_1(object sender, RoutedEventArgs e)
        {
            PreTest = "USB_CHECKER";
            btnSwitch.Content = PreTest;
            Window_Loaded(sender, e);
        }

        private void BtnSwitch_Unchecked_1(object sender, RoutedEventArgs e)
        {
            PreTest = "CADD_ANALISIS";
            btnSwitch.Content = PreTest;
            Window_Loaded(sender, e);
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
