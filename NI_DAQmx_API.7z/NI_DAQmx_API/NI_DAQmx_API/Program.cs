﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NI_DAQmx_API
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);


            string[] _Args = Environment.GetCommandLineArgs(); //Lectura de argumentos de entrada

            Application.Run(new Form1(_Args));
        }
    }
}
