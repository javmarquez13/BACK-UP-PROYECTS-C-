﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NationalInstruments.DAQmx;
using System.IO;


namespace NI_DAQmx_API
{
    public partial class Form1 : Form
    {
        public Form1(string[] inputArgs)
        {
            InitializeComponent();
            _Args = inputArgs;         
        }

        string[] _Args;
        int ExitCode = 5;
     
  
        int functionToRead(string PortLine)
        {
            int _return = 0;
            NationalInstruments.DAQmx.Task task = new NationalInstruments.DAQmx.Task();
            
            string[] devices = DaqSystem.Local.Devices;
            string[] channels = DaqSystem.Local.GetPhysicalChannels(PhysicalChannelTypes.All, PhysicalChannelAccess.External);

            PortLine = devices[0] + "/" + PortLine;

            task.DIChannels.CreateChannel(PortLine, string.Empty, ChannelLineGrouping.OneChannelForEachLine);
        
            bool flag = new DigitalSingleChannelReader(task.Stream).ReadSingleSampleSingleLine();

            if (flag) _return= 1;
            if (!flag) _return= 0;

            return _return;
        }

        void functionToWrite(string PortLine, string Value)
        {
            bool DATA = Convert.ToBoolean(Value);
                   
            NationalInstruments.DAQmx.Task task = new NationalInstruments.DAQmx.Task();
            string[] devices = DaqSystem.Local.Devices;
            string[] channels = DaqSystem.Local.GetPhysicalChannels(PhysicalChannelTypes.All, PhysicalChannelAccess.External);

            PortLine = devices[0] + "/" + PortLine;
            
            task.DOChannels.CreateChannel(PortLine, string.Empty, ChannelLineGrouping.OneChannelForEachLine);
            new DigitalSingleChannelWriter(task.Stream).WriteSingleSampleSingleLine(true, DATA);
        }

        /// Funciones para atrapa money
        private void Form1_Load(object sender, EventArgs e)
        {
            if (_Args[1] == "Setup")
            {
                ExitCode = Setup();
            }

            if (_Args[1] == "TakeMoney")
            {
              ExitCode = TakeMoney();
            } 
       
            Environment.Exit(ExitCode);
        }

           
        int TakeMoney()
        {
            int _result = 0;
            int ExitCode = 0;

            try
            {
                //Bill sensor wait for bills
                while (functionToRead("port2/line0") != 1)
                {
                    System.Threading.Thread.Sleep(500);
                }

                //Move slide out
                functionToWrite("port1/line0", "false");
                System.Threading.Thread.Sleep(500);

                //Wait for slide out sensor
                while (functionToRead("port2/line2") != 1)
                {
                    System.Threading.Thread.Sleep(500);
                }

                //Act gripper
                functionToWrite("port1/line1", "false");
                System.Threading.Thread.Sleep(500);

                //Move slide home
                functionToWrite("port1/line0", "true");
                System.Threading.Thread.Sleep(500);

                //Wait for home sensor
                while (functionToRead("port2/line1") != 1)
                {
                    System.Threading.Thread.Sleep(500);
                }

                //Open gripper
                functionToWrite("port1/line1", "true");
                System.Threading.Thread.Sleep(500);
            }

            catch(Exception ex)
            {
                ExitCode = 1;
                MessageBox.Show(ex.Message);
            }

            return ExitCode;
        }

        int Setup()
        {
            int _result = 0;
            int ExitCode = 0;

            try
            {              
                //Move slide out
                functionToWrite("port1/line0", "false");
                System.Threading.Thread.Sleep(500);

                //Wait for slide out sensor
                while (functionToRead("port2/line2") != 1)
                {
                    System.Threading.Thread.Sleep(500);
                }

                //Act gripper
                functionToWrite("port1/line1", "false");
                System.Threading.Thread.Sleep(500);

                //Move slide home
                functionToWrite("port1/line0", "true");
                System.Threading.Thread.Sleep(500);

                //Wait for home sensor
                while (functionToRead("port2/line1") != 1)
                {
                    System.Threading.Thread.Sleep(500);
                }

                //Open gripper
                functionToWrite("port1/line1", "true");
                System.Threading.Thread.Sleep(500);
            }

            catch (Exception ex)
            {
                ExitCode = 1;
                MessageBox.Show(ex.Message);
            }

            return ExitCode;                 
        } 
    }
}






class JoseCerda
{

    public string Color { get; set; }
    public string Edad { get; set; }
    public string Carrera { get; set; }

    public JoseCerda()
    {
        this.Color = null;
        this.Edad = null;
        this.Carrera = null;
    }
}
   



