﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NCR_User_Certification
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            lblError.Visibility = Visibility.Hidden;
        }

        //string _APIUrl = @"http://mxchim0web12:8087/iFactoryCustomReportAPI/api/Certifications/ValidateUserAccessCertification/?userLogin=jabil%5C918271&resource=MXCHINCRMLNATM1";
        string _APIUrl = @"http://mxchim0web12:8087/iFactoryCustomReportAPI/api/Certifications/ValidateUserAccessCertification/";

        UserCertificationsDLL.UserCertificationsDLL ValidateCertification = new UserCertificationsDLL.UserCertificationsDLL();
        bool _IsAllowed = false;
        bool _IsCertification = false;
        string PROCESSNAME = "FVT";
        string RESORUCE = "MXCHINCRMLNATM1";


        JsonRoot GETJson(string API)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(API);
            try
            {
                WebResponse response = request.GetResponse();
                using (Stream responseStream = response.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(responseStream, System.Text.Encoding.UTF8);
                    string json = reader.ReadToEnd();
                    JsonRoot _infoUnit = JsonConvert.DeserializeObject<JsonRoot>(json);
                    return _infoUnit;
                }
            }
            catch (WebException ex)
            {
                WebResponse errorResponse = ex.Response;
                using (Stream responseStream = errorResponse.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(responseStream, System.Text.Encoding.GetEncoding("utf-8"));
                    String errorText = reader.ReadToEnd();
                }
                throw;
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            string FileWithAllUsers = @"C:\Images\UserCert.txt";
            string[] Content = System.IO.File.ReadAllLines(FileWithAllUsers);
            List<string> _list = new List<string>();

            foreach (string line in Content)
            {
                string[] SplitIn3 = line.Split('\t');

                JsonRoot _infoCertObj = GETJson(_APIUrl + "?userLogin=jabil%5C" + SplitIn3[0] + "&resource=" + RESORUCE);

                if (_infoCertObj._data.UserCertifications.Count > 0)
                {
                    string json = _infoCertObj._data.UserCertifications[0].ToString();
                    CertificacionInfo _certInfo = JsonConvert.DeserializeObject<CertificacionInfo>(json);
                    //MessageBox.Show(SplitIn3[2] + " Certificacion encontrada " + _certInfo.CertificationName + _certInfo.UpdatedByName);
                    _list.Add(SplitIn3[0] + " " + SplitIn3[2] + " Certificacion encontrada " + _certInfo.CertificationName +" "+ _certInfo.UpdatedByName);
                }
                else
                {
                    _infoCertObj = GETJson(_APIUrl + "?userLogin=jabil%5C" + SplitIn3[1] + "&resource=" + RESORUCE);

                    try
                    {

                        if (_infoCertObj._data.UserCertifications.Count > 0)
                        {
                            string json = _infoCertObj._data.UserCertifications[0].ToString();
                            CertificacionInfo _certInfo = JsonConvert.DeserializeObject<CertificacionInfo>(json);
                            //MessageBox.Show(SplitIn3[2] + " Certificacion encontrada " + _certInfo.CertificationName + _certInfo.UpdatedByName);
                            _list.Add(SplitIn3[0] + " " + SplitIn3[2] + " Certificacion encontrada " + _certInfo.CertificationName + " " + _certInfo.UpdatedByName);
                        }
                        else
                        {
                            //MessageBox.Show(SplitIn3[2] + " Certificacion no encontrada");
                            _list.Add(SplitIn3[0] + " " + SplitIn3[2] + "  Certificacion no encontrada");
                        }
                    }

                    catch(Exception ex)
                    {

                    }
                   
                }
            }

            using (StreamWriter _sw = new StreamWriter(@"C:\Images\CertNoEncontradas.txt"))
            {
                foreach(string _cer  in _list)
                {
                    _sw.WriteLine(_cer);
                }
                _sw.Close();
            }
        }

        private void TxtUser_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.Key == Key.Enter)
            {
                JsonRoot _infoCertObj = GETJson(_APIUrl + "?userLogin=jabil%5C" + txtUser.Text + "&resource=" + RESORUCE);
                if (_infoCertObj._data.UserCertifications.Count > 0)
                {
                    lblError.Visibility = Visibility.Hidden;
                    string json = _infoCertObj._data.UserCertifications[0].ToString();
                    CertificacionInfo _certInfo = JsonConvert.DeserializeObject<CertificacionInfo>(json);
                    MessageBox.Show("OK");
                }
                else
                {
                    lblError.Content = "CERTIFICACION NO ENCONTRADA";
                    lblError.Visibility = Visibility.Visible;
                }
            }
        }
    }
}
