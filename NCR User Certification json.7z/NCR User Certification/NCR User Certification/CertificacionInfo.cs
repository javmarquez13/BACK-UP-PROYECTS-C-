﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NCR_User_Certification
{
    class CertificacionInfo
    {
        public string CertificationName { get; set; }
        public bool IsActive { get; set; }
        public bool CertificationExpires { get; set; }
        public string EffectiveFrom { get; set; }
        public string EffectiveTo { get; set; }
        public bool TrainingCertification { get; set; }
        public bool NearToExpire { get; set; }
        public bool Expired { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedByName { get; set; }
        public string UpdateByLogin { get; set; }


        public CertificacionInfo()
        {
            this.CertificationName = null;
            this.IsActive = false;
            this.CertificationExpires = false;
            this.EffectiveFrom = null;
            this.EffectiveTo = null;
            this.TrainingCertification = false;
            this.NearToExpire = false;
            this.Expired = false;
            this.UpdatedBy = null;
            this.UpdatedByName = null;
            this.UpdateByLogin = null;
        }
    }
}
