﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NCR_User_Certification
{
    class JsonRoot
    {
        public int _code { get; set; }
        public string _message { get; set; }
        public object _eventID { get; set; }
        public Data _data { get; set; }
        public bool _success { get; set; }
        public bool _fail { get; set; }
        public bool _warining { get; set; }
        public string _messageDetails { get; set; }

        public JsonRoot()
        {
            this._code = 0;
            this._data = null;
            this._eventID = null;
            this._fail = false;
            this._message = null;
            this._messageDetails = null;
            this._success = false;
            this._warining = false;
        }
    }
}
