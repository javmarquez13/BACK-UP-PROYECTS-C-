﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NCR_User_Certification
{
    class Data
    {
        public bool AccessAllowed { get; set; }
        public List<object> UserCertifications { get; set; }
        public List<object> CertificationsNeededPerResource { get; set; }
        public List<object> MatchCertifications { get; set; }

        public Data()
        {
            this.AccessAllowed = false;
            this.UserCertifications = null;
            this.CertificationsNeededPerResource = null;
            this.MatchCertifications = null;
        }
    }
}
