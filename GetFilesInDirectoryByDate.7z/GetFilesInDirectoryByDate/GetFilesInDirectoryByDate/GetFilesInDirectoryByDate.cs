﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JabilTest;

namespace GetFilesInDirectoryByDate
{
    public class GetFilesInDirectoryByDate : JabilTest.Test
    {
        public GetFilesInDirectoryByDate(ScriptVariableSpace varSpace, object otherParameters) : base(varSpace, otherParameters)
        {

        }

        public override TestResult Execute()
        {
            TestResult testResult = this.testResult;
            testResult.TestName = this.Name;
            testResult.TestDescription = this.Description;
            string stringVariable1 = this.GetStringVariable("Argument0", "Directory");
            string stringVariable2 = this.GetStringVariable("Argument1", "Search Pattern");

            try
            {
                DirectoryInfo _dirInfo = new DirectoryInfo(stringVariable1);
                //FileInfo[] filesInfo = _dirInfo.GetFiles(stringVariable2).OrderBy(p => p.CreationTime).ToArray();
                FileInfo[] filesInfo = _dirInfo.GetFiles(stringVariable2).OrderByDescending(d => d.CreationTime).ToArray();

                string[] files = filesInfo.Select(f => f.FullName).ToArray();

                ScriptVariable variable1 = new ScriptVariable("ReturnValue0", VariableType.Array, (object)files);
                ScriptVariable variable2 = new ScriptVariable("ReturnValue1", VariableType.Integer, (object)files.GetLength(0));
                this.VariableSpace.setVariable(variable1);
                this.VariableSpace.setVariable(variable2);
                this.VariableSpace.UpdateStatusText("GetFilesInDirectory: Directory [" + stringVariable1 + "] Returned [" + files.GetLength(0).ToString() + "] Files.");
                return testResult;
            }
            catch (IOException ex)
            {
                this.FailTest("GetFilesInDirectory: The Following Error Occurred [" + ex.Message + "]");
                return testResult;
            }
        }
    }
}
