﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Management;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;
using SendAttributes.SQL;
using Newtonsoft.Json;
using System.IO;
using System.Xml.Linq;
using System.Xml;


/// <summary>
/// DEVELOPER: JAVIER MARQUEZ 
/// DATE RELEASE: 28 OCT 2020
/// FIRST RELEASE 1.0.0.0
/// 
/// 28 OCT 2020
/// FILL THE SNBASEBOARD WITH MACADRESSS WHEN THIS IS EMPTY 
/// 1.0.0.1
/// 
/// 28 OCT 2020
/// ADD MILISECONDS FROMO DATETIME.NOW TO AVOID REPLACE THE XML ALREADY CREATED FROM THE SAME TRACER
/// 1.0.0.2
/// 
/// 
/// 
/// </summary>

namespace Display_Test
{
    public partial class Form1 : Form
    {
        //APP VERSION
        string VERSION = "1.0.0.2";

        //Globales
        iFactoryInfo.iFactoryInfo _iFactoryInfo = new iFactoryInfo.iFactoryInfo();
        SendAttributes.SendAttributes _sendAtrib = new SendAttributes.SendAttributes();

        //Info Unit
        string _TRACER;
        string _WIP;
        string _CLASS;
        string _CLASSMC;
        string[] _FEATURES;
        string[] _UnitInfo;
        bool _CONTINUE;
        bool _testPass = true;
        List<string> _buildTyp = new List<string>();

        //TestDisplay
        string _CPUType;
        ulong _MemoryRamTotal;
        ulong _UpperLimit;
        ulong _LowerLimit;
        string _SNBaseBoard;
        string _ProductBaseBoard;
        string _macAdress;
        UInt64[] _size = new UInt64[4];
        string[] _slots = new string[4];
        int _loop = 0;

        //Objects 
        private static ManagementObjectSearcher baseboardSearcher = new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_BaseBoard");
        private static ManagementObjectSearcher motherboardSearcher = new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_MotherboardDevice");
        private static ManagementObjectSearcher tpmModule = new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_Tpm");

        public Form1()
        {
            InitializeComponent();
            InicializarDGV();
            lblVersion.Text = VERSION;
        }

        void InicializarDGV()
        {
            dgvTests.Columns.Add("Date", "Fecha");
            dgvTests.Columns.Add("Test Name", "TestName");
            dgvTests.Columns.Add("Measurement Name", "Measurement");
            dgvTests.Columns.Add("Lower Limit", "LowerLimit");
            dgvTests.Columns.Add("Upper Limit", "UpperLimit");
            dgvTests.Columns.Add("Status", "Status");

            dgvTests.Columns["Date"].Width = 130;
            dgvTests.Columns["Test Name"].Width = 125;
            dgvTests.Columns["Measurement Name"].Width = 200;
            dgvTests.Columns["Lower Limit"].Width = 140;
            dgvTests.Columns["Upper Limit"].Width = 140;
            dgvTests.Columns["Status"].Width = 50;
         
            dgvTests.RowHeadersVisible = false;
        }

        void ScanningUnit()
        {
            _TRACER = txtScaneo.Text;
            _UnitInfo = _iFactoryInfo.GetSCMC(_TRACER);
            _WIP = _UnitInfo[0];
            _CLASS = _UnitInfo[1];
            _CLASSMC = _UnitInfo[1] + "-MC" + _UnitInfo[2];

            if (_UnitInfo.Contains(" Not Found") || _UnitInfo.Contains("Serial Not Found"))
            {
                _testPass = false;
                WriteDGV(_testPass, DateTime.Now, "TRACER", _TRACER, "", "");
                WriteDGV(_testPass, DateTime.Now, "WIP", _WIP, "", "");
                WriteDGV(_testPass, DateTime.Now, "CLASS-MC", _CLASSMC, "", "");
                _CONTINUE = false;
                return;
            }

            WriteDGV(_testPass, DateTime.Now, "TRACER", _TRACER, "", "");
            WriteDGV(_testPass, DateTime.Now, "WIP", _WIP, "", "");
            WriteDGV(_testPass, DateTime.Now, "CLASS-MC", _CLASSMC, "", "");
            _CONTINUE = true;
        }

        void TestDisplay()
        {
            _FEATURES = GetFeatsString(_CLASS);
            string _featString = string.Join(_CLASS, _FEATURES);
            WriteDGV(_testPass, DateTime.Now, "FEATURES", _featString, "", "");

            _buildTyp = GetFeatsDecription(_CLASS, _FEATURES);


            /// TEST FOR CPU TYPE
            _testPass = true;
            _CPUType = CheckCPUType();
            if (_buildTyp.Contains("INTEL_CELERON") && _buildTyp.Contains("XR7_DISPLAY"))
            {
                if (_CPUType.Contains("G1820TE")) _testPass = true;
                else _testPass = false;          
            }

            if (_buildTyp.Contains("INTEL_CELERON") && _buildTyp.Contains("7703_DISPLAY"))
            {
                if (_CPUType.Contains("G3900TE")) _testPass = true;
                else _testPass = false;
            }

            if (_buildTyp.Contains("INTEL_I3") && _buildTyp.Contains("XR7_DISPLAY"))
            {
                if (_CPUType.Contains("i3-4350t")) _testPass = true;
                else _testPass = false;
            }

            if (_buildTyp.Contains("INTEL_I3") && _buildTyp.Contains("7703_DISPLAY"))
            {
                if (_CPUType.Contains("i3-6100te")) _testPass = true;
                else _testPass = false;
            }

            if (_buildTyp.Contains("INTEL_I5") && _buildTyp.Contains("XR7_DISPLAY"))
            {
                if (_CPUType.Contains("4590t")) _testPass = true;
                else _testPass = false;
            }

            if (_buildTyp.Contains("INTEL_I5") && _buildTyp.Contains("7703_DISPLAY"))
            {
                if (_CPUType.Contains("7500TE")) _testPass = true;
                else _testPass = false;
            }
            WriteDGV(_testPass, DateTime.Now, "CPU", _CPUType, "", "");
            if (!_testPass) goto End;



            /// TEST FOR MEMORY RAM
            _testPass = true;
            _MemoryRamTotal = GetMemoryRam();
         
            foreach(string _slot in _slots)
            {               
                if (_slot == null) break;
                WriteDGV(_testPass, DateTime.Now, "MEMORY RAM", _slot + "=" + _size[_loop], "", "");
                _loop++;
            }


            //RAM 4GB
            if (!_buildTyp.Contains("EXTRA_4GB") && !_buildTyp.Contains("EXTRA_8GB") && !_buildTyp.Contains("SIXTEEN_GB_MEMORY") && !_buildTyp.Contains("8GB_MEMORY"))
            {
                _UpperLimit = 4500000000;
                _LowerLimit = 4000000000;

                if (_MemoryRamTotal <= _UpperLimit && _MemoryRamTotal >= _LowerLimit) _testPass = true;
                else _testPass = false;
            }


            //RAM 8GB
            if (_buildTyp.Contains("EXTRA_4GB") || _buildTyp.Contains("8GB_MEMORY") && !_buildTyp.Contains("EXTRA_8GB"))
            {
                _UpperLimit = 8800000000;
                _LowerLimit = 8000000000;

                if (_MemoryRamTotal <= _UpperLimit && _MemoryRamTotal >= _LowerLimit) _testPass = true;
                else _testPass = false;
            }


            //RAM 16GB
            if (_buildTyp.Contains("EXTRA_8GB") || _buildTyp.Contains("SIXTEEN_GB_MEMORY") && !_buildTyp.Contains("EXTRA_8GB"))
            {
                _UpperLimit = 17200000000;
                _LowerLimit = 16000000000;

                if (_MemoryRamTotal <= _UpperLimit && _MemoryRamTotal >= _LowerLimit) _testPass = true;
                else _testPass = false;
            }


            //RAM 24GB
            if (_buildTyp.Contains("EXTRA_8GB") && _buildTyp.Contains("SIXTEEN_GB_MEMORY"))
            {
                _UpperLimit = 25800000000;
                _LowerLimit = 24000000000;

                if (_MemoryRamTotal <= _UpperLimit && _MemoryRamTotal >= _LowerLimit) _testPass = true;
                else _testPass = false;
            }

            WriteDGV(_testPass, DateTime.Now, "MEMORY RAM", _MemoryRamTotal.ToString(), _LowerLimit.ToString(),_UpperLimit.ToString());
            if (!_testPass) goto End;


            _macAdress = CheckWMIValue(@"ROOT\\CIMV2", @"Select * FROM Win32_NetworkAdapterConfiguration where IPEnabled=true", "MACAddress");
            _sendAtrib.SendAttributesToiFactory("BASE-BOARD MAC-ADRESS", _macAdress, _WIP);
            WriteDGV(_testPass, DateTime.Now, "MAC ADRESS", _macAdress, "", "");

            _SNBaseBoard = GetSNBaseBoard;
            if (string.IsNullOrEmpty(_SNBaseBoard)) _SNBaseBoard = _macAdress;
            _sendAtrib.SendAttributesToiFactory("BASE-BOARD SERIAL NUMBER", _SNBaseBoard, _WIP);
            WriteDGV(_testPass, DateTime.Now, "BOARD SERIAL", _SNBaseBoard, "", "");

            _ProductBaseBoard = GetProductBaseBoard;
            _sendAtrib.SendAttributesToiFactory("BASE-BOARD PRODUCT", _ProductBaseBoard, _WIP);
            WriteDGV(_testPass, DateTime.Now, "BOARD PRODUCT", _ProductBaseBoard, "", "");

            End:
            {
                if (!_testPass) WriteDGV(_testPass, DateTime.Now, "TEST FAIL", "ENSAMBLE INCORRECTO", "","");
                if (_testPass) WriteDGV(_testPass, DateTime.Now, "TEST PASS", "ENSAMBLE CORRECTO", "","");

                DataTable _dt = GetDataTableFromDGV();
                _dt.TableName = "TEST";
                DataSet ds = new DataSet();
                ds.DataSetName = "DISPLAY_TEST";
                ds.Namespace = "RECURSO=SDISPLAY01TE01/STEPNAME=DISPLAY TEST";
                ds.Tables.Add(_dt);
                string xmlResult = ds.GetXml();
                File.WriteAllText(@"\\mxchim0pangea01\Display_TEST\" + _TRACER +"_"+ DateTime.Now.Millisecond +  ".xml", xmlResult);
            }
        }

 
        private DataTable GetDataTableFromDGV()
        {
            var dt = new DataTable();
            foreach (DataGridViewColumn column in dgvTests.Columns)
            {
                if (column.Visible)
                {                   
                    dt.Columns.Add(column.HeaderText);
                }
            }

            object[] cellValues = new object[dgvTests.Columns.Count];
            foreach (DataGridViewRow row in dgvTests.Rows)
            {
                for (int i = 0; i < row.Cells.Count; i++)
                {
                    cellValues[i] = row.Cells[i].Value;
                }
                dt.Rows.Add(cellValues);
            }

            return dt;
        }

        string[] GetFeatsString(string Class)
        {
            string[] _Lines = { "" };
            string[] _split = { "" };
            string _pathFeats = @"\\mxchim0pangea01\diskbld\feats\Feat";            
            string[] _featureString = { "" };

            int i = 0;
            int _space = 15;

            try
            {
                _Lines = File.ReadAllLines(_pathFeats + Class);

                foreach (string _line in _Lines)
                {
                    if (!_line.Contains("#"))
                    {
                        _split = _line.Split(' ');
                        i = _space - _split[0].Length;

                        if (_split[0].Contains(_CLASSMC))
                        {
                            _featureString = _split[i].Split(new[] { _CLASS }, StringSplitOptions.None);
                            break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                WriteDGV(false, DateTime.Now, "APP ISSUE", ex.Message, "", "");
            }

            return _featureString;
        }

        List<string> GetFeatsDecription(string ClassMc, string[] features)
        {
            string _pathFeaturesDescription = @"\\mxchim0pangea01\diskbld\stdcore\feature.txt";
            List<string> _buildTypeList = new List<string>();

            try
            {
                foreach(string feat in features)
                {
                    if (feat != "")
                    {
                        string _DescriptionFeat = File.ReadAllLines(_pathFeaturesDescription).Where(x => x.Contains(feat.ToUpper() + " " + ClassMc)).FirstOrDefault();

                        string[] _split = _DescriptionFeat.Split(' ');
                        string FeatClass = _split[0] + " " + _split[1];
                        List<string> _splitDescriptions = new List<string>();                       
                        int loop = 0;
                        _splitDescriptions = _split.ToList();

                        foreach (string featB in _splitDescriptions)
                        {
                            if (featB != "00FF" &&  featB != "000A" && loop >= 2)
                            {
                                _buildTypeList.Add(featB);
                            }

                            loop++;
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                WriteDGV(false, DateTime.Now, "APP ISSUE", ex.Message, "", "");
            }

            return _buildTypeList;
        }

        void WriteDGV(bool Status, DateTime date, string TestName, string MeasurementName, string LowerLimit, string UpperLimit)
        {
            string _PassFail = "FAIL";

            try
            {           
                if (Status)
                {
                    _PassFail = "PASS";
                    dgvTests.Invoke(new MethodInvoker(delegate
                    {
                        dgvTests.Rows.Add(new Object[]
                        {
                          date, TestName, MeasurementName, LowerLimit, UpperLimit, _PassFail
                        });
                        dgvTests.Rows[dgvTests.Rows.Count - 1].DefaultCellStyle.BackColor = Color.LightGreen;
                        dgvTests.CurrentCell = dgvTests.Rows[dgvTests.Rows.Count - 1].Cells[0];
                        this.Update();
                    }));         
                }

                if (!Status)
                {
                    _PassFail = "FAIL";
                    dgvTests.Invoke(new MethodInvoker(delegate
                    {
                        dgvTests.Rows.Add(new Object[]
                        {
                           date, TestName, MeasurementName, LowerLimit, UpperLimit, _PassFail
                        });
                        dgvTests.Rows[dgvTests.Rows.Count - 1].DefaultCellStyle.BackColor = Color.Red;
                        dgvTests.CurrentCell = dgvTests.Rows[dgvTests.Rows.Count - 1].Cells[0];
                        this.Update();
                    }));            
                }
            }
            catch (Exception ex)
            {
                dgvTests.Invoke(new MethodInvoker(delegate
                {

                    dgvTests.Rows.Add(new Object[]
                  {
                        date, "Application log", ex.Message, "", ""
                  });
                dgvTests.Rows[dgvTests.Rows.Count - 1].DefaultCellStyle.BackColor = Color.PaleVioletRed;
                dgvTests.CurrentCell = dgvTests.Rows[dgvTests.Rows.Count - 1].Cells[0];
                this.Update();

                }));

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtScaneo.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        ulong GetMemoryRam()
        {
            ulong MEMORY_RAM = 0;

            try
            {            
                for (int i = 0; i < 4; i++)
                {
                    try
                    {
                        string tag = i.ToString();
                        var ram = new ManagementObjectSearcher("Select * from WIN32_PhysicalMemory WHERE Tag LIKE 'Physical Memory " + tag + "'").Get().Cast<ManagementObject>().First();
                        _size[i] = (UInt64)ram["Capacity"];
                        _slots[i] = (string)ram["DeviceLocator"];
                    }
                    catch (Exception e)
                    {
                        //_size[i] = 0;
                        //_slots[i] = "unknown";
                    }
                }

                MEMORY_RAM = _size[0] + _size[1] + _size[2] + _size[3];

                //  MEMORY_RAM = ComputerInfo.TotalPhysicalMemory;    
                //RegistryKey Rkey = Registry.LocalMachine;
                //Rkey = Rkey.OpenSubKey("HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0");
                //CPU = (string)Rkey.GetValue("ProcessorNameString");
            }
            catch (Exception ex)
            {
                WriteDGV(false, DateTime.Now, "APP ISSUE", ex.Message, "", "");
            }

            return MEMORY_RAM;
        }

        string CheckCPUType()
        {
            string CPU = string.Empty;
            try
            {
                var result_cpu = new ManagementObjectSearcher("select * from Win32_Processor").Get().Cast<ManagementObject>().First();
                 CPU = ((string)result_cpu["Name"]).ToLower();
            }
            catch (Exception ex)
            {
                WriteDGV(false, DateTime.Now, "APP ISSUE", ex.Message, "", "");
            }
            return CPU;
        }

        string GetProductBaseBoard
        {
            get
            {
                try
                {
                    foreach (ManagementObject queryObj in baseboardSearcher.Get())
                    {
                        return queryObj["Product"].ToString();
                    }
                    return "";
                }
                catch (Exception e)
                {
                    return "";
                }
            }
        }

        string GetSNBaseBoard
        {
            get
            {
                try
                {
                    foreach (ManagementObject queryObj in baseboardSearcher.Get())
                    {
                        return queryObj["SerialNumber"].ToString();
                    }
                    return "";
                }
                catch (Exception e)
                {
                    return "";
                }
            }
        }

        string GetTPMModule
        {
            get
            {
                try
                {
                    foreach (ManagementObject queryObj in tpmModule.Get())
                    {
                        return queryObj["Value"].ToString();
                    }
                    return "";
                }
                catch (Exception e)
                {
                    return "";
                }
            }
        }

        string CheckWMIValue(string nameSpace, string query, string property)
        {
            try
            {
                string value = string.Empty;
                ObjectQuery WQL = new ObjectQuery(query);
                ManagementObjectSearcher searcher = new ManagementObjectSearcher(WQL);
                ManagementObjectCollection results = searcher.Get();
                foreach (ManagementObject mObject in results)
                {
                    foreach (PropertyData propertyItem in mObject.Properties)
                    {
                        if (propertyItem.Name.ToUpper() == property.ToUpper())
                        {
                            value = propertyItem.Value.ToString();
                            break;
                        }
                    }
                    if (value != string.Empty)
                    {
                        break;
                    }
                }
                return value;
            }
            catch (Exception exp)
            {
                throw;
            }
        }

        private async void txtScaneo_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyData == Keys.Enter)
            {
                timer1.Start();
                dgvTests.Rows.Clear();
                txtScaneo.Enabled = false;
                ScanningUnit();

                Task _MainTask = new Task(TestDisplay);
                _MainTask.Start();
                await _MainTask;

                txtScaneo.Clear();
                txtScaneo.Enabled = true;
                txtScaneo.Focus();
                timer1.Stop();
                _seconds = 0;
                _testPass = true;
            }          
        }


        double _seconds = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            TimeSpan _tim1 = TimeSpan.FromSeconds(_seconds);
            lblElapsedTime.Text = String.Format(@"Elapsed Time: {0:hh\:mm\:ss}", _tim1);
            _seconds++;
        }
    }
}
