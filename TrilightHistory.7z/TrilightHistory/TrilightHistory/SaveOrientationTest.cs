﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JabilTest;

namespace TrilightHistory
{
    class SaveOrientationTest : JabilTest.Test
    {
        public SaveOrientationTest(ScriptVariableSpace varSpace, object otherParameters) : base(varSpace, otherParameters)
        {

        }

        public override TestResult Execute()
        {
            string _Result = string.Empty;
            string Tracer = this.GetObjectVariable("Argument0", "Name0").ToString().Replace("'", "");
            string ConfidenceSideA = this.GetObjectVariable("Argument1", "Name1").ToString().Replace("'", "");
            string ConfidenceSideB = this.GetObjectVariable("Argument2", "Name2").ToString().Replace("'", "");


            //Main
            _Result = SaveTestUnit(Tracer, ConfidenceSideA, ConfidenceSideB, "PASSED");


            ScriptVariable retVar0 = new ScriptVariable("ReturnValue0", VariableType.String, _Result);
            VariableSpace.setVariable(retVar0);
            testResult.Status = TestStatus.Pass;
            return testResult;
        }

        //Global variables
        XMLHistory _XMLHistory = new XMLHistory();


        string  SaveTestUnit(string TRACER, string SIDE_A, string SIDE_B, string STATUS) 
        {
            string _Resultado = string.Empty;

            try
            {
                _XMLHistory.SavePassedUnit(DateTime.Now, TRACER, SIDE_A, SIDE_B, STATUS);
                _Resultado = TRACER + " Orientation test saved";
            }
            catch(Exception EX)
            {
                _Resultado = EX.Message;
            }
            return _Resultado;       
        }


        
    }
}
