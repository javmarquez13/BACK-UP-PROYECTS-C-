﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace TrilightHistory
{
    public class XMLHistory
    {

        DataSet ds;
        
        string LogBackup = @"C:\Images\DataBase\OrientationTest.xml";
        string LogBackupColor = @"C:\Images\DataBase\ColorTest.xml";


 
        public void SavePassedUnit(DateTime DATE, string TRACER, string SIDEA, string SIDEB, string STATUS)
        { 
            //Save unit passed in DB
            if (!File.Exists(LogBackup))
            {
                XmlWriterSettings xmlWriterSettings = new XmlWriterSettings();
                xmlWriterSettings.Indent = true;
                //xmlWriterSettings.NewLineOnAttributes = true;
                using (XmlWriter xmlWriter = XmlWriter.Create(LogBackup, xmlWriterSettings))
                {
                    xmlWriter.WriteStartDocument();
                    xmlWriter.WriteStartElement("TESTS");
                    xmlWriter.WriteStartElement("U" + TRACER);
                    xmlWriter.WriteElementString("SIDE_A", SIDEA);
                    xmlWriter.WriteElementString("SIDE_B", SIDEB);
                    xmlWriter.WriteElementString("STATUS", STATUS);
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();

                    xmlWriter.WriteEndDocument();
                    xmlWriter.Flush();
                    xmlWriter.Close();
                }
            }
            else
            {
                XmlDocument _doc = new XmlDocument();
                _doc.Load(LogBackup);

                XmlNode unit = _doc.CreateElement("U" + TRACER);
                XmlNode _sideA = _doc.CreateElement("SIDE_A");
                _sideA.InnerText = SIDEA;
                XmlNode _sideB = _doc.CreateElement("SIDE_B");
                _sideB.InnerText = SIDEB;
                XmlNode _status = _doc.CreateElement("STATUS");
                _status.InnerText = STATUS;
                unit.AppendChild(_sideA);
                unit.AppendChild(_sideB);
                unit.AppendChild(_status);
                _doc.DocumentElement.AppendChild(unit);
                _doc.Save(LogBackup);
            }
        }


        public void SavePassedUnitColor(DateTime DATE, string TRACER, string LANEINT, string LANECX, string LANECY, string GREENCX, string GREENCY, string YELLOWCX, string YELLOWCY, string REDCX, string REDCY, string STATUS)
        {
            //Save unit passed in DB
            if (!File.Exists(LogBackupColor))
            {
                XmlWriterSettings xmlWriterSettings = new XmlWriterSettings();
                xmlWriterSettings.Indent = true;
                //xmlWriterSettings.NewLineOnAttributes = true;
                using (XmlWriter xmlWriter = XmlWriter.Create(LogBackupColor, xmlWriterSettings))
                {
                    xmlWriter.WriteStartDocument();
                    xmlWriter.WriteStartElement("TESTS");
                    xmlWriter.WriteStartElement("U" + TRACER);
                    xmlWriter.WriteElementString("LANE_INTENSITY", LANEINT);
                    xmlWriter.WriteElementString("LANE_CX", LANECX);
                    xmlWriter.WriteElementString("LANE_CY", LANECY);
                    xmlWriter.WriteElementString("GREEN_CX", GREENCX);
                    xmlWriter.WriteElementString("GREEN_CY", GREENCY);
                    xmlWriter.WriteElementString("YELLOW_CX", YELLOWCX);
                    xmlWriter.WriteElementString("YELLOW_CY", YELLOWCY);
                    xmlWriter.WriteElementString("RED_CX", REDCX);
                    xmlWriter.WriteElementString("RED_CY", REDCY);
                    xmlWriter.WriteElementString("STATUS", STATUS);
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();

                    xmlWriter.WriteEndDocument();
                    xmlWriter.Flush();
                    xmlWriter.Close();
                }
            }
            else
            {
                XmlDocument _doc = new XmlDocument();
                _doc.Load(LogBackupColor);

                XmlNode unit = _doc.CreateElement("U" + TRACER);
                XmlNode _laneInt = _doc.CreateElement("LANE_INTENSITY");
                _laneInt.InnerText = LANEINT;
                XmlNode _laneCx = _doc.CreateElement("LANE_CX");
                _laneCx.InnerText = LANECX;
                XmlNode _laneCy = _doc.CreateElement("LANE_CY");
                _laneCy.InnerText = LANECY;

                XmlNode _greenCx = _doc.CreateElement("GREEN_CX");
                _greenCx.InnerText = GREENCX;
                XmlNode _greenCy = _doc.CreateElement("GREEN_CY");
                _greenCy.InnerText = GREENCY;

                XmlNode _yellowCx = _doc.CreateElement("YELLOW_CX");
                _yellowCx.InnerText = YELLOWCX;
                XmlNode _yellowCy = _doc.CreateElement("YELLOW_CY");
                _yellowCy.InnerText = YELLOWCY;

                XmlNode _redCx = _doc.CreateElement("RED_CX");
                _redCx.InnerText = REDCX;
                XmlNode _redCy = _doc.CreateElement("RED_CY");
                _redCy.InnerText = REDCY;

                XmlNode _status = _doc.CreateElement("STATUS");
                _status.InnerText = STATUS;

                unit.AppendChild(_laneInt);
                unit.AppendChild(_laneCx);
                unit.AppendChild(_laneCy);

                unit.AppendChild(_greenCx);
                unit.AppendChild(_greenCy);

                unit.AppendChild(_yellowCx);
                unit.AppendChild(_yellowCy);

                unit.AppendChild(_redCx);
                unit.AppendChild(_redCy);

                unit.AppendChild(_status);

                _doc.DocumentElement.AppendChild(unit);
                _doc.Save(LogBackupColor);
            }
        }
    }
}
