﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using JabilTest;


namespace TrilightHistory
{
    public class CheckOrientationTest : JabilTest.Test
    {
        public CheckOrientationTest(ScriptVariableSpace varSpace, object otherParameters) : base(varSpace, otherParameters)
        {

        }

        public override TestResult Execute()
        {
            string _Result0 = string.Empty;
            string _Result1 = string.Empty;
            string _Result2 = string.Empty;
            string Tracer = this.GetObjectVariable("Argument0", "Name0").ToString().Replace("'", "");
            

            //Main
            _Result0 = CheckTest(Tracer);
            _Result1 = valueSideA;
            _Result2 = valueSideB;

            ScriptVariable retVar0 = new ScriptVariable("ReturnValue0", VariableType.String, _Result0);
            ScriptVariable retVar1 = new ScriptVariable("ReturnValue1", VariableType.String, _Result1);
            ScriptVariable retVar2 = new ScriptVariable("ReturnValue2", VariableType.String, _Result2);
            VariableSpace.setVariable(retVar0);
            VariableSpace.setVariable(retVar1);
            VariableSpace.setVariable(retVar2);
            testResult.Status = TestStatus.Pass;
            return testResult;
        }


        //Gobal Variables
        DataSet ds;
        string LogBackup = @"C:\Images\DataBase\OrientationTest.xml";
        string XMLReader;
        string valueSideA = string.Empty;
        string valueSideB = string.Empty;



        string CheckTest(string TRACER)
        {
            string _Resultado = "FALSE";

            try
            {

                XmlDocument xml = new XmlDocument();
                xml.Load(LogBackup);


                //XmlNodeList xnList = xml.SelectNodes("U" + TRACER);
                XmlNodeList xnList = xml.GetElementsByTagName("U" + TRACER);
                foreach (XmlNode xn in xnList)
                { 
                    string SIDE_A = xn["SIDE_A"].InnerText;
                    string SIDE_B = xn["SIDE_B"].InnerText;
                    string STATUS = xn["STATUS"].InnerText;
              
                    valueSideA = SIDE_A;
                    valueSideB = SIDE_B;

                    _Resultado = "TRUE";
                }
            }
            catch(Exception ex)
            {
                _Resultado = ex.Message;
            }

            return _Resultado;
        }








    }
}
