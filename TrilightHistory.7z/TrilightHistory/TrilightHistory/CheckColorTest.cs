﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using JabilTest;


namespace TrilightHistory
{
    public class CheckColorTest : JabilTest.Test
    {
        public CheckColorTest(ScriptVariableSpace varSpace, object otherParameters) : base(varSpace, otherParameters)
        {

        }

        public override TestResult Execute()
        {
            string _Result0 = string.Empty;

            string _Result1 = string.Empty;
            string _Result2 = string.Empty;
            string _Result3 = string.Empty;

            string _Result4 = string.Empty;
            string _Result5 = string.Empty;

            string _Result6 = string.Empty;
            string _Result7 = string.Empty;

            string _Result8 = string.Empty;
            string _Result9 = string.Empty;

            string Tracer = this.GetObjectVariable("Argument0", "Name0").ToString().Replace("'", "");
            
            //Main
            _Result0 = CheckTest(Tracer);
            _Result1 = valueLaneInt;
            _Result2 = valueLaneCx;
            _Result3 = valueLaneCy;

            _Result4 = valueGreenCx;
            _Result5 = valueGreenCy;

            _Result6 = valueYellowCx;
            _Result7 = valueYellowCy;
        
            _Result8 = valueRedCx;
            _Result9 = valueRedCy;

            ScriptVariable retVar0 = new ScriptVariable("ReturnValue0", VariableType.String, _Result0);
            ScriptVariable retVar1 = new ScriptVariable("ReturnValue1", VariableType.String, _Result1);
            ScriptVariable retVar2 = new ScriptVariable("ReturnValue2", VariableType.String, _Result2);
            ScriptVariable retVar3 = new ScriptVariable("ReturnValue3", VariableType.String, _Result3);
            ScriptVariable retVar4 = new ScriptVariable("ReturnValue4", VariableType.String, _Result4);
            ScriptVariable retVar5 = new ScriptVariable("ReturnValue5", VariableType.String, _Result5);
            ScriptVariable retVar6 = new ScriptVariable("ReturnValue6", VariableType.String, _Result6);
            ScriptVariable retVar7 = new ScriptVariable("ReturnValue7", VariableType.String, _Result7);
            ScriptVariable retVar8 = new ScriptVariable("ReturnValue8", VariableType.String, _Result8);
            ScriptVariable retVar9 = new ScriptVariable("ReturnValue9", VariableType.String, _Result9);
            VariableSpace.setVariable(retVar0);
            VariableSpace.setVariable(retVar1);
            VariableSpace.setVariable(retVar2);
            VariableSpace.setVariable(retVar3);
            VariableSpace.setVariable(retVar4);
            VariableSpace.setVariable(retVar5);
            VariableSpace.setVariable(retVar6);
            VariableSpace.setVariable(retVar7);
            VariableSpace.setVariable(retVar8);
            VariableSpace.setVariable(retVar9);
            testResult.Status = TestStatus.Pass;
            return testResult;
        }


        //Gobal Variables
        DataSet ds;
        string LogBackup = @"C:\Images\DataBase\ColorTest.xml";
        string XMLReader;
        string valueLaneInt= string.Empty;
        string valueLaneCx= string.Empty;
        string valueLaneCy= string.Empty;

        string valueGreenCx = string.Empty;
        string valueGreenCy = string.Empty;

        string valueYellowCx = string.Empty;
        string valueYellowCy = string.Empty;

        string valueRedCx = string.Empty;
        string valueRedCy = string.Empty;


        string CheckTest(string TRACER)
        {
            string _Resultado = "FALSE";

            try
            {
                XmlDocument xml = new XmlDocument();
                xml.Load(LogBackup);

                //XmlNodeList xnList = xml.SelectNodes("U" + TRACER);
                XmlNodeList xnList = xml.GetElementsByTagName("U" + TRACER);
                foreach (XmlNode xn in xnList)
                { 
                    string LANE_INT = xn["LANE_INTENSITY"].InnerText;
                    string LANE_CX = xn["LANE_CX"].InnerText;
                    string LANE_CY = xn["LANE_CY"].InnerText;

                    string GREEN_CX = xn["GREEN_CX"].InnerText;
                    string GREEN_CY = xn["GREEN_CY"].InnerText;

                    string YELLOW_CX = xn["YELLOW_CX"].InnerText;
                    string YELLOW_CY = xn["YELLOW_CY"].InnerText;

                    string RED_CX = xn["RED_CX"].InnerText;
                    string RED_CY = xn["RED_CY"].InnerText;

                    string STATUS = xn["STATUS"].InnerText;


                    valueLaneInt = LANE_INT;
                    valueLaneCx = LANE_CX;
                    valueLaneCy = LANE_CY;

                    valueGreenCx = GREEN_CX;
                    valueGreenCy = GREEN_CY;

                    valueYellowCx = YELLOW_CX;
                    valueYellowCy = YELLOW_CY;

                    valueRedCx = RED_CX;
                    valueRedCy = RED_CY;

                    _Resultado = "TRUE";
                }
            }
            catch(Exception ex)
            {
                _Resultado = ex.Message;
            }

            return _Resultado;
        }








    }
}
