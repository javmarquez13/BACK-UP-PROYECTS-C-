﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JabilTest;

namespace TrilightHistory
{
    class SaveColorTest : JabilTest.Test
    {
        public SaveColorTest(ScriptVariableSpace varSpace, object otherParameters) : base(varSpace, otherParameters)
        {

        }

        public override TestResult Execute()
        {
            string _Result = string.Empty;
            string Tracer = this.GetObjectVariable("Argument0", "Name0").ToString().Replace("'", "");

            string LaneIntensity = this.GetObjectVariable("Argument1", "Name1").ToString().Replace("'", "");
            string LaneColorCX = this.GetObjectVariable("Argument2", "Name2").ToString().Replace("'", "");
            string LaneColorCY = this.GetObjectVariable("Argument3", "Name3").ToString().Replace("'", "");

            string GreenColorCX = this.GetObjectVariable("Argument4", "Name4").ToString().Replace("'", "");
            string GreenColorCY = this.GetObjectVariable("Argument5", "Name5").ToString().Replace("'", "");

            string YellowColorCX = this.GetObjectVariable("Argument6", "Name6").ToString().Replace("'", "");
            string YellowColorCY = this.GetObjectVariable("Argument7", "Name7").ToString().Replace("'", "");

            string RedColorCX = this.GetObjectVariable("Argument8", "Name8").ToString().Replace("'", "");
            string RedColorCY = this.GetObjectVariable("Argument9", "Name9").ToString().Replace("'", "");



            //Main
            _Result = SaveTestUnit(Tracer, LaneIntensity, LaneColorCX, LaneColorCY, GreenColorCX, GreenColorCY, YellowColorCX, YellowColorCY, RedColorCX, RedColorCY, "PASSED");


            ScriptVariable retVar0 = new ScriptVariable("ReturnValue0", VariableType.String, _Result);
            VariableSpace.setVariable(retVar0);
            testResult.Status = TestStatus.Pass;
            return testResult;
        }

        //Global variables
        XMLHistory _XMLHistory = new XMLHistory();


        string  SaveTestUnit
            (string TRACER, 

            string LaneIntensity, 
            string LaneColorCX, 
            string LaneColorCY, 

            string GreenColorCX,         
            string GreenColorCY,
            
            string YellowColorCX, 
            string YellowColorCY, 

            string RedColorCX, 
            string RedColorCY,
            string STATUS)
        {
            string _Resultado = string.Empty;

            try
            {
                _XMLHistory.SavePassedUnitColor(DateTime.Now, TRACER,
                                           LaneIntensity, 
                                           LaneColorCX, 
                                           LaneColorCY,                                            
                                           GreenColorCX, 
                                           GreenColorCY,
                                           YellowColorCX,
                                           YellowColorCY, 
                                           RedColorCX,
                                           RedColorCY,
                                           STATUS);

                _Resultado = TRACER + " Color test saved";
            }
            catch(Exception EX)
            {
                _Resultado = EX.Message;
            }
            return _Resultado;       
        }


        
    }
}
