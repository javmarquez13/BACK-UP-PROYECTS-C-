﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace School_manage
{
    class DEBUGAPP
    {
        StreamWriter _WriterLocal;
        string _ERRORFILE = @"C:\SCHOOL MANAGE\ERROR\ERROR_FILE.TXT";


        public void INSER_ERROR(DateTime DateTime)
        {
          
            try
            {
                //_WriterLocal.WriteLine(" * **********************************************************************************************************************");
                //_WriterLocal.WriteLine("");
                //_WriterLocal.WriteLine(DateTime.ToString().ToUpper());
                //_WriterLocal.WriteLine("UTT:" + UTT.ToUpper());
                //_WriterLocal.WriteLine("Module:" + Module.ToUpper());
                //_WriterLocal.WriteLine("Comentarios:" + Comments.ToUpper());
                //_WriterLocal.WriteLine("");
                //_WriterLocal.WriteLine("***********************************************************************************************************************");
                //_WriterLocal.WriteLine("");
                //_WriterLocal.WriteLine("");
                //_WriterLocal.WriteLine("");
                //_WriterLocal.Close();

            }

            catch (Exception ex)
            {

            }

        }

    }
}
