﻿namespace School_manage
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.materialTabSelector1 = new MaterialSkin.Controls.MaterialTabSelector();
            this.materialTabControl1 = new MaterialSkin.Controls.MaterialTabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label12 = new System.Windows.Forms.Label();
            this.cBoxViewStudents = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cBClass = new System.Windows.Forms.ComboBox();
            this.btnAttendance = new System.Windows.Forms.Button();
            this.dgvATTENDANCE = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lblGroupSelected = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbDate = new System.Windows.Forms.RadioButton();
            this.rbName = new System.Windows.Forms.RadioButton();
            this.txtQuery = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePickerEndDay = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerStartDay = new System.Windows.Forms.DateTimePicker();
            this.btnReload = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.dgvModifications = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btnDeleteStudent = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.cBoxSelectStudentToDelete = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.cBoxSelectGroupDeleteStudent = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.btnAddStudent = new System.Windows.Forms.Button();
            this.btnCreateGroup = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtCreateGroup = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtAddStudent = new System.Windows.Forms.TextBox();
            this.cBoxSelectGroupAddStudent = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.lblDate = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.lblPorciento = new MaterialSkin.Controls.MaterialLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pBoxGota1 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pBoxGota2 = new System.Windows.Forms.PictureBox();
            this.pBoxGota3 = new System.Windows.Forms.PictureBox();
            this.pBoxGota4 = new System.Windows.Forms.PictureBox();
            this.pBoxGota5 = new System.Windows.Forms.PictureBox();
            this.pBoxGota6 = new System.Windows.Forms.PictureBox();
            this.pBoxGota7 = new System.Windows.Forms.PictureBox();
            this.pBoxGota8 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pBcharco = new System.Windows.Forms.PictureBox();
            this.pBoxGota9 = new System.Windows.Forms.PictureBox();
            this.materialTabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvATTENDANCE)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvModifications)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxGota1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxGota2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxGota3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxGota4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxGota5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxGota6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxGota7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxGota8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBcharco)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxGota9)).BeginInit();
            this.SuspendLayout();
            // 
            // materialTabSelector1
            // 
            this.materialTabSelector1.BaseTabControl = this.materialTabControl1;
            this.materialTabSelector1.Depth = 0;
            this.materialTabSelector1.Location = new System.Drawing.Point(0, 99);
            this.materialTabSelector1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialTabSelector1.Name = "materialTabSelector1";
            this.materialTabSelector1.Size = new System.Drawing.Size(1656, 48);
            this.materialTabSelector1.TabIndex = 0;
            this.materialTabSelector1.Text = "materialTabSelector1";
            // 
            // materialTabControl1
            // 
            this.materialTabControl1.Controls.Add(this.tabPage1);
            this.materialTabControl1.Controls.Add(this.tabPage2);
            this.materialTabControl1.Controls.Add(this.tabPage3);
            this.materialTabControl1.Controls.Add(this.tabPage4);
            this.materialTabControl1.Controls.Add(this.tabPage5);
            this.materialTabControl1.Depth = 0;
            this.materialTabControl1.Location = new System.Drawing.Point(0, 153);
            this.materialTabControl1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialTabControl1.Name = "materialTabControl1";
            this.materialTabControl1.SelectedIndex = 0;
            this.materialTabControl1.Size = new System.Drawing.Size(1378, 611);
            this.materialTabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Controls.Add(this.lblPorciento);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Controls.Add(this.pictureBox4);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.cBoxViewStudents);
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.cBClass);
            this.tabPage1.Controls.Add(this.btnAttendance);
            this.tabPage1.Controls.Add(this.dgvATTENDANCE);
            this.tabPage1.Controls.Add(this.pBcharco);
            this.tabPage1.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1370, 578);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Attendance";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(8, 106);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(125, 21);
            this.label12.TabIndex = 18;
            this.label12.Text = "View Students:";
            // 
            // cBoxViewStudents
            // 
            this.cBoxViewStudents.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBoxViewStudents.FormattingEnabled = true;
            this.cBoxViewStudents.Location = new System.Drawing.Point(6, 134);
            this.cBoxViewStudents.Name = "cBoxViewStudents";
            this.cBoxViewStudents.Size = new System.Drawing.Size(282, 29);
            this.cBoxViewStudents.TabIndex = 17;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::School_manage.Properties.Resources.Tree;
            this.pictureBox1.Location = new System.Drawing.Point(240, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 40);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 21);
            this.label3.TabIndex = 15;
            this.label3.Text = "Select Group:";
            // 
            // cBClass
            // 
            this.cBClass.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBClass.FormattingEnabled = true;
            this.cBClass.Location = new System.Drawing.Point(6, 59);
            this.cBClass.Name = "cBClass";
            this.cBClass.Size = new System.Drawing.Size(282, 29);
            this.cBClass.TabIndex = 14;
            this.cBClass.SelectedIndexChanged += new System.EventHandler(this.cBClass_SelectedIndexChanged);
            // 
            // btnAttendance
            // 
            this.btnAttendance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(125)))), ((int)(((byte)(139)))));
            this.btnAttendance.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(125)))), ((int)(((byte)(139)))));
            this.btnAttendance.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAttendance.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAttendance.ForeColor = System.Drawing.Color.White;
            this.btnAttendance.Location = new System.Drawing.Point(6, 187);
            this.btnAttendance.Name = "btnAttendance";
            this.btnAttendance.Size = new System.Drawing.Size(282, 58);
            this.btnAttendance.TabIndex = 13;
            this.btnAttendance.Text = "Attendance";
            this.btnAttendance.UseVisualStyleBackColor = false;
            this.btnAttendance.Click += new System.EventHandler(this.btnAttendance_Click);
            // 
            // dgvATTENDANCE
            // 
            this.dgvATTENDANCE.AllowUserToAddRows = false;
            this.dgvATTENDANCE.AllowUserToDeleteRows = false;
            this.dgvATTENDANCE.AllowUserToResizeColumns = false;
            this.dgvATTENDANCE.AllowUserToResizeRows = false;
            this.dgvATTENDANCE.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvATTENDANCE.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvATTENDANCE.Location = new System.Drawing.Point(294, 8);
            this.dgvATTENDANCE.Name = "dgvATTENDANCE";
            this.dgvATTENDANCE.RowTemplate.Height = 28;
            this.dgvATTENDANCE.Size = new System.Drawing.Size(1058, 564);
            this.dgvATTENDANCE.TabIndex = 2;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.pictureBox2);
            this.tabPage2.Controls.Add(this.lblGroupSelected);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Controls.Add(this.txtQuery);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.dateTimePickerEndDay);
            this.tabPage2.Controls.Add(this.dateTimePickerStartDay);
            this.tabPage2.Controls.Add(this.btnReload);
            this.tabPage2.Controls.Add(this.btnUpdate);
            this.tabPage2.Controls.Add(this.dgvModifications);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1370, 578);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Data base";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::School_manage.Properties.Resources.Sun;
            this.pictureBox2.Location = new System.Drawing.Point(236, 8);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(46, 37);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 74;
            this.pictureBox2.TabStop = false;
            // 
            // lblGroupSelected
            // 
            this.lblGroupSelected.AutoSize = true;
            this.lblGroupSelected.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGroupSelected.Location = new System.Drawing.Point(72, 8);
            this.lblGroupSelected.Name = "lblGroupSelected";
            this.lblGroupSelected.Size = new System.Drawing.Size(158, 28);
            this.lblGroupSelected.TabIndex = 73;
            this.lblGroupSelected.Text = "Select group";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(8, 8);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 21);
            this.label5.TabIndex = 72;
            this.label5.Text = "Group: ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbDate);
            this.groupBox1.Controls.Add(this.rbName);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(6, 269);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(276, 67);
            this.groupBox1.TabIndex = 71;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Filter by:";
            // 
            // rbDate
            // 
            this.rbDate.AutoSize = true;
            this.rbDate.Location = new System.Drawing.Point(88, 37);
            this.rbDate.Name = "rbDate";
            this.rbDate.Size = new System.Drawing.Size(75, 25);
            this.rbDate.TabIndex = 1;
            this.rbDate.TabStop = true;
            this.rbDate.Text = "Date";
            this.rbDate.UseVisualStyleBackColor = true;
            // 
            // rbName
            // 
            this.rbName.AutoSize = true;
            this.rbName.Location = new System.Drawing.Point(6, 37);
            this.rbName.Name = "rbName";
            this.rbName.Size = new System.Drawing.Size(83, 25);
            this.rbName.TabIndex = 0;
            this.rbName.TabStop = true;
            this.rbName.Text = "Name";
            this.rbName.UseVisualStyleBackColor = true;
            // 
            // txtQuery
            // 
            this.txtQuery.Location = new System.Drawing.Point(6, 217);
            this.txtQuery.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtQuery.Name = "txtQuery";
            this.txtQuery.Size = new System.Drawing.Size(276, 26);
            this.txtQuery.TabIndex = 70;
            this.txtQuery.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQuery_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(8, 192);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 21);
            this.label4.TabIndex = 69;
            this.label4.Text = "Search:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 21);
            this.label2.TabIndex = 68;
            this.label2.Text = "End date:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 21);
            this.label1.TabIndex = 67;
            this.label1.Text = "Star date:";
            // 
            // dateTimePickerEndDay
            // 
            this.dateTimePickerEndDay.Location = new System.Drawing.Point(3, 150);
            this.dateTimePickerEndDay.Name = "dateTimePickerEndDay";
            this.dateTimePickerEndDay.Size = new System.Drawing.Size(279, 26);
            this.dateTimePickerEndDay.TabIndex = 66;
            // 
            // dateTimePickerStartDay
            // 
            this.dateTimePickerStartDay.Location = new System.Drawing.Point(3, 83);
            this.dateTimePickerStartDay.Name = "dateTimePickerStartDay";
            this.dateTimePickerStartDay.Size = new System.Drawing.Size(279, 26);
            this.dateTimePickerStartDay.TabIndex = 65;
            // 
            // btnReload
            // 
            this.btnReload.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(125)))), ((int)(((byte)(139)))));
            this.btnReload.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(125)))), ((int)(((byte)(139)))));
            this.btnReload.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReload.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReload.ForeColor = System.Drawing.Color.Transparent;
            this.btnReload.Location = new System.Drawing.Point(6, 357);
            this.btnReload.Name = "btnReload";
            this.btnReload.Size = new System.Drawing.Size(285, 53);
            this.btnReload.TabIndex = 19;
            this.btnReload.Text = "Load";
            this.btnReload.UseVisualStyleBackColor = false;
            this.btnReload.Click += new System.EventHandler(this.btnReload_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(125)))), ((int)(((byte)(139)))));
            this.btnUpdate.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(125)))), ((int)(((byte)(139)))));
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdate.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.ForeColor = System.Drawing.Color.Transparent;
            this.btnUpdate.Location = new System.Drawing.Point(6, 420);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(285, 53);
            this.btnUpdate.TabIndex = 18;
            this.btnUpdate.Text = "Save";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // dgvModifications
            // 
            this.dgvModifications.AllowUserToAddRows = false;
            this.dgvModifications.AllowUserToDeleteRows = false;
            this.dgvModifications.AllowUserToResizeColumns = false;
            this.dgvModifications.AllowUserToResizeRows = false;
            this.dgvModifications.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvModifications.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvModifications.Location = new System.Drawing.Point(294, 8);
            this.dgvModifications.Name = "dgvModifications";
            this.dgvModifications.RowTemplate.Height = 28;
            this.dgvModifications.Size = new System.Drawing.Size(989, 564);
            this.dgvModifications.TabIndex = 3;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.pictureBox3);
            this.tabPage3.Controls.Add(this.btnDeleteStudent);
            this.tabPage3.Controls.Add(this.groupBox4);
            this.tabPage3.Controls.Add(this.btnAddStudent);
            this.tabPage3.Controls.Add(this.btnCreateGroup);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.listView1);
            this.tabPage3.Controls.Add(this.groupBox3);
            this.tabPage3.Controls.Add(this.groupBox2);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1370, 578);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Manage Groups";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::School_manage.Properties.Resources.Brain;
            this.pictureBox3.Location = new System.Drawing.Point(455, 6);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(48, 47);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 80;
            this.pictureBox3.TabStop = false;
            // 
            // btnDeleteStudent
            // 
            this.btnDeleteStudent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(125)))), ((int)(((byte)(139)))));
            this.btnDeleteStudent.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(125)))), ((int)(((byte)(139)))));
            this.btnDeleteStudent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeleteStudent.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteStudent.ForeColor = System.Drawing.Color.Transparent;
            this.btnDeleteStudent.Location = new System.Drawing.Point(314, 415);
            this.btnDeleteStudent.Name = "btnDeleteStudent";
            this.btnDeleteStudent.Size = new System.Drawing.Size(119, 55);
            this.btnDeleteStudent.TabIndex = 79;
            this.btnDeleteStudent.Text = "Delete";
            this.btnDeleteStudent.UseVisualStyleBackColor = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.cBoxSelectStudentToDelete);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.cBoxSelectGroupDeleteStudent);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(12, 353);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(296, 175);
            this.groupBox4.TabIndex = 77;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Delete student in Group";
            // 
            // cBoxSelectStudentToDelete
            // 
            this.cBoxSelectStudentToDelete.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBoxSelectStudentToDelete.FormattingEnabled = true;
            this.cBoxSelectStudentToDelete.Location = new System.Drawing.Point(10, 120);
            this.cBoxSelectStudentToDelete.Name = "cBoxSelectStudentToDelete";
            this.cBoxSelectStudentToDelete.Size = new System.Drawing.Size(279, 29);
            this.cBoxSelectStudentToDelete.TabIndex = 77;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(6, 96);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(127, 21);
            this.label10.TabIndex = 76;
            this.label10.Text = "Student name:";
            // 
            // cBoxSelectGroupDeleteStudent
            // 
            this.cBoxSelectGroupDeleteStudent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBoxSelectGroupDeleteStudent.FormattingEnabled = true;
            this.cBoxSelectGroupDeleteStudent.Location = new System.Drawing.Point(10, 51);
            this.cBoxSelectGroupDeleteStudent.Name = "cBoxSelectGroupDeleteStudent";
            this.cBoxSelectGroupDeleteStudent.Size = new System.Drawing.Size(154, 29);
            this.cBoxSelectGroupDeleteStudent.TabIndex = 74;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(6, 27);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(114, 21);
            this.label11.TabIndex = 73;
            this.label11.Text = "Group name:";
            // 
            // btnAddStudent
            // 
            this.btnAddStudent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(125)))), ((int)(((byte)(139)))));
            this.btnAddStudent.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(125)))), ((int)(((byte)(139)))));
            this.btnAddStudent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddStudent.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddStudent.ForeColor = System.Drawing.Color.Transparent;
            this.btnAddStudent.Location = new System.Drawing.Point(314, 219);
            this.btnAddStudent.Name = "btnAddStudent";
            this.btnAddStudent.Size = new System.Drawing.Size(119, 55);
            this.btnAddStudent.TabIndex = 78;
            this.btnAddStudent.Text = "Add";
            this.btnAddStudent.UseVisualStyleBackColor = false;
            this.btnAddStudent.Click += new System.EventHandler(this.btnAddStudent_Click);
            // 
            // btnCreateGroup
            // 
            this.btnCreateGroup.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(125)))), ((int)(((byte)(139)))));
            this.btnCreateGroup.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(125)))), ((int)(((byte)(139)))));
            this.btnCreateGroup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCreateGroup.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateGroup.ForeColor = System.Drawing.Color.Transparent;
            this.btnCreateGroup.Location = new System.Drawing.Point(314, 59);
            this.btnCreateGroup.Name = "btnCreateGroup";
            this.btnCreateGroup.Size = new System.Drawing.Size(119, 55);
            this.btnCreateGroup.TabIndex = 77;
            this.btnCreateGroup.Text = "Create";
            this.btnCreateGroup.UseVisualStyleBackColor = false;
            this.btnCreateGroup.Click += new System.EventHandler(this.btnCreateGroup_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(509, 6);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 21);
            this.label6.TabIndex = 75;
            this.label6.Text = "Group view:";
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.listView1.GridLines = true;
            this.listView1.Location = new System.Drawing.Point(513, 32);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(770, 540);
            this.listView1.TabIndex = 76;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Group";
            this.columnHeader1.Width = 50;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "#";
            this.columnHeader2.Width = 40;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Name";
            this.columnHeader3.Width = 500;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtCreateGroup);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(8, 32);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(300, 102);
            this.groupBox3.TabIndex = 75;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Create new Group";
            // 
            // txtCreateGroup
            // 
            this.txtCreateGroup.Location = new System.Drawing.Point(10, 53);
            this.txtCreateGroup.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtCreateGroup.Name = "txtCreateGroup";
            this.txtCreateGroup.Size = new System.Drawing.Size(154, 27);
            this.txtCreateGroup.TabIndex = 74;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(6, 27);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(114, 21);
            this.label8.TabIndex = 73;
            this.label8.Text = "Group name:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.txtAddStudent);
            this.groupBox2.Controls.Add(this.cBoxSelectGroupAddStudent);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 157);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(296, 175);
            this.groupBox2.TabIndex = 73;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Add student in Group";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(6, 96);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(127, 21);
            this.label9.TabIndex = 76;
            this.label9.Text = "Student name:";
            // 
            // txtAddStudent
            // 
            this.txtAddStudent.Location = new System.Drawing.Point(10, 125);
            this.txtAddStudent.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtAddStudent.Name = "txtAddStudent";
            this.txtAddStudent.Size = new System.Drawing.Size(279, 27);
            this.txtAddStudent.TabIndex = 75;
            // 
            // cBoxSelectGroupAddStudent
            // 
            this.cBoxSelectGroupAddStudent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBoxSelectGroupAddStudent.FormattingEnabled = true;
            this.cBoxSelectGroupAddStudent.Location = new System.Drawing.Point(10, 51);
            this.cBoxSelectGroupAddStudent.Name = "cBoxSelectGroupAddStudent";
            this.cBoxSelectGroupAddStudent.Size = new System.Drawing.Size(154, 29);
            this.cBoxSelectGroupAddStudent.TabIndex = 74;
            this.cBoxSelectGroupAddStudent.SelectedIndexChanged += new System.EventHandler(this.cBoxSelectGroupAddStudent_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(6, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(114, 21);
            this.label7.TabIndex = 73;
            this.label7.Text = "Group name:";
            // 
            // tabPage4
            // 
            this.tabPage4.Location = new System.Drawing.Point(4, 29);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1370, 578);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "TASKS-JOURNAL";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabPage5
            // 
            this.tabPage5.Location = new System.Drawing.Point(4, 29);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1370, 578);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "SCHEDULE";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.BackColor = System.Drawing.Color.Transparent;
            this.lblDate.ForeColor = System.Drawing.Color.White;
            this.lblDate.Location = new System.Drawing.Point(12, 9);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(42, 20);
            this.lblDate.TabIndex = 2;
            this.lblDate.Text = "label";
            // 
            // timer1
            // 
            this.timer1.Interval = 25;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 5000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // lblPorciento
            // 
            this.lblPorciento.AutoSize = true;
            this.lblPorciento.Depth = 0;
            this.lblPorciento.Font = new System.Drawing.Font("Roboto", 11F);
            this.lblPorciento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblPorciento.Location = new System.Drawing.Point(120, 541);
            this.lblPorciento.MouseState = MaterialSkin.MouseState.HOVER;
            this.lblPorciento.Name = "lblPorciento";
            this.lblPorciento.Size = new System.Drawing.Size(40, 27);
            this.lblPorciento.TabIndex = 30;
            this.lblPorciento.Text = "0%";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pBoxGota9);
            this.panel1.Controls.Add(this.pBoxGota1);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.pBoxGota2);
            this.panel1.Controls.Add(this.pBoxGota3);
            this.panel1.Controls.Add(this.pBoxGota4);
            this.panel1.Controls.Add(this.pBoxGota5);
            this.panel1.Controls.Add(this.pBoxGota6);
            this.panel1.Controls.Add(this.pBoxGota7);
            this.panel1.Controls.Add(this.pBoxGota8);
            this.panel1.Location = new System.Drawing.Point(34, 362);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(225, 110);
            this.panel1.TabIndex = 28;
            // 
            // pBoxGota1
            // 
            this.pBoxGota1.Image = global::School_manage.Properties.Resources.rain_L;
            this.pBoxGota1.Location = new System.Drawing.Point(28, 34);
            this.pBoxGota1.Name = "pBoxGota1";
            this.pBoxGota1.Size = new System.Drawing.Size(10, 32);
            this.pBoxGota1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBoxGota1.TabIndex = 24;
            this.pBoxGota1.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.Location = new System.Drawing.Point(150, 73);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(75, 36);
            this.panel4.TabIndex = 8;
            // 
            // panel3
            // 
            this.panel3.Location = new System.Drawing.Point(0, 73);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(77, 36);
            this.panel3.TabIndex = 7;
            // 
            // pBoxGota2
            // 
            this.pBoxGota2.Image = global::School_manage.Properties.Resources.rain_L;
            this.pBoxGota2.Location = new System.Drawing.Point(51, 10);
            this.pBoxGota2.Name = "pBoxGota2";
            this.pBoxGota2.Size = new System.Drawing.Size(10, 27);
            this.pBoxGota2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBoxGota2.TabIndex = 6;
            this.pBoxGota2.TabStop = false;
            // 
            // pBoxGota3
            // 
            this.pBoxGota3.Image = global::School_manage.Properties.Resources.rain_L;
            this.pBoxGota3.Location = new System.Drawing.Point(79, 38);
            this.pBoxGota3.Name = "pBoxGota3";
            this.pBoxGota3.Size = new System.Drawing.Size(10, 32);
            this.pBoxGota3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBoxGota3.TabIndex = 5;
            this.pBoxGota3.TabStop = false;
            // 
            // pBoxGota4
            // 
            this.pBoxGota4.Image = global::School_manage.Properties.Resources.rain_L;
            this.pBoxGota4.Location = new System.Drawing.Point(104, 81);
            this.pBoxGota4.Name = "pBoxGota4";
            this.pBoxGota4.Size = new System.Drawing.Size(10, 27);
            this.pBoxGota4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBoxGota4.TabIndex = 4;
            this.pBoxGota4.TabStop = false;
            // 
            // pBoxGota5
            // 
            this.pBoxGota5.Image = global::School_manage.Properties.Resources.rain_L;
            this.pBoxGota5.Location = new System.Drawing.Point(123, 62);
            this.pBoxGota5.Name = "pBoxGota5";
            this.pBoxGota5.Size = new System.Drawing.Size(10, 25);
            this.pBoxGota5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBoxGota5.TabIndex = 3;
            this.pBoxGota5.TabStop = false;
            // 
            // pBoxGota6
            // 
            this.pBoxGota6.Image = global::School_manage.Properties.Resources.rain_L;
            this.pBoxGota6.Location = new System.Drawing.Point(139, 13);
            this.pBoxGota6.Name = "pBoxGota6";
            this.pBoxGota6.Size = new System.Drawing.Size(10, 20);
            this.pBoxGota6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBoxGota6.TabIndex = 2;
            this.pBoxGota6.TabStop = false;
            // 
            // pBoxGota7
            // 
            this.pBoxGota7.Image = global::School_manage.Properties.Resources.rain_L;
            this.pBoxGota7.Location = new System.Drawing.Point(156, 43);
            this.pBoxGota7.Name = "pBoxGota7";
            this.pBoxGota7.Size = new System.Drawing.Size(10, 27);
            this.pBoxGota7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBoxGota7.TabIndex = 1;
            this.pBoxGota7.TabStop = false;
            // 
            // pBoxGota8
            // 
            this.pBoxGota8.Image = global::School_manage.Properties.Resources.rain_L;
            this.pBoxGota8.Location = new System.Drawing.Point(176, 5);
            this.pBoxGota8.Name = "pBoxGota8";
            this.pBoxGota8.Size = new System.Drawing.Size(13, 25);
            this.pBoxGota8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBoxGota8.TabIndex = 0;
            this.pBoxGota8.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::School_manage.Properties.Resources.cloud;
            this.pictureBox4.Location = new System.Drawing.Point(6, 268);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(282, 88);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 26;
            this.pictureBox4.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(34, 477);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(225, 42);
            this.panel2.TabIndex = 27;
            // 
            // pBcharco
            // 
            this.pBcharco.Image = global::School_manage.Properties.Resources.puddle;
            this.pBcharco.Location = new System.Drawing.Point(34, 478);
            this.pBcharco.Name = "pBcharco";
            this.pBcharco.Size = new System.Drawing.Size(225, 42);
            this.pBcharco.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBcharco.TabIndex = 29;
            this.pBcharco.TabStop = false;
            // 
            // pBoxGota9
            // 
            this.pBoxGota9.Image = global::School_manage.Properties.Resources.rain_L;
            this.pBoxGota9.Location = new System.Drawing.Point(101, 21);
            this.pBoxGota9.Name = "pBoxGota9";
            this.pBoxGota9.Size = new System.Drawing.Size(10, 21);
            this.pBoxGota9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBoxGota9.TabIndex = 25;
            this.pBoxGota9.TabStop = false;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1387, 769);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.materialTabControl1);
            this.Controls.Add(this.materialTabSelector1);
            this.MaximizeBox = false;
            this.Name = "Main";
            this.Sizable = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SCHOOL MANAGE";
            this.Load += new System.EventHandler(this.Main_Load);
            this.materialTabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvATTENDANCE)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvModifications)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pBoxGota1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxGota2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxGota3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxGota4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxGota5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxGota6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxGota7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxGota8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBcharco)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxGota9)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MaterialSkin.Controls.MaterialTabSelector materialTabSelector1;
        private System.Windows.Forms.Label lblDate;
        private MaterialSkin.Controls.MaterialTabControl materialTabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cBClass;
        private System.Windows.Forms.Button btnAttendance;
        private System.Windows.Forms.DataGridView dgvATTENDANCE;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dgvModifications;
        private System.Windows.Forms.Button btnReload;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePickerEndDay;
        private System.Windows.Forms.DateTimePicker dateTimePickerStartDay;
        private System.Windows.Forms.TextBox txtQuery;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbName;
        private System.Windows.Forms.RadioButton rbDate;
        private System.Windows.Forms.Label lblGroupSelected;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnAddStudent;
        private System.Windows.Forms.Button btnCreateGroup;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtCreateGroup;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtAddStudent;
        private System.Windows.Forms.ComboBox cBoxSelectGroupAddStudent;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnDeleteStudent;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cBoxSelectGroupDeleteStudent;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cBoxSelectStudentToDelete;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cBoxViewStudents;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private MaterialSkin.Controls.MaterialLabel lblPorciento;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pBoxGota1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pBoxGota2;
        private System.Windows.Forms.PictureBox pBoxGota3;
        private System.Windows.Forms.PictureBox pBoxGota4;
        private System.Windows.Forms.PictureBox pBoxGota5;
        private System.Windows.Forms.PictureBox pBoxGota6;
        private System.Windows.Forms.PictureBox pBoxGota7;
        private System.Windows.Forms.PictureBox pBoxGota8;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pBcharco;
        private System.Windows.Forms.PictureBox pBoxGota9;
    }
}

