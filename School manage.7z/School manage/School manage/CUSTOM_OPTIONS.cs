﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace School_manage
{
    public partial class CUSTOM_OPTIONS : Form
    {
        public string _COMMENTS;
        Main Main = new Main();

        public CUSTOM_OPTIONS(string CurrentStudent)
        {           
            InitializeComponent();
            lblCurrentStudent.Text = CurrentStudent;
        }


        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cBtnPresent_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Yes;
            SendComments();
            this.Close();
        }

        private void circularButton1_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.No;
            SendComments();
            this.Close();
        }

        private void circularButton2_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Retry;
            SendComments();
            this.Close();
        }

        private void btnPresent_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Yes;
            SendComments();
            this.Close();
        }

        private void btnAbsent_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.No;
            SendComments();
            this.Close();
        }

        private void btnPending_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Retry;
            SendComments();
            this.Close();
        }

        void SendComments()
        {
            if(txtComments.Text == "Extra information....")
            {
                _COMMENTS = "";
            }

            else
            {
                _COMMENTS = txtComments.Text;
            }
        }

        private void CUSTOM_OPTIONS_Load(object sender, EventArgs e)
        {
            this.DesktopLocation = new Point(Screen.PrimaryScreen.WorkingArea.Width - this.Width, Screen.PrimaryScreen.WorkingArea.Height - this.Height); //970, 522
            btnPresent.Focus();
        }


    }
}
