﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace School_manage
{
    class Functions
    {

        string _Date = DateTime.Today.ToShortDateString();
        string _DirectorySM = @"c:\SCHOOL MANAGE\GROUPS\";
        string _DirectoryXML = @"c:\SCHOOL MANAGE\XML\";
        DataTable XMLtable;
        DataSet dataSet = new DataSet();
        DataTable dataTable = new DataTable();
        StreamWriter StreamWriter;


        public string InitializeFiles()
        {
            string _result;
            try
            {
                if (!Directory.Exists(_DirectorySM))
                {
                    Directory.CreateDirectory(_DirectorySM);
                    Directory.CreateDirectory(_DirectoryXML);
                }
            }
            catch (Exception)
            {

            }

            _result = _Date;
            return _result;
        }


        public string[] FillClass()
        {
            string[] _result = { "" };
            List<string> _list = new List<string>();
            DirectoryInfo directoryInfo = new DirectoryInfo(_DirectorySM);
            FileInfo[] archivos = directoryInfo.GetFiles("*.lis");

            try
            {
                foreach (FileInfo _file in archivos)
                {
                    _list.Add(_file.Name.Substring(0, 2));
                  //  cBClass.Items.Add(_file.Name.Substring(0, 2));
                }
            }

            catch (Exception ex)
            {
                
            }

            _result = _list.ToArray();
            return _result;
        }

        public List<string> FillStudents(string GROUP)
        {
            List<string> _Result = new List<string>();

            try
            {
                StreamReader reader = new StreamReader(_DirectorySM + GROUP + ".lis");

                while (!reader.EndOfStream)
                {
                    _Result.Add(reader.ReadLine());
                }
                reader.Close();
            }

            catch(Exception ex)
            {

            }
          
            return _Result;
        }


        public void CreateTable(string GROUP)
        {
            XMLtable = new DataTable("STUDENTS");

            if (File.Exists(_DirectoryXML + GROUP + ".xml"))
            {
                XMLtable = ReadXML(GROUP);
            }
            else
            {
                XMLtable.Columns.Add("DATE");
                XMLtable.Columns.Add("GROUP");
                XMLtable.Columns.Add("#");
                XMLtable.Columns.Add("STUDENT");
                XMLtable.Columns.Add("ATTENDANCE");
                XMLtable.Columns.Add("COMMENTS");
            }
            
            
        }

        public void AddInfoTable(DateTime DATE, string GROUP, int NUMBER, string STUDENTNAME, string ABSENT, string COMMENTS)
        {
            XMLtable.Rows.Add(DATE, GROUP, NUMBER, STUDENTNAME, ABSENT, COMMENTS);
        }


        public void CreateXML(string GROUP)
        {
            DataSet setXML = new DataSet(GROUP);
            setXML.Tables.Add(XMLtable);
            string XML = setXML.GetXml();
            File.WriteAllText(_DirectoryXML + GROUP + ".XML", XML);
        }


        public DataTable ReadXML(string GROUP)
        {
            try
            {
                dataSet.ReadXml(_DirectoryXML + GROUP + ".XML");
                dataTable = dataSet.Tables[0];
                dataSet.Tables.Clear();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return dataTable;
        }


        public void SaveXML(DataTable DT, string GROUP)
        {
            DT.WriteXml(_DirectoryXML + GROUP + ".XML");
        }


        public void CreateNewGorup(string GROUP)
        {         
            try
            {
                if(File.Exists(_DirectorySM + GROUP + ".lis"))
                {
                    MessageBox.Show("Group already exist, You can try modifying in manual mode", "Contact the administrator");
                }
                else
                {
                    StreamWriter = new StreamWriter(_DirectorySM + GROUP.ToUpper() + ".lis");
                    StreamWriter.Close();
                    MessageBox.Show(GROUP.ToUpper() + " Created successfully");
                }
               
            }
            catch (Exception ex)
            {

            }
        }

        public void AddStudent(string GROUP, string STUDENTNAME)
        {
            try
            {
                string StudentsByGroup = File.ReadAllText(_DirectorySM + GROUP.ToUpper() + ".lis");
                if (StudentsByGroup.Contains(STUDENTNAME.ToUpper()))
                {
                    MessageBox.Show("Student already exist in group, You can try modifying in manual mode", "Contact the administrator");
                }
                else
                {
                    StreamWriter = File.AppendText(_DirectorySM + GROUP.ToUpper() + ".lis");
                    StreamWriter.WriteLine(STUDENTNAME.ToUpper());
                    StreamWriter.Close();
                    MessageBox.Show(STUDENTNAME.ToUpper() + " Added successfully in Group " + GROUP.ToUpper());
                }
              
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }




    }
}
