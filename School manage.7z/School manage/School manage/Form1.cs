﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin.Controls;
using System.IO;
using System.Runtime.InteropServices;

namespace School_manage
{
    public partial class Main : MaterialForm
    {

        #region Efecto Lluvia

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(
              int left,
              int top,
              int right,
              int bottom,
              int width,
              int height
          );

        int[] rainSpeeds = { 4, 5, 6, 4, 5, 6, 7, 4, 6 };
        int loadingSpeed = 2;
        float initialPercentage = 0;

        #endregion


        public string _DialogResult;

        string _Date;
        int _ListNumber = 1;
        DateTime _DateTime = DateTime.Now;
        string[] _Classes;
        string _DirectorySM = @"c:\SCHOOL MANAGE\GROUPS\";
        StreamReader _SR;
        DataTable _dt = new DataTable();


        Image Good = School_manage.Properties.Resources.DGVGOOD;
        Image Bad = School_manage.Properties.Resources.DGVFAIL;
        Image Check = School_manage.Properties.Resources.DGVCHECK;

        Functions _FUNCIONES = new Functions();
        CUSTOM_OPTIONS _CUSTOMOPTIONS;

        public Main()
        {
            InitializeComponent();
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 7, 7));
            
            Design.MaterialStyle();
            _Date = _FUNCIONES.InitializeFiles();
            _Classes = _FUNCIONES.FillClass();


            Initialize();
            InitialDGV_ATTENDANCE();

        }


        void Initialize()
        {
            lblDate.Text = _Date;
            
            foreach(string _Class in _Classes)
            {
                cBClass.Items.Add(_Class);
                cBoxSelectGroupAddStudent.Items.Add(_Class);
                cBoxSelectGroupDeleteStudent.Items.Add(_Class);
            }        
        }

        void InitialDGV_ATTENDANCE()
        {
            dgvATTENDANCE.Columns.Add("date", "DATE");
            dgvATTENDANCE.Columns.Add("group", "GROUP");
            dgvATTENDANCE.Columns.Add("number", "#");
            dgvATTENDANCE.Columns.Add("student", "STUDENT");
            dgvATTENDANCE.Columns.Add("absent", "ATTENDANCE");
            dgvATTENDANCE.Columns.Add("comments", "COMMENTS");

            dgvATTENDANCE.Columns["date"].Width = 120;
            dgvATTENDANCE.Columns["group"].Width = 50;
            dgvATTENDANCE.Columns["number"].Width = 25;
            dgvATTENDANCE.Columns["student"].Width = 250;
            dgvATTENDANCE.Columns["absent"].Width = 80;
            dgvATTENDANCE.Columns["comments"].Width = 600;
            dgvATTENDANCE.RowHeadersVisible = false;


            dgvModifications.AutoGenerateColumns = true;
            //dgvModifications.Columns.Add("status", "Status");
            //dgvModifications.Columns.Add("date", "Date");
            //dgvModifications.Columns.Add("number", "#");
            //dgvModifications.Columns.Add("student", "StudentName");
            //dgvModifications.Columns.Add("absent", "Absent");
            //dgvModifications.Columns.Add("comments", "Comments");

            //dgvModifications.Columns["date"].Width = 125;
            //dgvModifications.Columns["number"].Width = 20;
            //dgvModifications.Columns["student"].Width = 250;
            //dgvModifications.Columns["absent"].Width = 70;
            //dgvModifications.Columns["comments"].Width = 400;
            //dgvModifications.RowHeadersVisible = false;
        }


        void FormatDataDGV()
        {
            dgvModifications.Columns["DATE"].Width = 120;
            dgvModifications.Columns["GROUP"].Width = 50;
            dgvModifications.Columns["#"].Width = 25;
            dgvModifications.Columns["STUDENT"].Width = 250;
            dgvModifications.Columns["ATTENDANCE"].Width = 80;
            dgvModifications.Columns["COMMENTS"].Width = 300;
        }

        private void btnAttendance_Click(object sender, EventArgs e)
        {
            _FUNCIONES.CreateTable(cBClass.Text); 
            dgvATTENDANCE.Rows.Clear();
            TAKE_ATTENDANCE();
            btnAttendance.Enabled = false;
        }


        void TAKE_ATTENDANCE()
        {
            string _SelectedClass = cBClass.Text;
            string _CurrentStudent = "";
            
            try
            {
                _SR = new StreamReader(_DirectorySM + _SelectedClass + ".lis");

                while (!_SR.EndOfStream)
                {
                    _CurrentStudent = _SR.ReadLine();
                    // DialogResult = MessageBox.Show(_CurrentStudent, "ABSENT?", MessageBoxButtons.YesNo);
                    CUSTOM_OPTIONS _ASK = new CUSTOM_OPTIONS(_CurrentStudent);
                    DialogResult = _ASK.ShowDialog();

                    if (DialogResult == DialogResult.Yes)
                    {
                        WriteDGV_ATTENDANCE(_DateTime, _CurrentStudent, "PRESENT", _ASK._COMMENTS);
                        _FUNCIONES.AddInfoTable(_DateTime, cBClass.Text, _ListNumber, _CurrentStudent, "PRESENT", _ASK._COMMENTS);
                    }

                    if (DialogResult == DialogResult.No)
                    {
                        WriteDGV_ATTENDANCE(_DateTime, _CurrentStudent, "ABSENT", _ASK._COMMENTS);
                        _FUNCIONES.AddInfoTable(_DateTime, cBClass.Text, _ListNumber, _CurrentStudent, "ABSENT", _ASK._COMMENTS);
                    }

                    if (DialogResult == DialogResult.Retry)
                    {
                        WriteDGV_ATTENDANCE(_DateTime, _CurrentStudent, "PENDING", _ASK._COMMENTS);
                        _FUNCIONES.AddInfoTable(_DateTime, cBClass.Text, _ListNumber, _CurrentStudent, "PENDING", _ASK._COMMENTS);
                    }

                    _ListNumber = _ListNumber + 1;
                }

                _FUNCIONES.CreateXML(cBClass.Text);

                _ListNumber = 1;

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void QUERY()
        {
            string sQuery = txtQuery.Text;
            //dgvModifications.RowHeadersVisible = false;
            DataTable Data = _FUNCIONES.ReadXML(cBClass.Text);
            DataView dv = new DataView(Data);

            try
            {
                if (rbDate.Checked)
                {
                    dv.RowFilter = "(date >= #" + dateTimePickerStartDay.Value.Date + "# And date <= #" + dateTimePickerEndDay.Value.Date + "# )";
                    dgvModifications.DataSource = dv.ToTable();
                }

                if (rbName.Checked)
                {
                    dv.RowFilter = "student  LIKE '%" + sQuery + "%'";
                    dgvModifications.DataSource = dv.ToTable();
                }

            }
            catch(Exception ex)
            {

            }
        }

        void WriteDGV_ATTENDANCE(DateTime date, string StudentName, string ABSENT, string Comments)
        {
            //int icIndex = dgvFailures.Columns.Add(imgCol);
            //dgvFailures.Columns[icIndex].Name = "image";
            try
            {
                if (ABSENT == "ABSENT")
                {
                    dgvATTENDANCE.Rows.Add(new Object[]
                     {
                          date, cBClass.Text, _ListNumber, StudentName, ABSENT, Comments
                     });


                    dgvATTENDANCE.Rows[dgvATTENDANCE.Rows.Count - 1].DefaultCellStyle.BackColor = Color.PaleVioletRed;
                    dgvATTENDANCE.CurrentCell = dgvATTENDANCE.Rows[dgvATTENDANCE.Rows.Count - 1].Cells[0];
                    this.Update();
                }

                if (ABSENT == "PRESENT")
                {
                    dgvATTENDANCE.Rows.Add(new Object[]
                     {
                           date, cBClass.Text, _ListNumber, StudentName, ABSENT, Comments
                     });

                    dgvATTENDANCE.Rows[dgvATTENDANCE.Rows.Count - 1].DefaultCellStyle.BackColor = Color.LightGreen;
                    dgvATTENDANCE.CurrentCell = dgvATTENDANCE.Rows[dgvATTENDANCE.Rows.Count - 1].Cells[0];
                    this.Update();
                }

                if (ABSENT == "PENDING")
                {
                    dgvATTENDANCE.Rows.Add(new Object[]
                     {
                           date, cBClass.Text, _ListNumber, StudentName, ABSENT, Comments
                     });


                    dgvATTENDANCE.Rows[dgvATTENDANCE.Rows.Count - 1].DefaultCellStyle.BackColor = Color.LightBlue;
                    dgvATTENDANCE.CurrentCell = dgvATTENDANCE.Rows[dgvATTENDANCE.Rows.Count - 1].Cells[0];
                    this.Update();
                }

            }


            catch (Exception ex)
            {
                dgvATTENDANCE.Rows.Add(new Object[]
                     {
                         /*CADD_ANALISIS.Properties.Resources.DGVFAIL,*/ date, "Application log", ex.Message
                     });

                dgvATTENDANCE.Rows[dgvATTENDANCE.Rows.Count - 1].DefaultCellStyle.BackColor = Color.PaleVioletRed;
                dgvATTENDANCE.CurrentCell = dgvATTENDANCE.Rows[dgvATTENDANCE.Rows.Count - 1].Cells[0];             
                this.Update();
            }
        }


        private void btnReload_Click(object sender, EventArgs e)
        {
            try
            {
                MessageBox.Show("UPLOAD RECORDS FROM GROUP: " + cBClass.Text, "GROUP " + cBClass.Text);
                _dt = _FUNCIONES.ReadXML(cBClass.Text);
                dgvModifications.DataSource = _dt;
                dgvModifications.Refresh();
                FormatDataDGV();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            DialogResult = MessageBox.Show("ARE YOU SURE THAT WANT SAVE THE CHANGES?", "ARE YOU SURE?", MessageBoxButtons.YesNo);

            if(DialogResult == DialogResult.Yes)
            {
                _FUNCIONES.SaveXML(_dt, cBClass.Text);
                MessageBox.Show("CHANGES SAVED SUCCESSFULLY", "SAVING CHANGES...");
                _dt = _FUNCIONES.ReadXML(cBClass.Text);
                dgvModifications.DataSource = _dt;
                dgvModifications.Refresh();
                FormatDataDGV();
            }
        }


        private void txtQuery_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((int)e.KeyChar == (int)Keys.Enter)
            {
                QUERY();
            }
        }

        private void cBClass_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblGroupSelected.Text = cBClass.Text;
            List<string> Students = new List<string>();
            Students =  _FUNCIONES.FillStudents(cBClass.Text);

            cBoxViewStudents.Items.Clear();
            foreach(string Student in Students)
            {
                cBoxViewStudents.Items.Add(Student);
            }
        }

        private void btnCreateGroup_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtCreateGroup.Text != "")
                {
                    _FUNCIONES.CreateNewGorup(txtCreateGroup.Text);
                    txtCreateGroup.ResetText();

                    _Classes = _FUNCIONES.FillClass();
                    cBClass.Items.Clear();
                    cBoxSelectGroupAddStudent.Items.Clear();
                    cBoxSelectGroupDeleteStudent.Items.Clear();
                    foreach (string _Class in _Classes)
                    {
                        cBClass.Items.Add(_Class);
                        cBoxSelectGroupAddStudent.Items.Add(_Class);
                        cBoxSelectGroupDeleteStudent.Items.Add(_Class);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "CONTACT THE ADMINISTRATOR");
            }
        }


        private void btnAddStudent_Click(object sender, EventArgs e)
        {
            _FUNCIONES.AddStudent(cBoxSelectGroupAddStudent.Text, txtAddStudent.Text);
            fillListView();
            txtAddStudent.ResetText();
        }


        void fillListView()
        {
            listView1.Items.Clear();
            List<string> _list = new List<string>();
            _list = _FUNCIONES.FillStudents(cBoxSelectGroupAddStudent.Text);
            int n = 1;
            try
            {
                foreach(string student in _list)
                {
                    ListViewItem viewItem = new ListViewItem(cBoxSelectGroupAddStudent.Text);
                    viewItem.SubItems.Add(n.ToString());
                    viewItem.SubItems.Add(student);
                    listView1.Items.Add(viewItem);

                    n = n + 1;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cBoxSelectGroupAddStudent_SelectedIndexChanged(object sender, EventArgs e)
        {
            fillListView();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            for (int i = 0; i < 9; i++)
            {
                switch (i)
                {
                    case 0:
                        //animation for rain 1
                        pBoxGota1.Location = new Point(pBoxGota1.Location.X, pBoxGota1.Location.Y + rainSpeeds[i]);
                        if (pBoxGota1.Location.Y > panel1.Size.Height + pBoxGota1.Size.Height)
                        {
                            pBoxGota1.Location = new Point(pBoxGota1.Location.X, 0 - pBoxGota1.Size.Height);
                        }
                        break;
                    case 1:
                        //animation for rain 2
                        pBoxGota2.Location = new Point(pBoxGota2.Location.X, pBoxGota2.Location.Y + rainSpeeds[i]);
                        if (pBoxGota2.Location.Y > panel1.Size.Height + pBoxGota2.Size.Height)
                        {
                            pBoxGota2.Location = new Point(pBoxGota2.Location.X, 0 - pBoxGota2.Size.Height);
                        }
                        break;
                    case 2:
                        //animation for rain 3
                        pBoxGota3.Location = new Point(pBoxGota3.Location.X, pBoxGota3.Location.Y + rainSpeeds[i]);
                        if (pBoxGota3.Location.Y > panel1.Size.Height + pBoxGota3.Size.Height)
                        {
                            pBoxGota3.Location = new Point(pBoxGota3.Location.X, 0 - pBoxGota3.Size.Height);
                        }
                        break;
                    case 3:
                        //animation for rain 4
                        pBoxGota4.Location = new Point(pBoxGota4.Location.X, pBoxGota4.Location.Y + rainSpeeds[i]);
                        if (pBoxGota4.Location.Y > panel1.Size.Height + pBoxGota4.Size.Height)
                        {
                            pBoxGota4.Location = new Point(pBoxGota4.Location.X, 0 - pBoxGota4.Size.Height);
                        }
                        break;
                    case 4:
                        //animation for rain 5
                        pBoxGota5.Location = new Point(pBoxGota5.Location.X, pBoxGota5.Location.Y + rainSpeeds[i]);
                        if (pBoxGota5.Location.Y > panel1.Size.Height + pBoxGota5.Size.Height)
                        {
                            pBoxGota5.Location = new Point(pBoxGota5.Location.X, 0 - pBoxGota5.Size.Height);
                        }
                        break;
                    case 5:
                        //animation for rain 6
                        pBoxGota6.Location = new Point(pBoxGota6.Location.X, pBoxGota6.Location.Y + rainSpeeds[i]);
                        if (pBoxGota6.Location.Y > panel1.Size.Height + pBoxGota6.Size.Height)
                        {
                            pBoxGota6.Location = new Point(pBoxGota6.Location.X, 0 - pBoxGota6.Size.Height);
                        }
                        break;
                    case 6:
                        //animation for rain 7
                        pBoxGota7.Location = new Point(pBoxGota7.Location.X, pBoxGota7.Location.Y + rainSpeeds[i]);
                        if (pBoxGota7.Location.Y > panel1.Size.Height + pBoxGota7.Size.Height)
                        {
                            pBoxGota7.Location = new Point(pBoxGota7.Location.X, 0 - pBoxGota7.Size.Height);
                        }
                        break;
                    case 7:
                        //animation for rain 8
                        pBoxGota8.Location = new Point(pBoxGota8.Location.X, pBoxGota8.Location.Y + rainSpeeds[i]);
                        if (pBoxGota8.Location.Y > panel1.Size.Height + pBoxGota8.Size.Height)
                        {
                            pBoxGota8.Location = new Point(pBoxGota8.Location.X, 0 - pBoxGota8.Size.Height);
                        }
                        break;
                    case 8:
                        //animation for rain 9
                        pBoxGota9.Location = new Point(pBoxGota9.Location.X, pBoxGota9.Location.Y + rainSpeeds[i]);
                        if (pBoxGota9.Location.Y > panel1.Size.Height + pBoxGota9.Size.Height)
                        {
                            pBoxGota9.Location = new Point(pBoxGota9.Location.X, 0 - pBoxGota9.Size.Height);
                        }
                        break;
                }
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            initialPercentage += loadingSpeed;
            float percentage = initialPercentage / pBcharco.Height * 100;

            lblPorciento.Text = (int)percentage + " %";

            panel2.Location = new Point(panel2.Location.X, panel2.Location.Y + loadingSpeed);
            if (panel2.Location.Y > pBcharco.Location.Y + pBcharco.Height)
            {
                lblPorciento.Text = "100 %";
                this.timer2.Stop();
            }
        }

        private void Main_Load(object sender, EventArgs e)
        {
            timer1.Start();
            timer2.Start();
        }
    }
}
