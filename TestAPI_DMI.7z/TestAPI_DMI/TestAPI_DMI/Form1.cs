﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace TestAPI_DMI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string _APIUrl = @"http://mxchim0web12:8087/iFactoryCustomReportAPI/api/Wips/Get_WipInformationMonitor/";

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {

            //tovalidate = 57-55600516

            if (e.KeyCode == Keys.Enter)
            {
               InfoUnit _infoUnit = GETJson(_APIUrl + textBox1.Text);
               IList<Data> _data;
               _data = _infoUnit._data;
                label1.Text = _data[0].SerialNumber;
                label2.Text = _data[0].Material444;
                label3.Text = _data[0].Serial.Substring(0,11);
                label4.Text = _data[0].MPN;
                label5.Text = _data[0].MC;
                textBox1.Clear();

                int dataInt = _data[0].MPN.Length;
            }
        }


        InfoUnit GETJson(string API)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(API);
            try
            {
                WebResponse response = request.GetResponse();
                using (Stream responseStream = response.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(responseStream, System.Text.Encoding.UTF8);
                    string json = reader.ReadToEnd();
                    InfoUnit _infoUnit = JsonConvert.DeserializeObject<InfoUnit>(json);
                    return _infoUnit;
                }
            }
            catch (WebException ex)
            {
                WebResponse errorResponse = ex.Response;
                using (Stream responseStream = errorResponse.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(responseStream, System.Text.Encoding.GetEncoding("utf-8"));
                    String errorText = reader.ReadToEnd();
                }
                throw;
            }
        }


        public class InfoUnit
        {
            public int _code { get; set; }
            public string _message { get; set; }
            public string _eventID { get; set; }
            public IList<Data> _data { get; set; }
            public bool _success { get; set; }
            public bool _fail { get; set; }
            public bool _warining { get; set; }
            public string _messageDetails { get; set; }

            public InfoUnit()
            {
                this._code = 0;
                this._data = null;
                this._eventID = null;
                this._fail = false;
                this._message = null;
                this._messageDetails = null;
                this._success = false;
                this._warining = false;
            }
        }

        public class Data
        {
            public string SerialNumber { get; set; }
            public string Material444 { get; set; }
            public string MC { get; set; }
            public string Serial { get; set; }
            public string MPN { get; set; }

            public Data()
            {
                this.SerialNumber = null;
                this.Material444 = null;
                this.MC = null;
                this.Serial = null;
                this.MPN = null;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                FileStream _stream = File.Open(@"C:\Mavis\10059617.ejl", FileMode.Open);
                System.Threading.Thread.Sleep(50);
                _stream.Dispose();
                _stream.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        
        }

        FileStream _stream_;
        private void button3_Click(object sender, EventArgs e)
        {
           _stream_ = File.Open(@"C:\Mavis\10059617.ejl", FileMode.Open);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            _stream_.Dispose();
            _stream_.Close();
        }
    }
}
