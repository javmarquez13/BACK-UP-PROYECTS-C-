﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace USBDeviceNCRChecker
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            int count = 0;

            repeat:
            bool isOwned = false;

            System.Threading.Mutex appStartMutex = new System.Threading.Mutex(true, Application.ProductName, out isOwned);
            if (!isOwned)
            {
                if (count < 50)
                {
                    System.Threading.Thread.Sleep(100);
                    count++;
                    goto repeat;
                }
                MessageBox.Show("Una instancia del programa ya esta siendo ejecutada, verifique y cierre primero esta instancia antes de continuar", "Same Thread Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }

            Application.Run(new frmMainUI());
        }
    }
}
