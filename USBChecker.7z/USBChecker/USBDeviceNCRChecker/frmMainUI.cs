﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using NativeUsbLib;
using System.IO;
using System.Management;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.ServiceProcess;

namespace USBDeviceNCRChecker
{
    public partial class frmMainUI : Form
    {
        public static bool allUSB = false;
        public static bool allService = false;
        bool corePress = false;
        //private static int _nestLevel;
        string xmlFileName = "";
        // public static StreamWriter sw;
        DataTable dtDevices = new DataTable();
        DataTable dtRequestUSB = new DataTable();
        DataTable dtResultUSB = new DataTable();
        DataTable dtLastDevicesConnected = new DataTable();
        StreamWriter sw;
        public static string userClose = "NCRChecker";
        public static string userComment = "";
        DateTime lastRequestFile = DateTime.Now;
        bool RequestedFile = false;
        bool firstCheck = true;
        string LogFolderPath = "";

        string AppFolder = @"C:\Pangaea\ExternalExecutables\USBDeviceNCRChecker\";
        string programRute;

        private string sServer = @"MXCHIM0SQLV03B\INST1";
        private string sDataBase = "TestGroup";
        public frmMainUI()
        {
            InitializeComponent();
        }

        private void frmMainUI_Load(object sender, EventArgs e)
        {
            string mapping = "";
            DataSet BuiltType = new DataSet();
            DataSet Mapping = new DataSet();  
            try
            {
                BuiltType = ReadBuiltType(out mapping);

                try
                {
                    Mapping = ReadMappíng(mapping);
                    GetRequestUSB(BuiltType, Mapping);

                    CloseProgram("PangaeaFinancial");  // "POWERPNT"           //wait until is open an next close
                    //AppFolder = Application.StartupPath;
                    programRute = Path.Combine(AppFolder, @"UsbTreeView.exe");
                    xmlFileName = Path.Combine(AppFolder, @"UsbTreeView_report.xml");

                    if (File.Exists(xmlFileName))
                    {
                        File.Delete(xmlFileName);
                        RequestedFile = false;
                    }

                    VerifyUSBs();
                    //RunRepair();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("No se pudo obtener informacion de usb requeridos, " + ex);
                    corePress = true;
                    allUSB = true;
                    allService = true;
                    Close();
                }

            }
            catch (Exception ex)
            {
                corePress = true;
                allUSB = true;
                allService = true;
                Close();
            }
            this.Text = "USBDeviceNCRChecker " + ProductVersion;
            //dgvDevicesFVT.Visible = true;
               dgvDevicesFVT.Visible = false;


        }

        private void tmrCheckAgain_Tick(object sender, EventArgs e)
        {
            tmrCheckAgain.Enabled = false;
            VerifyUSBs();

            if (allUSB)
            {
                if (!allService)
                {
                    lblRunning.Visible = false;
                    lblComplete.Visible = true;
                    // MessageBox.Show("Todos los dispositivos USB del BuildType encontrados,faltan servicios se reiniciará Windows para cargar correctamente servicios");
                    frmResetCountDown countDown = new frmResetCountDown();
                    countDown.ShowDialog();

                    Process.Start("shutdown", "/r /t 0"); // the argument /r is to restart the computer
                }
                else
                {
                    lblRunning.Visible = false;
                    lblComplete.Visible = true;
                    //MessageBox.Show("Todos los dispositivos USB del BuildType encontrados, se cerrara USBDeviceNCRChecker y se abrira Pangea");
                    frmComment AddComment = new frmComment();
                    AddComment.ShowDialog();
                    WriteLog(false);
                    deleteStartup();
                    RunPangea();
                }
                Close();
            }
            else
            {
                tmrCheckAgain.Enabled = true;
            }

        }

        //////////////////////////////////////////////////forma archivo/////////////////////////////


        private void VerifyUSBs()
        {
            if (lastRequestFile < DateTime.Now.AddSeconds(-15) || RequestedFile == false)
            {
                CrateFileUSBInfo();
            }
            if (File.Exists(xmlFileName))
            {

                System.IO.FileInfo info = new System.IO.FileInfo(xmlFileName);
                if (info.Attributes == System.IO.FileAttributes.Archive)
                {

                    File.GetAccessControl(xmlFileName);
                    dtDevices = new DataTable();
                    dtDevices.Columns.Add("DeviceDescription");
                    dtDevices.Columns.Add("DeviceName");
                    dtDevices.Columns.Add("DeviceidProduct");
                    dtDevices.Columns.Add("DeviceidVendor");
                    dtDevices.Columns.Add("DevicePortNumber");
                    dtDevices.Columns.Add("PortChain");
                    dtDevices.Columns.Add("DeviceInterfaceDesc");
                    dtDevices.Columns.Add("hubDeviceDescription");
                    dtDevices.Columns.Add("hubName");
                    dtDevices.Columns.Add("HubType");


                    int indexDevice = 0;
                    char[] delimiter = { ';' };
                    char[] delimiter2 = { ':' };
                    string[] Lines;
                    string Description = "";
                    string vId = "";
                    string pId = "";
                    string Port = "";
                    string PortChain = "";
                    string stringDescriptor = "";
                    bool isNextPid = false;
                    bool isNextStringDescriptor = false;

                    try
                    {

                        Lines = File.ReadAllLines(xmlFileName);

                        foreach (string Line in Lines)
                        {
                            if (!Line.Contains("= USB Device =") || !Line.Contains("(Device is connected)"))                  //= USB Hub =        //   HubType : USB 2.0 Hub    //     Device Description  : Generic USB Hub   //   Device Description : Generic USB Hub              Friendly Name
                                continue;
                            Description = "";
                            vId = "";
                            pId = "";
                            Port = "";
                            PortChain = "";
                            stringDescriptor = "";
                            isNextPid = false;
                            isNextStringDescriptor = false;
                            string[] Properties = Line.Split(delimiter);
                            foreach (string property in Properties)
                            {
                                if (!isNextPid && !isNextStringDescriptor)
                                {
                                    if (!Line.Contains(":"))
                                        continue;
                                    string[] parts = property.Split(delimiter2);
                                    if (parts[0].Trim() == "Device Description")
                                    {
                                        Description = parts[1].Trim();
                                        continue;
                                    }
                                    if (parts[0].Trim() == "Device Path")  //string para pid y vid          Device Path              : \\?\usb#vid_8087&amp;pid_0a2b#5&amp;
                                    {
                                        vId = parts[1].Trim();
                                        vId = vId.Substring(vId.IndexOf('_') + 1);
                                        vId = vId.Substring(0, 4);
                                        isNextPid = true;
                                        continue;
                                    }
                                    if (parts[0].Trim() == "Port Chain")     //   Port Chain  1-4   hub-puerto
                                    {
                                        Port = parts[1].Trim();
                                        continue;
                                    }
                                    if (parts[0].Trim() == "Language 0x0409")     //  string Descriptor
                                    {
                                        isNextStringDescriptor = true;
                                        continue;
                                    }
                                }
                                else
                                {
                                    if (isNextPid == true)
                                    {
                                        if (property.Contains("pid"))
                                        {
                                            pId = property;
                                            pId = pId.Substring(pId.IndexOf('_') + 1);
                                            pId = pId.Substring(0, 4);
                                        }
                                        isNextPid = false;
                                    }
                                    else
                                    {
                                        if (stringDescriptor == "")
                                        {
                                            stringDescriptor = property;
                                        }
                                        else
                                        {
                                            stringDescriptor += "|" + property;
                                        }
                                        isNextStringDescriptor = false;
                                    }

                                }
                            }

                            try
                            {
                                Description = Description.Replace("&#xD", "");

                                stringDescriptor = stringDescriptor.Replace("&quot", "");
                                if (Port.Contains('-'))
                                {
                                    PortChain = Port.Replace("&#xD", "");
                                    Port = PortChain.Substring(PortChain.LastIndexOf('-') + 1);
                                }

                            }
                            catch { }
                            dtDevices.Rows.Add();
                            dtDevices.Rows[indexDevice]["DeviceDescription"] = Description;
                            dtDevices.Rows[indexDevice]["DeviceName"] = Description;
                            dtDevices.Rows[indexDevice]["DeviceidProduct"] = pId.ToUpper();
                            dtDevices.Rows[indexDevice]["DeviceidVendor"] = vId.ToUpper();
                            dtDevices.Rows[indexDevice]["DevicePortNumber"] = Port;
                            dtDevices.Rows[indexDevice]["PortChain"] = PortChain;
                            dtDevices.Rows[indexDevice]["DeviceInterfaceDesc"] = stringDescriptor;
                            dtDevices.Rows[indexDevice]["hubDeviceDescription"] = "";
                            dtDevices.Rows[indexDevice]["hubName"] = "";
                            dtDevices.Rows[indexDevice]["HubType"] = "";

                            indexDevice++;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                    if (File.Exists(xmlFileName))
                    {
                        File.Delete(xmlFileName);
                        RequestedFile = false;
                    }

                    if (!IsTablesEqual(dtResultUSB, CheckDevicesUsb(dtDevices)))
                    {
                        dtResultUSB = CheckDevicesUsb(dtDevices).Copy();
                    
                        if (IsDifferentPortChain()) { }
                        dgvDevicesFVT.DataSource = dtResultUSB;
                        dgvDevicesFVT.Update();
                        dgvDevicesFVT.RowHeadersVisible = false;
                        dgvDevicesFVT.Refresh();
                        PaintDataGridResult();
                        dtLastDevicesConnected = dtDevices.Copy();
                    }
                }
                else
                {
                    //  MessageBox.Show(info.Attributes.ToString());
                }
            }
        }
        public bool IsTablesEqual(DataTable dt1, DataTable dt2)
        {
            int i = 0;
            try
            {
                if(dt1.Rows.Count != dt2.Rows.Count)
                {
                    return false;
                }
                for (i = 0; i < dt1.Rows.Count; i++)
                {
                    if (dt1.Rows[i]["Status"].ToString() != dt2.Rows[i]["Status"].ToString())
                    {
                        return false;
                    }
                    /*if (dt1.Rows[i]["portchain"].ToString() != dt2.Rows[i]["portchain"].ToString())
                    {
                        
                        return false;
                    }*/

                }
            }
            catch
            {
                return false;
            }
            return true;
        }
        private bool IsUsbListModify(DataTable dtDevices)
        {
            int count;
            try
            {
                for (count = 0; count < dtDevices.Rows.Count; count++)
                {
                  
                    if (dtDevices.Rows[count]["DeviceidProduct"].ToString() != dtLastDevicesConnected.Rows[count]["DeviceidProduct"].ToString() || dtDevices.Rows[count]["DeviceidVendor"].ToString() != dtLastDevicesConnected.Rows[count]["DeviceidVendor"].ToString() || dtDevices.Rows[count]["DevicePortNumber"].ToString() != dtLastDevicesConnected.Rows[count]["DevicePortNumber"].ToString())
                   {
                        
                        return true;
                    }
                }

            }
            catch
            {
                return true;
            }
            return false;
        }
        private bool IsDifferentPortChain()
        {
            int count;
            bool boolportchain = true;
            try
            {
                for (count = 0; count < dtResultUSB.Rows.Count; count++)
                {
                    if (dtResultUSB.Rows[count]["PortChain"].ToString() != dtLastDevicesConnected.Rows[count]["PortChain"].ToString())
                    {
                        dtResultUSB.Rows[count]["Status"] = "Check portchain";
                        dtResultUSB.AcceptChanges();
                        allService = false;
                        boolportchain = true;                        
                    }
                 
                }
                if (boolportchain) { return true;}
                else
                {
                    return false;
                }
                
            }
            catch
            {
                return true;
            }
            return false;
        }
        private DataSet ReadBuiltType(out string mapping)
        {
            DataSet Buildtype = new DataSet();
            DataTable Service = new DataTable("Service");
            Service.Columns.Add("Name");
            string[] lines;
            mapping = "";

            if (File.Exists(@"C:\build.typ"))
            {
                lines = File.ReadAllLines(@"C:\build.typ");
                mapping = lines[1].Split(':')[1];    //"6684";                            //cambiar a seleccion por archivo

                for (int CountBuild = 2; CountBuild < lines.Length; CountBuild++)
                {
                    Service.Rows.Add();
                    Service.Rows[CountBuild-2]["Name"] = lines[CountBuild].Split(':',';')[0].Trim();
                }
                Buildtype.Tables.Add(Service);
            }
            //string folderBuildtype = @"C:\Pangaea";
            // string[] filesInDir = Directory.GetFiles(folderBuildtype, "*.xml");
            //string builtypeName = "";
            //foreach (string file in filesInDir)
            //{
            //    if (file.Contains("BuildType"))
            //    {
            //        builtypeName = file;
            //        break;
            //    }

            //}

            //Buildtype.ReadXml(builtypeName);
            //mapping = Buildtype.Tables["BuildType"].Rows[0]["ClassID"].ToString();    //"6684";                            //cambiar a seleccion por archivo

            return Buildtype;
        }
        private DataSet ReadMappíng(string mapping)
        {
            DataSet ReadMappíng = new DataSet();
            int num = (int)ReadMappíng.ReadXml(Path.Combine("\\\\mxchim0pangea01\\diskbld\\USBMapping", mapping + "Mapping.xml"));

            // DataSet ReadMappíng = new DataSet();

            //  ReadMappíng.ReadXml(Path.Combine(@"\\mxchim0pangea01\diskbld\USBMapping", mapping + "USBMapping.xml"));   //debug: descomentar para uso normal

            ////ReadMappíng.ReadXml(Path.Combine(@"C:\Pangaea", mapping + "Mapping.xml"));                               //debug: comentar para uso normal

            // /*
            // if (mapping == "6684")
            // {
            //     ReadMappíng.ReadXml(Path.Combine(@"\\mxchim0pangea01\diskbld\USBMapping", @"6684Mapping.xml"));
            // }
            // else if(mapping == "6688")
            // {
            //     ReadMappíng.ReadXml(Path.Combine(@"\\mxchim0pangea01\diskbld\USBMapping", @"6688Mapping.xml"));
            // }
            // else
            // {
            //     ReadMappíng.ReadXml(Path.Combine(@"\\mxchim0pangea01\diskbld\USBMapping", mapping + "Mapping.xml"));
            // }
            // */
            return ReadMappíng;
        }
     

        private void GetRequestUSB(DataSet BuildType, DataSet Mapping)
        {
            try
            {
                dtRequestUSB = Mapping.Tables["DevicePort"].Clone();
                string buildItemToCheck = "";
                DataRow[] rowMapping;
                bool firstOcurrence = true;
                foreach (DataRow dataRow in BuildType.Tables["Service"].Rows)           //  Name         Variant   
                {
                    if (dataRow["Name"].ToString() != "")
                    {
                        buildItemToCheck = dataRow["Name"].ToString();
                        rowMapping = Mapping.Tables["DevicePort"].Select("pseudo='" + buildItemToCheck + "'");
                        if (rowMapping.Length == 1)
                        {
                            dtRequestUSB.ImportRow(rowMapping[0]);
                        }
                        else if (rowMapping.Length > 1)
                        {
                            firstOcurrence = true;
                            foreach (DataRow rowM in rowMapping)
                            {
                                if (firstOcurrence)
                                {
                                    dtRequestUSB.ImportRow(rowM);
                                    firstOcurrence = false;
                                }
                                else
                                {
                                    dtRequestUSB.Rows[dtRequestUSB.Rows.Count - 1]["pid"] = dtRequestUSB.Rows[dtRequestUSB.Rows.Count - 1]["pid"].ToString() + "|" + rowM["pid"];
                                    dtRequestUSB.Rows[dtRequestUSB.Rows.Count - 1]["vid"] = dtRequestUSB.Rows[dtRequestUSB.Rows.Count - 1]["vid"].ToString() + "|" + rowM["vid"];
                                    dtRequestUSB.Rows[dtRequestUSB.Rows.Count - 1]["port"] = dtRequestUSB.Rows[dtRequestUSB.Rows.Count - 1]["port"].ToString() + "|" + rowM["port"];
                                    //dtRequestUSB.Rows[dtRequestUSB.Rows.Count - 1]["portchain"] = dtRequestUSB.Rows[dtRequestUSB.Rows.Count - 1]["portchain"].ToString() + "|" + rowM["port"];
                                    dtRequestUSB.Rows[dtRequestUSB.Rows.Count - 1]["service"] = dtRequestUSB.Rows[dtRequestUSB.Rows.Count - 1]["service"].ToString() + "|" + rowM["service"];

                                }

                            }

                        }
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
         
        }

        private DataTable CheckDevicesUsb(DataTable dtDevices)
        {
            DataTable dtResult = new DataTable();
            DataTable dtTemp = new DataTable();
            string[] pId;
            string[] vId;
            string[] port;
            string[] service;
            string status = "";
            DataRow[] rowDeviceFound;
            int countOption = 0;

            dtTemp = dtRequestUSB.Copy();
            dtTemp.Columns.Add("Status");
            dtResult = dtTemp.Clone();

            allUSB = true;
            allService = true;

            foreach (DataRow dr in dtTemp.Rows)
            {
                pId = dr["pId"].ToString().Split('|');
                vId = dr["vId"].ToString().Split('|');
                port = dr["Port"].ToString().Split('|');
                service = dr["service"].ToString().Split('|');

                status = "Device not found";
                

                for (countOption = 0; countOption < pId.Length; countOption++)
                {
                    rowDeviceFound = dtDevices.Select("DeviceidProduct='" + pId[countOption] + "' AND DeviceidVendor ='" + vId[countOption] + "'");

                    if (rowDeviceFound.Length != 0)
                    {

                        //***************************************************************************************************************************
                        //verificacion de servicio  
                        //***************************************************************************************************************************
                        if (service[countOption] != "")
                        {
                            string serviceStatus = CheckServices(service[countOption]);
                            if (serviceStatus == "Running")
                            {
                                status = "OK";
                                break;
                            }
                            else if (serviceStatus != "")
                            {
                                status = "Service " + serviceStatus;
                            }
                            else
                            {
                                if (!status.Contains("Service"))
                                {
                                    status = "Service not found";
                                }
                            }
                        }
                        else
                        {
                            status = "OK";
                            break;
                        }

                    }

                }

                if (status == "Device not found")
                {
                    allUSB = false;
                    allService = false;
                }
                else if (status != "OK")
                {
                    allService = false;
                }

                dr["Status"] = status;
                dtResult.ImportRow(dr);
            }
            return dtResult;
        }

        private void PaintDataGridResult()
        {
            string status = "";
            foreach (DataGridViewRow rowp in dgvDevicesFVT.Rows)
            {
                if (rowp.Cells["Status"].Value == null) continue;

                status = rowp.Cells["Status"].Value.ToString();

                if (status == "OK")
                {
                    dgvDevicesFVT.Rows[rowp.Index].DefaultCellStyle.BackColor = Color.LightGreen;
                }
                else if (status == "Device not found")
                {
                    dgvDevicesFVT.Rows[rowp.Index].DefaultCellStyle.BackColor = Color.PaleVioletRed;
                }
                else
                {
                    dgvDevicesFVT.Rows[rowp.Index].DefaultCellStyle.BackColor = Color.LightYellow;
                }
            }
        }

        private void CrateFileUSBInfo()
        {
            try
            {

                ProcessStartInfo p = new ProcessStartInfo();

                p.FileName = programRute;


                p.Arguments = "-X=" + xmlFileName + "";

                try
                {
                    Process x = Process.Start(p);

                    if (firstCheck)
                    {
                        x.WaitForExit();
                        firstCheck = false;
                    }

                    lastRequestFile = DateTime.Now;
                    RequestedFile = true;
                }
                catch (Exception ex)
                {

                }


            }
            catch (Exception ex)
            {

            }
        }

        private void frmMainUI_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!allUSB)
            {
                MessageBox.Show("No se puede cerrar programa hasta encontrar dispositivos usb");
                //e.Cancel = true;
            }

        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            string Tracer = Environment.MachineName.Substring(7);
            string LogFolderPathPreparser = @"\\mxchim0pangea01\diskbld\USBMapping\Logs\Parametric\";
            btnTest.Visible = false;
            btnContinue.Visible = false;
            lblRunning.Visible = true;
            lblComplete.Visible = false;
            dgvDevicesFVT.Visible = true;
            VerifyUSBs();
            WriteLog(true);
            if (IsFristFVTStart())
            {

                try
                {
                    if (!Directory.Exists(LogFolderPathPreparser))
                    {
                        Directory.CreateDirectory(LogFolderPathPreparser);
                    }
                    File.Copy(LogFolderPath + Tracer + "Start.txt", LogFolderPathPreparser + Tracer + "Start.txt");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("problema al copiar log a carpeta de preparser, " + ex);
                }
            }

            //dgvDevicesConn.DataSource = dtDevices;
            //dgvDevicesConn.Update();
            //dgvDevicesConn.Refresh();

            if (allUSB && allService)
            {
                lblRunning.Visible = false;
                lblComplete.Visible = true;
                //MessageBox.Show("Todos los dispositivos USB del BuildType encontrados, se cerrara USBDeviceNCRChecker y se abrira Pangea");
                frmComment AddComment = new frmComment();
                AddComment.ShowDialog();
                WriteLog(false);
                deleteStartup();
                RunPangea();
                Close();
            }
            else
            {
                tmrCheckAgain.Enabled = true;
            }
        }
        public string CheckServices(string serviceToFind)
        {
            string resultSearchServices = "";
            ServiceController[] scServices;
            scServices = ServiceController.GetServices(Environment.MachineName);
            //*******************************************************************************************

            foreach (ServiceController scTemp in scServices)
            {
                if (scTemp.ServiceName == serviceToFind)
                {
                    resultSearchServices = scTemp.Status.ToString();
                    if (scTemp.Status == ServiceControllerStatus.Running)
                    {
                        break;
                    }

                }
                /*
                // Write the service name and the display name
                // for each running service.
                Console.WriteLine();
                Console.WriteLine("  Service :        {0}", scTemp.ServiceName);
                Console.WriteLine("    Display name:    {0}", scTemp.DisplayName);

                // Query WMI for additional information about this service.
                // Display the start name (LocalSytem, etc) and the service
                // description.
                ManagementObject wmiService;
                wmiService = new ManagementObject("Win32_Service.Name='" + scTemp.ServiceName + "'");
                wmiService.Get();
                Console.WriteLine("    Start name:      {0}", wmiService["StartName"]);
                Console.WriteLine("    Description:     {0}", wmiService["Description"]);
                */
            }
            return resultSearchServices;
        }


        private void btnContinue_Click(object sender, EventArgs e)
        {
            btnContinue.Visible = false;
            btnTest.Visible = false;
            MessageBox.Show("Los dispositivos USB del BuildType no se verificaron, se cerrara USBDeviceNCRChecker y se abrira Pangea");
            RunPangea();
            allUSB = true;
            corePress = true;
            Close();
        }

        private void RunPangea()
        {

            try
            {
                //string AppFolder = @"C:\Pangaea\PangaeaFinancial\GUI";
                //string programRute = Path.Combine(AppFolder, @"PangaeaFinancial.exe");

                //ProcessStartInfo p = new ProcessStartInfo();

                //p.FileName = programRute;
                //p.WorkingDirectory = AppFolder + @"\";
                //p.UseShellExecute = false;

                //Process x = Process.Start(p);
                //System.Threading.Thread.Sleep(1000);
                RunATMFVT();
            }
            catch (Exception ex)
            {

            }

        }

        private void RunATMFVT()
        {
            try
            {
                string AppFolder = @"C:\Pangaea\ExternalExecutables";
                string programRute = Path.Combine(AppFolder, @"ATM FVT Verification 1.0.0.exe");

                ProcessStartInfo p = new ProcessStartInfo();

                p.FileName = programRute;
                p.WorkingDirectory = AppFolder + @"\";
                p.UseShellExecute = false;

                Process x = Process.Start(p);
            }
            catch (Exception ex)
            {

            }
        }

        private void RunRepair()
        {
            try
            {
                string AppFolder = @"C:\Pangaea\ExternalExecutables";
                string programRute = Path.Combine(AppFolder, @"Repair.exe");

                ProcessStartInfo p = new ProcessStartInfo();

                p.FileName = programRute;
                p.WorkingDirectory = AppFolder + @"\";
                p.UseShellExecute = false;

                Process x = Process.Start(p);
            }
            catch (Exception ex)
            {

            }
        }

        private void CloseProgram(string taskName)
        {
            bool isCloseProgram = false;
            Restart:
            try
            {
                foreach (Process proceso in Process.GetProcessesByName(taskName))
                {
                    isCloseProgram = true;

                    proceso.Kill();
                }
            }
            catch (Exception ex)
            {
                //  MessageBox.Show(ex.Message);
            }
            if (!isCloseProgram)
            {
                System.Threading.Thread.Sleep(100);
                goto Restart;
            }
        }

        private void btnAceptarManual_Click(object sender, EventArgs e)
        {
            frmLogin login = new frmLogin("NCR");
            login.ShowDialog();

        }
        private void dgvDevicesFVT_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            PaintDataGridResult();
        }

        private void deleteStartup()
        {
            string shorcut = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Startup), @"USBDeviceNCRChecker.lnk");
            if (File.Exists(shorcut))
            {
                File.Delete(shorcut);
            }

        }

        bool IsFristFVTStart()
        {
            string Tracer = Environment.MachineName.Substring(7);
            DataTable dtConsult = new DataTable();
            string queryConsult = "SELECT TOP (1000) [PKId]" +
                  ", [DateTest]" +
                  ", [SerialNumber]" +
                  ", [Status]" +
                  ", [Tester]" +
                  ", [PartNumber]" +
                  "FROM SY_EOLResults " +
                  "WHERE SerialNumber = '" + Tracer + "'";
            wsSQL.SQLServerDBv2 SQL = new wsSQL.SQLServerDBv2();
            dtConsult = SQL.dtSQLQuery(Properties.Settings.Default.SQLServer, Properties.Settings.Default.DataBase, queryConsult);
            try
            {
                if (dtConsult.Rows.Count >= 1 && dtConsult.Rows[0]["SerialNumber"].ToString() == Tracer)
                {
                    return false;
                }
                else
                {
                    return true;
                }

            }
            catch
            {
                return true;
            }

        }

        private void WriteLog(bool logInicial)
        {

            string Tracer = Environment.MachineName.Substring(7);
            string Results = "";
            string Mensaje = "";

            if (corePress == true)
            {
                userClose = "CORETEST";
            }
            try
            {
                if (LogFolderPath == "")
                {
                    LogFolderPath = @"\\mxchim0pangea01\diskbld\USBMapping\Logs\" + DateTime.Now.ToString("MM_yyyy_dd") + @"\" + DateTime.Now.ToString("HH") + @"\";
                }
                string LogFolderPathPreparser = @"\\mxchim0pangea01\diskbld\USBMapping\Logs\Parametric\";
                if (!Directory.Exists(LogFolderPath))
                {
                    Directory.CreateDirectory(LogFolderPath);
                }
                if (logInicial)
                {
                    sw = new StreamWriter(LogFolderPath + Tracer + "Start.txt", true);
                }
                else
                {
                    sw = new StreamWriter(LogFolderPath + Tracer + "End.txt", true);
                    /*
                    if (corePress == false)
                    {
                        frmComment AddComment = new frmComment();
                        AddComment.ShowDialog();
                    }
                    */
                }
                Results = "PASS";
                foreach (DataRow row in dtResultUSB.Rows)
                {
                    if (row["Status"].ToString() != "OK")
                    {
                        Results = "FAIL";
                    }
                }
                Mensaje = "STATUS:" + Results + Environment.NewLine +
                          "MACHINE_NAME:" + Environment.MachineName + Environment.NewLine +
                          "USER:" + userClose + Environment.NewLine +
                          "COMMENT:" + userComment + Environment.NewLine +
                          "DATE:" + DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss");

                sw.WriteLine(Mensaje + Environment.NewLine);
                dtResultUSB.WriteXml(sw);
                sw.WriteLine(Environment.NewLine);

                sw.Flush();
                sw.Close();

                if (!logInicial)
                {
                    if (!Directory.Exists(LogFolderPathPreparser))
                    {
                        Directory.CreateDirectory(LogFolderPathPreparser);
                    }
                    if (corePress == false)
                    {
                        try
                        {
                            File.Copy(LogFolderPath + Tracer + "End.txt", LogFolderPathPreparser + Tracer + "End.txt");
                        }
                        catch
                        {

                        }
                    }
                }
                Application.DoEvents();
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }
        }

        private void UpdateVersion()
        {
            if (File.Exists(Properties.Settings.Default.UpdatePath + ProductName + ".exe"))
            {
                string installFolder = Application.StartupPath;
                string versionToUpdate = FileVersionInfo.GetVersionInfo(Properties.Settings.Default.UpdatePath + ProductName + ".exe").ProductVersion;
                string date = DateTime.Now.ToString("MMddyyyy");
                string time = DateTime.Now.ToString("HHmmss");
                var versionActual = new Version(ProductVersion);
                var versionUpdate = new Version(versionToUpdate);

                var NeedUpdate = versionActual.CompareTo(versionUpdate);

                if (NeedUpdate > 0)  //versionActual is greater"
                {

                }
                else if (NeedUpdate < 0)  //versionUpdate is greater
                {
                    if (!Directory.Exists(installFolder + @"\BKP\" + date + @"\" + time + @"\"))
                    {
                        Directory.CreateDirectory(installFolder + @"\BKP\" + date + @"\" + time + @"\");
                    }

                    try
                    {
                        File.Move(Path.Combine(installFolder, ProductName + ".exe"), Path.Combine(installFolder, @"BKP\" + date + @"\" + time + @"\" + ProductName + ".exe"));
                        File.Copy(Properties.Settings.Default.UpdatePath + ProductName + ".exe", Path.Combine(installFolder, ProductName + ".exe"));

                        if (File.Exists(Path.Combine(installFolder, ProductName + ".exe.config")))
                        {
                            File.Move(Path.Combine(installFolder, ProductName + ".exe.config"), Path.Combine(installFolder, @"BKP\" + date + @"\" + time + @"\" + ProductName + ".exe.config"));
                            File.Copy(Properties.Settings.Default.UpdatePath + ProductName + ".exe.config", Path.Combine(installFolder, ProductName + ".exe.config"));
                        }

                        if (File.Exists(Path.Combine(installFolder, ProductName + ".pdb")))
                        {
                            File.Move(Path.Combine(installFolder, ProductName + ".pdb"), Path.Combine(installFolder, @"BKP\" + date + @"\" + time + @"\" + ProductName + ".pdb"));
                            File.Copy(Properties.Settings.Default.UpdatePath + ProductName + ".pdb", Path.Combine(installFolder, ProductName + ".pdb"));
                        }

                        runBat(installFolder);

                    }
                    catch
                    {

                    }

                }
                else //versions are equal
                {

                }

            }
        }
        private void runBat(string installFolder)
        {
            string programRute = Path.Combine(installFolder, "RestartApp.bat");
            ProcessStartInfo p = new ProcessStartInfo(ProductName);
            p.Arguments = ProductName + ".exe";
            p.FileName = programRute;
            p.WorkingDirectory = installFolder + @"\";
            p.CreateNoWindow = true;
            Process x = Process.Start(p);
        }

        private void lblRunning_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

