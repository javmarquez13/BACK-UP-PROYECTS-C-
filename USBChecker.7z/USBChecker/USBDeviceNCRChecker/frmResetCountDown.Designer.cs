﻿namespace USBDeviceNCRChecker
{
    partial class frmResetCountDown
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tmrRestartPC = new System.Windows.Forms.Timer(this.components);
            this.lblTimeToReset = new System.Windows.Forms.Label();
            this.BtnResetNow = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(173, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Se reiniciara PC";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(504, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "USB Encontrados, no todos los servicios corriendo ";
            // 
            // tmrRestartPC
            // 
            this.tmrRestartPC.Interval = 1000;
            this.tmrRestartPC.Tick += new System.EventHandler(this.tmrRestartPC_Tick);
            // 
            // lblTimeToReset
            // 
            this.lblTimeToReset.AutoSize = true;
            this.lblTimeToReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTimeToReset.Location = new System.Drawing.Point(180, 136);
            this.lblTimeToReset.Name = "lblTimeToReset";
            this.lblTimeToReset.Size = new System.Drawing.Size(151, 39);
            this.lblTimeToReset.TabIndex = 2;
            this.lblTimeToReset.Text = "00:01:00";
            // 
            // BtnResetNow
            // 
            this.BtnResetNow.Location = new System.Drawing.Point(378, 224);
            this.BtnResetNow.Name = "BtnResetNow";
            this.BtnResetNow.Size = new System.Drawing.Size(90, 40);
            this.BtnResetNow.TabIndex = 3;
            this.BtnResetNow.Text = "Reiniciar Ahora";
            this.BtnResetNow.UseVisualStyleBackColor = true;
            this.BtnResetNow.Click += new System.EventHandler(this.BtnResetNow_Click);
            // 
            // ResetCountDown
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(512, 293);
            this.Controls.Add(this.BtnResetNow);
            this.Controls.Add(this.lblTimeToReset);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "ResetCountDown";
            this.Text = "USBchecker";
            this.Load += new System.EventHandler(this.ResetCountDown_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Timer tmrRestartPC;
        private System.Windows.Forms.Label lblTimeToReset;
        private System.Windows.Forms.Button BtnResetNow;
    }
}