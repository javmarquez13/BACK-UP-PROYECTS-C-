﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace USBDeviceNCRChecker
{
    public partial class frmResetCountDown : Form
    {
        TimeSpan time = TimeSpan.FromSeconds(5);
        public frmResetCountDown()
        {
            InitializeComponent();
        }

        private void ResetCountDown_Load(object sender, EventArgs e)
        {
            tmrRestartPC.Enabled = true;
        }

        private void tmrRestartPC_Tick(object sender, EventArgs e)
        {
            time = time - TimeSpan.FromSeconds(1);
            lblTimeToReset.Text = time.ToString();

            if (time == TimeSpan.Zero)
            {
                tmrRestartPC.Enabled = false;
                Close();
            }
        }

        private void BtnResetNow_Click(object sender, EventArgs e)
        {
            lblTimeToReset.Text = time.ToString();
            tmrRestartPC.Enabled = false;
            Close();
        }
    }
}
