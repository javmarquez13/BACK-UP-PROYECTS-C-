﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace USBDeviceNCRChecker
{
    public partial class frmLogin : Form
    {
        /*
        public frmLogin()
        {
            InitializeComponent();
            this.txtPassword.KeyPress += new KeyPressEventHandler(txtPassword_KeyPress);
        }

        private void GetUsers()
        {

        }

        private void btnLogOn_Click(object sender, EventArgs e)
        {


            if (txtPassword.Text.Length == 0 || txtUsers.Text.Length == 0)    //this is here for a reason , but i forgot it :P, anyway do not remove unless you find a better way to do this
            {

            }
            else
            {
                
                if (txtPassword.Text.ToUpper() == "ATMOK")
                {
                    frmMainUI.userClose = txtUsers.Text;
                    frmMainUI.allUSB = true;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Acceso denegado", "Acceso Denegado", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    txtPassword.Text = String.Empty;
                }
            }

            
        }

        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                btnLogOn.PerformClick();
            }
        }

        private void cmbUsers_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void frmLogin_Load(object sender, EventArgs e)
        {

        }

        */



        bool isLogged = false;
        string Customer = "";
        string usersGroup = "";

        public frmLogin(string WorkCell)
        {
            InitializeComponent();
            this.txtPassword.KeyPress += new KeyPressEventHandler(txtPassword_KeyPress);
            Customer = WorkCell;
            GetUsers();
        }

        public frmLogin(string WorkCell, string users)
        {
            InitializeComponent();
            this.txtPassword.KeyPress += new KeyPressEventHandler(txtPassword_KeyPress);
            Customer = WorkCell;
            usersGroup = users;
            GetUsers();
        }

        private void GetUsers()
        {
            DataTable dTUsers = new DataTable();
            try
            {
                string SQLServer = Properties.Settings.Default.SQLServer;
                string SQLDB = Properties.Settings.Default.SharedDataBase;
                wsSQL.SQLServerDBv2 SQLCommand = new wsSQL.SQLServerDBv2();
                string dataBase = Customer;
                string users = "2,3,4";
                if (usersGroup != "")
                    users = usersGroup;
                string SQLString = " SELECT UserID FROM dbo.SC_Users U (NOLOCK) INNER JOIN CR_WorkCel  W ON U.FKWorkCel = W.PKWorkCel " +
                                                        "WHERE W.Name  = '" + dataBase + "' AND  U.Active =1  AND FKGroup IN (" + users + ") "+
                                                        "ORDER BY UserID ASC";
                dTUsers = SQLCommand.dsSQLQuery(SQLServer, SQLDB, SQLString).Tables[0];
                cmbUsers.Items.Clear();
                foreach (DataRow Row in dTUsers.Rows)
                {
                    cmbUsers.Items.Add(Row["UserID"].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocurrio un error al intentar recuperar los usuarios activos : " + ex.Message + Environment.NewLine + ex.StackTrace, "Error de la base de datos", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLogOn_Click(object sender, EventArgs e)
        {
            if (isLogged)
            {
                isLogged = false;
            }

            if (txtPassword.Text.Length == 0 || cmbUsers.SelectedIndex == -1)   
            {

            }
            else
            {
                classLogin Login = new classLogin(cmbUsers.SelectedItem.ToString(), txtPassword.Text);
                if (Login.Logon())
                {
                    isLogged = true;
                    txtPassword.Text = String.Empty;
                    frmMainUI.userClose = cmbUsers.SelectedItem.ToString();
                    frmMainUI.allUSB = true;
                }
                else
                {
                    MessageBox.Show("Acceso denegado", "Acceso Denegado", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    txtPassword.Text = String.Empty;
                }
            }

            this.Close();
        }

        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                btnLogOn.PerformClick();
            }
        }

        private void cmbUsers_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void frmLogin_Load(object sender, EventArgs e)
        {

        }






















    }
}
