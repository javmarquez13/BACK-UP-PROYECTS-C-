﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace USBDeviceNCRChecker
{
    
    public partial class frmLoginAuthorizedUser : Form
    {
        bool isLogged = false;
        string Customer = "";
        string usersGroup = "";
        string[] requiredCertifications;


        public frmLoginAuthorizedUser(string WorkCell, string[] Certifications)
        {
            InitializeComponent();
            requiredCertifications = Certifications;
            Customer = WorkCell;
           // usersGroup = users;
           // GetUsers();
        }

        //private void GetUsers()
        //{
        //    DataTable dTUsers = new DataTable();
        //    try
        //    {
        //        string SQLServer = Properties.Settings.Default.SQLServer;
        //        string SQLDB = Properties.Settings.Default.SharedDataBase;
        //        wsSQL.SQLServerDBv2 SQLCommand = new wsSQL.SQLServerDBv2();
        //        string dataBase = Customer;

        //        string SQLString = " SELECT UserID FROM dbo.SC_Users U (NOLOCK) INNER JOIN CR_WorkCel  W ON U.FKWorkCel = W.PKWorkCel " +
        //                                                "WHERE W.Name  = '" + dataBase + "' AND U.Active =1 " +
        //                                                "ORDER BY UserID ASC";
        //        dTUsers = SQLCommand.dsSQLQuery(SQLServer, SQLDB, SQLString).Tables[0];
        //        cmbUsers.Items.Clear();
        //        foreach (DataRow Row in dTUsers.Rows)
        //        {
        //            cmbUsers.Items.Add(Row["UserID"].ToString());
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Ocurrio un error al intentar recuperar los usuarios activos : " + ex.Message + Environment.NewLine + ex.StackTrace, "Error de la base de datos", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //    }
        //}

        private void btnLogOn_Click(object sender, EventArgs e)
        {
            wsActiveDirectory.WSActiveDirectory activeDirectory = new wsActiveDirectory.WSActiveDirectory();
            isLogged = false;
             
            if (txtPassword.Text.Length != 0 && txtUsers.Text.Trim() != "")   
            {
                if (activeDirectory.Logon(txtUsers.Text, Encode(txtPassword.Text)))
                {
                    if (authorized(txtUsers.Text,Customer, requiredCertifications))
                    {
                        isLogged = true;
                        txtPassword.Text = String.Empty;
                        frmMainUI.userClose = txtUsers.Text;
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Usuario sin certificaciones", "Acceso Denegado", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        txtUsers.Text = "";
                        txtPassword.Text = String.Empty;
                    }

                }
                else
                {
                    MessageBox.Show("Acceso denegado", "Acceso Denegado", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    txtPassword.Text = String.Empty;
                }
            }
        }

        public string Encode(string data)
        {
            byte[] encData_byte = new byte[data.Length];
            encData_byte = System.Text.Encoding.UTF8.GetBytes(data);
            string encodedData = Convert.ToBase64String(encData_byte);
            return encodedData;
        }

        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                btnLogOn.PerformClick();
            }
        }

        private bool authorized(string user,string Workcel, string[] rCertification)
        {
            DataTable dTUserCetrifications = new DataTable();
            wsSQL.SQLServerDBv2 SQL = new wsSQL.SQLServerDBv2();
            string SQLString;
            int userNum;
            try
            {
                userNum=Convert.ToInt32(user);
            }
            catch
            {
                DataTable dTUser = new DataTable();
                SQLString = "SELECT [NTAccount], [NoSAP_Kronos] FROM SC_HeadCount WHERE [NTAccount] = '" + user + "'";
                dTUser = SQL.dtSQLQuery(Properties.Settings.Default.SQLServer, Properties.Settings.Default.SharedDataBase, SQLString);
                if (dTUser.Rows.Count > 0 && dTUser.Columns.Count > 1)
                {
                    user = dTUser.Rows[0]["NoSAP_Kronos"].ToString();
                }
                else
                {
                    dTUser = new DataTable();
                    SQLString = "SELECT [UserID], [EmployeeNumber] FROM SC_Users WHERE [UserID] = '" + user + "'";
                    dTUser = SQL.dtSQLQuery(Properties.Settings.Default.SQLServer, Properties.Settings.Default.SharedDataBase, SQLString);
                    if (dTUser.Rows.Count > 0 && dTUser.Columns.Count > 1)
                    {
                        try
                        {
                            user = dTUser.Rows[0]["EmployeeNumber"].ToString();
                            userNum = Convert.ToInt32(user); //Check if user are numeric
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Usuario no numerico");
                            return false;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Usuario no numerico");
                        return false;
                    }
                }
            }

            try
            {    //"[up_GetCUCUserCertifications] 1587094, 'MXCHITESLA072'"
                SQLString = "[up_GetCUCUserCertifications] "+ user + ", ''";
                dTUserCetrifications = SQL.dtSQLQuery(Properties.Settings.Default.SQLServer, Properties.Settings.Default.SharedDataBase, SQLString);

                foreach (string cert in rCertification)
                {
                    if (cert.Trim() != "")
                    {
                        foreach (DataRow drCertification in dTUserCetrifications.Rows)
                        {
                            if (drCertification["Topic"].ToString()== cert)
                            {
                                if (Convert.ToDateTime(drCertification["ExpirationDate"].ToString()) > DateTime.Now) //verificar expiracion de certificado
                                {
                                    if (Convert.ToInt32(drCertification["DaysToExpiration"].ToString())<5)
                                    {
                                        MessageBox.Show("La certificacion " + cert.Trim() + " del usuario:" + user + " esta proxima a expirar en: " + drCertification["DaysToExpiration"].ToString()+" dias");
                                    }
                                    goto NextCert;  // el usuario tiene vigente la certificacion
                                }
                                else
                                {
                                    MessageBox.Show("La certificacion "+ cert.Trim() + " del usuario:"+ user +" expiro el dia: "+ drCertification["ExpirationDate"].ToString());
                                }
                            }
                        }
                        MessageBox.Show("El usuario:" + user + " no tiene la certificacion " + cert.Trim());
                        return false;
                    }
                NextCert:;
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocurrio un error al verificar autorizacion de usuario : " + ex.Message + Environment.NewLine + ex.StackTrace);
                return false;
            }
        }

    }
}
