﻿namespace USBDeviceNCRChecker
{
    partial class frmMainUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tmrCheckAgain = new System.Windows.Forms.Timer(this.components);
            this.btnContinue = new System.Windows.Forms.Button();
            this.btnTest = new System.Windows.Forms.Button();
            this.btnAceptarManual = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvDevicesFVT = new System.Windows.Forms.DataGridView();
            this.lblRunning = new System.Windows.Forms.Label();
            this.lblComplete = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDevicesFVT)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tmrCheckAgain
            // 
            this.tmrCheckAgain.Interval = 500;
            this.tmrCheckAgain.Tick += new System.EventHandler(this.tmrCheckAgain_Tick);
            // 
            // btnContinue
            // 
            this.btnContinue.BackColor = System.Drawing.Color.Gainsboro;
            this.btnContinue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnContinue.FlatAppearance.BorderSize = 0;
            this.btnContinue.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContinue.Location = new System.Drawing.Point(3, 3);
            this.btnContinue.Name = "btnContinue";
            this.btnContinue.Size = new System.Drawing.Size(178, 69);
            this.btnContinue.TabIndex = 1;
            this.btnContinue.Text = "Core";
            this.btnContinue.UseVisualStyleBackColor = false;
            this.btnContinue.Click += new System.EventHandler(this.btnContinue_Click);
            // 
            // btnTest
            // 
            this.btnTest.BackColor = System.Drawing.Color.Gainsboro;
            this.btnTest.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnTest.FlatAppearance.BorderSize = 0;
            this.btnTest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTest.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTest.Location = new System.Drawing.Point(741, 3);
            this.btnTest.Name = "btnTest";
            this.btnTest.Size = new System.Drawing.Size(180, 69);
            this.btnTest.TabIndex = 2;
            this.btnTest.Text = "FVT";
            this.btnTest.UseVisualStyleBackColor = false;
            this.btnTest.Click += new System.EventHandler(this.btnTest_Click);
            // 
            // btnAceptarManual
            // 
            this.btnAceptarManual.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnAceptarManual.BackColor = System.Drawing.Color.Gainsboro;
            this.btnAceptarManual.Location = new System.Drawing.Point(3, 119);
            this.btnAceptarManual.Name = "btnAceptarManual";
            this.btnAceptarManual.Size = new System.Drawing.Size(104, 35);
            this.btnAceptarManual.TabIndex = 4;
            this.btnAceptarManual.Text = "Aceptar Manual Todos Usb OK";
            this.btnAceptarManual.UseVisualStyleBackColor = false;
            this.btnAceptarManual.Visible = false;
            this.btnAceptarManual.Click += new System.EventHandler(this.btnAceptarManual_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(741, 107);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(180, 50);
            this.label1.TabIndex = 6;
            this.label1.Text = "Devices BuildType FVT";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvDevicesFVT
            // 
            this.dgvDevicesFVT.AllowUserToAddRows = false;
            this.dgvDevicesFVT.AllowUserToDeleteRows = false;
            this.dgvDevicesFVT.AllowUserToResizeRows = false;
            this.dgvDevicesFVT.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDevicesFVT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanel1.SetColumnSpan(this.dgvDevicesFVT, 3);
            this.dgvDevicesFVT.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvDevicesFVT.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvDevicesFVT.Location = new System.Drawing.Point(3, 160);
            this.dgvDevicesFVT.MultiSelect = false;
            this.dgvDevicesFVT.Name = "dgvDevicesFVT";
            this.dgvDevicesFVT.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDevicesFVT.Size = new System.Drawing.Size(918, 399);
            this.dgvDevicesFVT.TabIndex = 5;
            this.dgvDevicesFVT.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvDevicesFVT_ColumnHeaderMouseClick);
            // 
            // lblRunning
            // 
            this.lblRunning.AutoSize = true;
            this.lblRunning.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRunning.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRunning.ForeColor = System.Drawing.Color.Red;
            this.lblRunning.Location = new System.Drawing.Point(187, 0);
            this.lblRunning.Name = "lblRunning";
            this.lblRunning.Size = new System.Drawing.Size(548, 75);
            this.lblRunning.TabIndex = 8;
            this.lblRunning.Text = "Verificar USB Faltantes";
            this.lblRunning.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblRunning.Visible = false;
            this.lblRunning.Click += new System.EventHandler(this.lblRunning_Click);
            // 
            // lblComplete
            // 
            this.lblComplete.AutoSize = true;
            this.lblComplete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblComplete.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComplete.ForeColor = System.Drawing.Color.Green;
            this.lblComplete.Location = new System.Drawing.Point(187, 75);
            this.lblComplete.Name = "lblComplete";
            this.lblComplete.Size = new System.Drawing.Size(548, 82);
            this.lblComplete.TabIndex = 9;
            this.lblComplete.Text = "USB Encontrados";
            this.lblComplete.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblComplete.Visible = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Controls.Add(this.btnContinue, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnTest, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label1, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnAceptarManual, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.dgvDevicesFVT, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblRunning, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblComplete, 1, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.44196F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.66395F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 71.8941F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(924, 562);
            this.tableLayoutPanel1.TabIndex = 10;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(924, 562);
            this.panel1.TabIndex = 11;
            // 
            // frmMainUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(924, 562);
            this.ControlBox = false;
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.Name = "frmMainUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "USBDeviceNCRChecker";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMainUI_FormClosing);
            this.Load += new System.EventHandler(this.frmMainUI_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDevicesFVT)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer tmrCheckAgain;
        private System.Windows.Forms.Button btnContinue;
        private System.Windows.Forms.Button btnTest;
        private System.Windows.Forms.Button btnAceptarManual;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvDevicesFVT;
        private System.Windows.Forms.Label lblRunning;
        private System.Windows.Forms.Label lblComplete;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
    }
}

