﻿namespace SSCOMonitor
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblVersion = new System.Windows.Forms.Label();
            this.btnMinimize = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPageSettings = new System.Windows.Forms.TabPage();
            this.dgvStrings = new System.Windows.Forms.DataGridView();
            this.tabPageDesc = new System.Windows.Forms.TabPage();
            this.dgvDescription = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rbtn6682 = new System.Windows.Forms.RadioButton();
            this.rbtn6681 = new System.Windows.Forms.RadioButton();
            this.rbtn6622 = new System.Windows.Forms.RadioButton();
            this.rbtn2043 = new System.Windows.Forms.RadioButton();
            this.rbtn6688 = new System.Windows.Forms.RadioButton();
            this.rbtn6684 = new System.Windows.Forms.RadioButton();
            this.rbtn6623 = new System.Windows.Forms.RadioButton();
            this.rBtn7362 = new System.Windows.Forms.RadioButton();
            this.rBtn7360 = new System.Windows.Forms.RadioButton();
            this.rBtn7358 = new System.Windows.Forms.RadioButton();
            this.rBtn7350 = new System.Windows.Forms.RadioButton();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dgviFactory = new System.Windows.Forms.DataGridView();
            this.rTxtBoxEJL = new System.Windows.Forms.RichTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtBoxClass = new System.Windows.Forms.TextBox();
            this.txtBoxTracer = new System.Windows.Forms.TextBox();
            this.txtBoxWip = new System.Windows.Forms.TextBox();
            this.txtTracerOrWip = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.rbtnNotePad = new System.Windows.Forms.RadioButton();
            this.rbtnVisualStudio = new System.Windows.Forms.RadioButton();
            this.btnOpenScript = new System.Windows.Forms.Button();
            this.chBoxAutoOpenPangaea = new System.Windows.Forms.CheckBox();
            this.chBoxAutoClosePangaea = new System.Windows.Forms.CheckBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnGetScripts = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPathSCripts = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cBoxScripts = new System.Windows.Forms.ComboBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.lblDetails = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtFindLogsVerifyAudit = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnPangaea02 = new System.Windows.Forms.Button();
            this.btnPangaea01 = new System.Windows.Forms.Button();
            this.btnChirel01 = new System.Windows.Forms.Button();
            this.btnScriptsKits = new System.Windows.Forms.Button();
            this.lblCurrentInfo = new System.Windows.Forms.Label();
            this.btnTab1 = new System.Windows.Forms.Button();
            this.btnTab2 = new System.Windows.Forms.Button();
            this.btnShortCuts = new System.Windows.Forms.Button();
            this.txtSearchFeature = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPageSettings.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStrings)).BeginInit();
            this.tabPageDesc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDescription)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgviFactory)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.btnExit);
            this.panel1.Controls.Add(this.lblVersion);
            this.panel1.Controls.Add(this.btnMinimize);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1527, 69);
            this.panel1.TabIndex = 1;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(93)))), ((int)(((byte)(0)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(1361, 5);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(45, 45);
            this.button1.TabIndex = 37;
            this.button1.Text = "?";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // btnExit
            // 
            this.btnExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExit.BackColor = System.Drawing.Color.IndianRed;
            this.btnExit.FlatAppearance.BorderColor = System.Drawing.Color.IndianRed;
            this.btnExit.FlatAppearance.BorderSize = 0;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnExit.Location = new System.Drawing.Point(1477, 3);
            this.btnExit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(45, 45);
            this.btnExit.TabIndex = 35;
            this.btnExit.Text = "X";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblVersion
            // 
            this.lblVersion.AutoSize = true;
            this.lblVersion.BackColor = System.Drawing.Color.Transparent;
            this.lblVersion.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVersion.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblVersion.Location = new System.Drawing.Point(150, 19);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(69, 17);
            this.lblVersion.TabIndex = 14;
            this.lblVersion.Text = "VERSION";
            // 
            // btnMinimize
            // 
            this.btnMinimize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMinimize.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.btnMinimize.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(93)))), ((int)(((byte)(0)))));
            this.btnMinimize.FlatAppearance.BorderSize = 0;
            this.btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimize.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnMinimize.Location = new System.Drawing.Point(1419, 5);
            this.btnMinimize.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnMinimize.Name = "btnMinimize";
            this.btnMinimize.Size = new System.Drawing.Size(45, 45);
            this.btnMinimize.TabIndex = 36;
            this.btnMinimize.Text = "_";
            this.btnMinimize.UseVisualStyleBackColor = false;
            this.btnMinimize.Click += new System.EventHandler(this.btnMinimize_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label4.Location = new System.Drawing.Point(12, 14);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(132, 36);
            this.label4.TabIndex = 13;
            this.label4.Text = "NCR TE";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tabControl1.Location = new System.Drawing.Point(0, 165);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1527, 606);
            this.tabControl1.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.tabPage1.Controls.Add(this.txtSearchFeature);
            this.tabPage1.Controls.Add(this.tabControl2);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1519, 573);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "FEATURES BY MC";
            // 
            // tabControl2
            // 
            this.tabControl2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl2.Controls.Add(this.tabPageSettings);
            this.tabControl2.Controls.Add(this.tabPageDesc);
            this.tabControl2.Location = new System.Drawing.Point(117, -29);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1406, 594);
            this.tabControl2.TabIndex = 55;
            // 
            // tabPageSettings
            // 
            this.tabPageSettings.Controls.Add(this.dgvStrings);
            this.tabPageSettings.Location = new System.Drawing.Point(4, 29);
            this.tabPageSettings.Name = "tabPageSettings";
            this.tabPageSettings.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageSettings.Size = new System.Drawing.Size(1398, 561);
            this.tabPageSettings.TabIndex = 0;
            this.tabPageSettings.Text = "Strings";
            this.tabPageSettings.UseVisualStyleBackColor = true;
            // 
            // dgvStrings
            // 
            this.dgvStrings.AllowUserToAddRows = false;
            this.dgvStrings.AllowUserToDeleteRows = false;
            this.dgvStrings.AllowUserToResizeColumns = false;
            this.dgvStrings.AllowUserToResizeRows = false;
            this.dgvStrings.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.dgvStrings.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvStrings.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvStrings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvStrings.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvStrings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvStrings.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.dgvStrings.Location = new System.Drawing.Point(3, 3);
            this.dgvStrings.Name = "dgvStrings";
            this.dgvStrings.ReadOnly = true;
            this.dgvStrings.RowTemplate.Height = 28;
            this.dgvStrings.Size = new System.Drawing.Size(1392, 555);
            this.dgvStrings.TabIndex = 2;
            this.dgvStrings.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvStrings_CellDoubleClick);
            // 
            // tabPageDesc
            // 
            this.tabPageDesc.Controls.Add(this.dgvDescription);
            this.tabPageDesc.Location = new System.Drawing.Point(4, 29);
            this.tabPageDesc.Name = "tabPageDesc";
            this.tabPageDesc.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageDesc.Size = new System.Drawing.Size(1398, 561);
            this.tabPageDesc.TabIndex = 1;
            this.tabPageDesc.Text = "Description";
            this.tabPageDesc.UseVisualStyleBackColor = true;
            // 
            // dgvDescription
            // 
            this.dgvDescription.AllowUserToAddRows = false;
            this.dgvDescription.AllowUserToDeleteRows = false;
            this.dgvDescription.AllowUserToResizeColumns = false;
            this.dgvDescription.AllowUserToResizeRows = false;
            this.dgvDescription.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDescription.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvDescription.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDescription.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgvDescription.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDescription.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.dgvDescription.Location = new System.Drawing.Point(3, 3);
            this.dgvDescription.Name = "dgvDescription";
            this.dgvDescription.ReadOnly = true;
            this.dgvDescription.RowTemplate.Height = 28;
            this.dgvDescription.Size = new System.Drawing.Size(1392, 555);
            this.dgvDescription.TabIndex = 3;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.rbtn6682);
            this.groupBox3.Controls.Add(this.rbtn6681);
            this.groupBox3.Controls.Add(this.rbtn6622);
            this.groupBox3.Controls.Add(this.rbtn2043);
            this.groupBox3.Controls.Add(this.rbtn6688);
            this.groupBox3.Controls.Add(this.rbtn6684);
            this.groupBox3.Controls.Add(this.rbtn6623);
            this.groupBox3.Controls.Add(this.rBtn7362);
            this.groupBox3.Controls.Add(this.rBtn7360);
            this.groupBox3.Controls.Add(this.rBtn7358);
            this.groupBox3.Controls.Add(this.rBtn7350);
            this.groupBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox3.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox3.Location = new System.Drawing.Point(9, 106);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(97, 449);
            this.groupBox3.TabIndex = 54;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Clases:";
            // 
            // rbtn6682
            // 
            this.rbtn6682.AutoSize = true;
            this.rbtn6682.Location = new System.Drawing.Point(6, 310);
            this.rbtn6682.Name = "rbtn6682";
            this.rbtn6682.Size = new System.Drawing.Size(70, 24);
            this.rbtn6682.TabIndex = 62;
            this.rbtn6682.Text = "6682";
            this.rbtn6682.UseVisualStyleBackColor = true;
            this.rbtn6682.Click += new System.EventHandler(this.rbtn6682_Click);
            // 
            // rbtn6681
            // 
            this.rbtn6681.AutoSize = true;
            this.rbtn6681.Location = new System.Drawing.Point(6, 275);
            this.rbtn6681.Name = "rbtn6681";
            this.rbtn6681.Size = new System.Drawing.Size(70, 24);
            this.rbtn6681.TabIndex = 61;
            this.rbtn6681.Text = "6681";
            this.rbtn6681.UseVisualStyleBackColor = true;
            this.rbtn6681.Click += new System.EventHandler(this.rbtn6681_Click);
            // 
            // rbtn6622
            // 
            this.rbtn6622.AutoSize = true;
            this.rbtn6622.Location = new System.Drawing.Point(6, 205);
            this.rbtn6622.Name = "rbtn6622";
            this.rbtn6622.Size = new System.Drawing.Size(70, 24);
            this.rbtn6622.TabIndex = 60;
            this.rbtn6622.Text = "6622";
            this.rbtn6622.UseVisualStyleBackColor = true;
            this.rbtn6622.Click += new System.EventHandler(this.rbtn6622_Click);
            // 
            // rbtn2043
            // 
            this.rbtn2043.AutoSize = true;
            this.rbtn2043.Location = new System.Drawing.Point(6, 170);
            this.rbtn2043.Name = "rbtn2043";
            this.rbtn2043.Size = new System.Drawing.Size(70, 24);
            this.rbtn2043.TabIndex = 59;
            this.rbtn2043.Text = "2043";
            this.rbtn2043.UseVisualStyleBackColor = true;
            this.rbtn2043.Click += new System.EventHandler(this.rbtn2043_Click);
            // 
            // rbtn6688
            // 
            this.rbtn6688.AutoSize = true;
            this.rbtn6688.Location = new System.Drawing.Point(6, 380);
            this.rbtn6688.Name = "rbtn6688";
            this.rbtn6688.Size = new System.Drawing.Size(70, 24);
            this.rbtn6688.TabIndex = 58;
            this.rbtn6688.Text = "6688";
            this.rbtn6688.UseVisualStyleBackColor = true;
            this.rbtn6688.Click += new System.EventHandler(this.rbtn6688_Click);
            // 
            // rbtn6684
            // 
            this.rbtn6684.AutoSize = true;
            this.rbtn6684.Location = new System.Drawing.Point(6, 345);
            this.rbtn6684.Name = "rbtn6684";
            this.rbtn6684.Size = new System.Drawing.Size(70, 24);
            this.rbtn6684.TabIndex = 57;
            this.rbtn6684.Text = "6684";
            this.rbtn6684.UseVisualStyleBackColor = true;
            this.rbtn6684.Click += new System.EventHandler(this.rbtn6684_Click);
            // 
            // rbtn6623
            // 
            this.rbtn6623.AutoSize = true;
            this.rbtn6623.Location = new System.Drawing.Point(6, 240);
            this.rbtn6623.Name = "rbtn6623";
            this.rbtn6623.Size = new System.Drawing.Size(70, 24);
            this.rbtn6623.TabIndex = 56;
            this.rbtn6623.Text = "6623";
            this.rbtn6623.UseVisualStyleBackColor = true;
            this.rbtn6623.Click += new System.EventHandler(this.rbtn6623_Click);
            // 
            // rBtn7362
            // 
            this.rBtn7362.AutoSize = true;
            this.rBtn7362.Location = new System.Drawing.Point(6, 135);
            this.rBtn7362.Name = "rBtn7362";
            this.rBtn7362.Size = new System.Drawing.Size(70, 24);
            this.rBtn7362.TabIndex = 55;
            this.rBtn7362.Text = "7362";
            this.rBtn7362.UseVisualStyleBackColor = true;
            this.rBtn7362.Click += new System.EventHandler(this.rBtn7362_Click);
            // 
            // rBtn7360
            // 
            this.rBtn7360.AutoSize = true;
            this.rBtn7360.Location = new System.Drawing.Point(6, 100);
            this.rBtn7360.Name = "rBtn7360";
            this.rBtn7360.Size = new System.Drawing.Size(70, 24);
            this.rBtn7360.TabIndex = 54;
            this.rBtn7360.Text = "7360";
            this.rBtn7360.UseVisualStyleBackColor = true;
            this.rBtn7360.Click += new System.EventHandler(this.rBtn7360_Click);
            // 
            // rBtn7358
            // 
            this.rBtn7358.AutoSize = true;
            this.rBtn7358.Location = new System.Drawing.Point(6, 65);
            this.rBtn7358.Name = "rBtn7358";
            this.rBtn7358.Size = new System.Drawing.Size(70, 24);
            this.rBtn7358.TabIndex = 53;
            this.rBtn7358.Text = "7358";
            this.rBtn7358.UseVisualStyleBackColor = true;
            this.rBtn7358.Click += new System.EventHandler(this.rBtn7358_Click);
            // 
            // rBtn7350
            // 
            this.rBtn7350.AutoSize = true;
            this.rBtn7350.Location = new System.Drawing.Point(6, 30);
            this.rBtn7350.Name = "rBtn7350";
            this.rBtn7350.Size = new System.Drawing.Size(70, 24);
            this.rBtn7350.TabIndex = 52;
            this.rBtn7350.Text = "7350";
            this.rBtn7350.UseVisualStyleBackColor = true;
            this.rBtn7350.Click += new System.EventHandler(this.rBtn7350_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.dgviFactory);
            this.tabPage2.Controls.Add(this.rTxtBoxEJL);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Controls.Add(this.txtTracerOrWip);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1519, 573);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "INFO UNIT";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label6.Location = new System.Drawing.Point(524, -1);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 17);
            this.label6.TabIndex = 80;
            this.label6.Text = "iFactory History:";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label5.Location = new System.Drawing.Point(1005, -1);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 17);
            this.label5.TabIndex = 54;
            this.label5.Text = "Current Log:";
            // 
            // dgviFactory
            // 
            this.dgviFactory.AllowUserToAddRows = false;
            this.dgviFactory.AllowUserToDeleteRows = false;
            this.dgviFactory.AllowUserToResizeColumns = false;
            this.dgviFactory.AllowUserToResizeRows = false;
            this.dgviFactory.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.dgviFactory.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.dgviFactory.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgviFactory.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgviFactory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgviFactory.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgviFactory.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.dgviFactory.Location = new System.Drawing.Point(527, 19);
            this.dgviFactory.Name = "dgviFactory";
            this.dgviFactory.ReadOnly = true;
            this.dgviFactory.RowTemplate.Height = 28;
            this.dgviFactory.Size = new System.Drawing.Size(472, 546);
            this.dgviFactory.TabIndex = 79;
            // 
            // rTxtBoxEJL
            // 
            this.rTxtBoxEJL.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.rTxtBoxEJL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.rTxtBoxEJL.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rTxtBoxEJL.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.rTxtBoxEJL.Location = new System.Drawing.Point(1008, 19);
            this.rTxtBoxEJL.Name = "rTxtBoxEJL";
            this.rTxtBoxEJL.Size = new System.Drawing.Size(494, 546);
            this.rTxtBoxEJL.TabIndex = 78;
            this.rTxtBoxEJL.Text = "";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label7.Location = new System.Drawing.Point(147, 86);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(92, 17);
            this.label7.TabIndex = 4;
            this.label7.Text = "press enter...";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.groupBox1.Controls.Add(this.txtBoxClass);
            this.groupBox1.Controls.Add(this.txtBoxTracer);
            this.groupBox1.Controls.Add(this.txtBoxWip);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox1.Location = new System.Drawing.Point(15, 111);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(209, 426);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Unit information";
            // 
            // txtBoxClass
            // 
            this.txtBoxClass.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.txtBoxClass.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBoxClass.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.txtBoxClass.Location = new System.Drawing.Point(6, 116);
            this.txtBoxClass.Name = "txtBoxClass";
            this.txtBoxClass.ReadOnly = true;
            this.txtBoxClass.Size = new System.Drawing.Size(197, 19);
            this.txtBoxClass.TabIndex = 7;
            this.txtBoxClass.Text = "Class:";
            // 
            // txtBoxTracer
            // 
            this.txtBoxTracer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.txtBoxTracer.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBoxTracer.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.txtBoxTracer.Location = new System.Drawing.Point(6, 42);
            this.txtBoxTracer.Name = "txtBoxTracer";
            this.txtBoxTracer.ReadOnly = true;
            this.txtBoxTracer.Size = new System.Drawing.Size(197, 19);
            this.txtBoxTracer.TabIndex = 5;
            this.txtBoxTracer.Text = "Tracer:";
            // 
            // txtBoxWip
            // 
            this.txtBoxWip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.txtBoxWip.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBoxWip.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.txtBoxWip.Location = new System.Drawing.Point(6, 79);
            this.txtBoxWip.Name = "txtBoxWip";
            this.txtBoxWip.ReadOnly = true;
            this.txtBoxWip.Size = new System.Drawing.Size(197, 19);
            this.txtBoxWip.TabIndex = 6;
            this.txtBoxWip.Text = "Wip:";
            // 
            // txtTracerOrWip
            // 
            this.txtTracerOrWip.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtTracerOrWip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.txtTracerOrWip.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTracerOrWip.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.txtTracerOrWip.Location = new System.Drawing.Point(15, 52);
            this.txtTracerOrWip.Name = "txtTracerOrWip";
            this.txtTracerOrWip.Size = new System.Drawing.Size(209, 19);
            this.txtTracerOrWip.TabIndex = 1;
            this.txtTracerOrWip.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtTracerOrWip_KeyDown);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label1.Location = new System.Drawing.Point(11, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tracer o Wip:";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.rbtnNotePad);
            this.tabPage3.Controls.Add(this.rbtnVisualStudio);
            this.tabPage3.Controls.Add(this.btnOpenScript);
            this.tabPage3.Controls.Add(this.chBoxAutoOpenPangaea);
            this.tabPage3.Controls.Add(this.chBoxAutoClosePangaea);
            this.tabPage3.Controls.Add(this.btnSave);
            this.tabPage3.Controls.Add(this.btnGetScripts);
            this.tabPage3.Controls.Add(this.btnUpdate);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.txtPathSCripts);
            this.tabPage3.Controls.Add(this.label2);
            this.tabPage3.Controls.Add(this.cBoxScripts);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1519, 573);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "DEBUG SCRIPTS";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // rbtnNotePad
            // 
            this.rbtnNotePad.AutoSize = true;
            this.rbtnNotePad.Location = new System.Drawing.Point(631, 192);
            this.rbtnNotePad.Name = "rbtnNotePad";
            this.rbtnNotePad.Size = new System.Drawing.Size(132, 24);
            this.rbtnNotePad.TabIndex = 60;
            this.rbtnNotePad.TabStop = true;
            this.rbtnNotePad.Text = "NOTEPAD ++";
            this.rbtnNotePad.UseVisualStyleBackColor = true;
            // 
            // rbtnVisualStudio
            // 
            this.rbtnVisualStudio.AutoSize = true;
            this.rbtnVisualStudio.Location = new System.Drawing.Point(631, 146);
            this.rbtnVisualStudio.Name = "rbtnVisualStudio";
            this.rbtnVisualStudio.Size = new System.Drawing.Size(56, 24);
            this.rbtnVisualStudio.TabIndex = 59;
            this.rbtnVisualStudio.TabStop = true;
            this.rbtnVisualStudio.Text = "VS";
            this.rbtnVisualStudio.UseVisualStyleBackColor = true;
            // 
            // btnOpenScript
            // 
            this.btnOpenScript.Location = new System.Drawing.Point(447, 146);
            this.btnOpenScript.Name = "btnOpenScript";
            this.btnOpenScript.Size = new System.Drawing.Size(154, 70);
            this.btnOpenScript.TabIndex = 58;
            this.btnOpenScript.Text = "OPEN SCRIPT";
            this.btnOpenScript.UseVisualStyleBackColor = true;
            // 
            // chBoxAutoOpenPangaea
            // 
            this.chBoxAutoOpenPangaea.AutoSize = true;
            this.chBoxAutoOpenPangaea.Location = new System.Drawing.Point(816, 139);
            this.chBoxAutoOpenPangaea.Name = "chBoxAutoOpenPangaea";
            this.chBoxAutoOpenPangaea.Size = new System.Drawing.Size(177, 24);
            this.chBoxAutoOpenPangaea.TabIndex = 57;
            this.chBoxAutoOpenPangaea.Text = "Auto open Pangaea";
            this.chBoxAutoOpenPangaea.UseVisualStyleBackColor = true;
            // 
            // chBoxAutoClosePangaea
            // 
            this.chBoxAutoClosePangaea.AutoSize = true;
            this.chBoxAutoClosePangaea.Location = new System.Drawing.Point(816, 98);
            this.chBoxAutoClosePangaea.Name = "chBoxAutoClosePangaea";
            this.chBoxAutoClosePangaea.Size = new System.Drawing.Size(178, 24);
            this.chBoxAutoClosePangaea.TabIndex = 56;
            this.chBoxAutoClosePangaea.Text = "Auto close Pangaea";
            this.chBoxAutoClosePangaea.UseVisualStyleBackColor = true;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(841, 6);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(154, 71);
            this.btnSave.TabIndex = 54;
            this.btnSave.Text = "SAVE SETTINGS";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnGetScripts
            // 
            this.btnGetScripts.Location = new System.Drawing.Point(257, 232);
            this.btnGetScripts.Name = "btnGetScripts";
            this.btnGetScripts.Size = new System.Drawing.Size(154, 70);
            this.btnGetScripts.TabIndex = 5;
            this.btnGetScripts.Text = "GET SCRIPTS";
            this.btnGetScripts.UseVisualStyleBackColor = true;
            this.btnGetScripts.Click += new System.EventHandler(this.btnGetScripts_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(14, 358);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(484, 127);
            this.btnUpdate.TabIndex = 4;
            this.btnUpdate.Text = "Copy Script To Pangaea";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(146, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Server Path scripts:";
            // 
            // txtPathSCripts
            // 
            this.txtPathSCripts.Location = new System.Drawing.Point(19, 82);
            this.txtPathSCripts.Name = "txtPathSCripts";
            this.txtPathSCripts.Size = new System.Drawing.Size(744, 26);
            this.txtPathSCripts.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 162);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Script:";
            // 
            // cBoxScripts
            // 
            this.cBoxScripts.FormattingEnabled = true;
            this.cBoxScripts.Location = new System.Drawing.Point(19, 188);
            this.cBoxScripts.Name = "cBoxScripts";
            this.cBoxScripts.Size = new System.Drawing.Size(392, 28);
            this.cBoxScripts.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.tabPage4.Controls.Add(this.lblDetails);
            this.tabPage4.Controls.Add(this.label10);
            this.tabPage4.Controls.Add(this.label9);
            this.tabPage4.Controls.Add(this.txtFindLogsVerifyAudit);
            this.tabPage4.Controls.Add(this.label8);
            this.tabPage4.Controls.Add(this.btnPangaea02);
            this.tabPage4.Controls.Add(this.btnPangaea01);
            this.tabPage4.Controls.Add(this.btnChirel01);
            this.tabPage4.Controls.Add(this.btnScriptsKits);
            this.tabPage4.Location = new System.Drawing.Point(4, 29);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1519, 573);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "SHORT CUTS";
            // 
            // lblDetails
            // 
            this.lblDetails.AutoSize = true;
            this.lblDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDetails.ForeColor = System.Drawing.Color.Firebrick;
            this.lblDetails.Location = new System.Drawing.Point(332, 91);
            this.lblDetails.Name = "lblDetails";
            this.lblDetails.Size = new System.Drawing.Size(0, 17);
            this.lblDetails.TabIndex = 66;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label10.Location = new System.Drawing.Point(533, 63);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 17);
            this.label10.TabIndex = 65;
            this.label10.Text = "enter...";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label9.Location = new System.Drawing.Point(324, 15);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 20);
            this.label9.TabIndex = 64;
            this.label9.Text = "Logs";
            // 
            // txtFindLogsVerifyAudit
            // 
            this.txtFindLogsVerifyAudit.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtFindLogsVerifyAudit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.txtFindLogsVerifyAudit.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtFindLogsVerifyAudit.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.txtFindLogsVerifyAudit.Location = new System.Drawing.Point(328, 63);
            this.txtFindLogsVerifyAudit.Name = "txtFindLogsVerifyAudit";
            this.txtFindLogsVerifyAudit.Size = new System.Drawing.Size(199, 19);
            this.txtFindLogsVerifyAudit.TabIndex = 63;
            this.txtFindLogsVerifyAudit.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtFindLogsVerifyAudit_KeyDown);
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label8.Location = new System.Drawing.Point(324, 35);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 20);
            this.label8.TabIndex = 61;
            this.label8.Text = "VerifyAudit:";
            // 
            // btnPangaea02
            // 
            this.btnPangaea02.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnPangaea02.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.btnPangaea02.FlatAppearance.BorderSize = 0;
            this.btnPangaea02.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPangaea02.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(173)))), ((int)(((byte)(157)))));
            this.btnPangaea02.Location = new System.Drawing.Point(14, 348);
            this.btnPangaea02.Name = "btnPangaea02";
            this.btnPangaea02.Size = new System.Drawing.Size(264, 100);
            this.btnPangaea02.TabIndex = 59;
            this.btnPangaea02.Text = "PANGAEA02";
            this.btnPangaea02.UseVisualStyleBackColor = false;
            this.btnPangaea02.Click += new System.EventHandler(this.btnPangaea02_Click);
            // 
            // btnPangaea01
            // 
            this.btnPangaea01.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnPangaea01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.btnPangaea01.FlatAppearance.BorderSize = 0;
            this.btnPangaea01.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPangaea01.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(173)))), ((int)(((byte)(157)))));
            this.btnPangaea01.Location = new System.Drawing.Point(14, 237);
            this.btnPangaea01.Name = "btnPangaea01";
            this.btnPangaea01.Size = new System.Drawing.Size(264, 100);
            this.btnPangaea01.TabIndex = 58;
            this.btnPangaea01.Text = "PANGAEA01";
            this.btnPangaea01.UseVisualStyleBackColor = false;
            this.btnPangaea01.Click += new System.EventHandler(this.btnPangaea01_Click);
            // 
            // btnChirel01
            // 
            this.btnChirel01.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnChirel01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.btnChirel01.FlatAppearance.BorderSize = 0;
            this.btnChirel01.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChirel01.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(173)))), ((int)(((byte)(157)))));
            this.btnChirel01.Location = new System.Drawing.Point(14, 15);
            this.btnChirel01.Name = "btnChirel01";
            this.btnChirel01.Size = new System.Drawing.Size(264, 100);
            this.btnChirel01.TabIndex = 56;
            this.btnChirel01.Text = "CHIREL01\\NCR";
            this.btnChirel01.UseVisualStyleBackColor = false;
            this.btnChirel01.Click += new System.EventHandler(this.btnChirel01_Click);
            // 
            // btnScriptsKits
            // 
            this.btnScriptsKits.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnScriptsKits.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.btnScriptsKits.FlatAppearance.BorderSize = 0;
            this.btnScriptsKits.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnScriptsKits.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(173)))), ((int)(((byte)(157)))));
            this.btnScriptsKits.Location = new System.Drawing.Point(14, 126);
            this.btnScriptsKits.Name = "btnScriptsKits";
            this.btnScriptsKits.Size = new System.Drawing.Size(264, 100);
            this.btnScriptsKits.TabIndex = 55;
            this.btnScriptsKits.Text = "SCRIPTS KITS";
            this.btnScriptsKits.UseVisualStyleBackColor = false;
            this.btnScriptsKits.Click += new System.EventHandler(this.btnScriptsKits_Click);
            // 
            // lblCurrentInfo
            // 
            this.lblCurrentInfo.AutoSize = true;
            this.lblCurrentInfo.BackColor = System.Drawing.Color.Transparent;
            this.lblCurrentInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentInfo.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblCurrentInfo.Location = new System.Drawing.Point(1, 75);
            this.lblCurrentInfo.Name = "lblCurrentInfo";
            this.lblCurrentInfo.Size = new System.Drawing.Size(86, 17);
            this.lblCurrentInfo.TabIndex = 15;
            this.lblCurrentInfo.Text = "Current info:";
            // 
            // btnTab1
            // 
            this.btnTab1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTab1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.btnTab1.FlatAppearance.BorderSize = 0;
            this.btnTab1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTab1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(173)))), ((int)(((byte)(157)))));
            this.btnTab1.Location = new System.Drawing.Point(791, 89);
            this.btnTab1.Name = "btnTab1";
            this.btnTab1.Size = new System.Drawing.Size(150, 70);
            this.btnTab1.TabIndex = 52;
            this.btnTab1.Text = "FEATURES BY MC";
            this.btnTab1.UseVisualStyleBackColor = false;
            this.btnTab1.Click += new System.EventHandler(this.btnTab1_Click);
            // 
            // btnTab2
            // 
            this.btnTab2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTab2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.btnTab2.FlatAppearance.BorderSize = 0;
            this.btnTab2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTab2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(173)))), ((int)(((byte)(157)))));
            this.btnTab2.Location = new System.Drawing.Point(947, 89);
            this.btnTab2.Name = "btnTab2";
            this.btnTab2.Size = new System.Drawing.Size(150, 70);
            this.btnTab2.TabIndex = 53;
            this.btnTab2.Text = "INFO UNIT";
            this.btnTab2.UseVisualStyleBackColor = false;
            this.btnTab2.Click += new System.EventHandler(this.btnTab2_Click);
            // 
            // btnShortCuts
            // 
            this.btnShortCuts.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnShortCuts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.btnShortCuts.FlatAppearance.BorderSize = 0;
            this.btnShortCuts.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnShortCuts.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(173)))), ((int)(((byte)(157)))));
            this.btnShortCuts.Location = new System.Drawing.Point(1103, 89);
            this.btnShortCuts.Name = "btnShortCuts";
            this.btnShortCuts.Size = new System.Drawing.Size(150, 70);
            this.btnShortCuts.TabIndex = 54;
            this.btnShortCuts.Text = "SHORT CUTS";
            this.btnShortCuts.UseVisualStyleBackColor = false;
            this.btnShortCuts.Click += new System.EventHandler(this.btnShortCuts_Click);
            // 
            // txtSearchFeature
            // 
            this.txtSearchFeature.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtSearchFeature.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.txtSearchFeature.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSearchFeature.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.txtSearchFeature.Location = new System.Drawing.Point(12, 47);
            this.txtSearchFeature.Name = "txtSearchFeature";
            this.txtSearchFeature.Size = new System.Drawing.Size(94, 19);
            this.txtSearchFeature.TabIndex = 57;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label11.Location = new System.Drawing.Point(11, 19);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(69, 20);
            this.label11.TabIndex = 56;
            this.label11.Text = "Feature:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.ClientSize = new System.Drawing.Size(1527, 771);
            this.Controls.Add(this.btnShortCuts);
            this.Controls.Add(this.lblCurrentInfo);
            this.Controls.Add(this.btnTab2);
            this.Controls.Add(this.btnTab1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "NCR TE";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabControl2.ResumeLayout(false);
            this.tabPageSettings.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvStrings)).EndInit();
            this.tabPageDesc.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDescription)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgviFactory)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnMinimize;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton rBtn7362;
        private System.Windows.Forms.RadioButton rBtn7360;
        private System.Windows.Forms.RadioButton rBtn7358;
        private System.Windows.Forms.RadioButton rBtn7350;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPageSettings;
        private System.Windows.Forms.DataGridView dgvStrings;
        private System.Windows.Forms.DataGridView dgvDescription;
        private System.Windows.Forms.TabPage tabPageDesc;
        private System.Windows.Forms.Label lblCurrentInfo;
        private System.Windows.Forms.RadioButton rbtn6623;
        private System.Windows.Forms.RadioButton rbtn6622;
        private System.Windows.Forms.RadioButton rbtn2043;
        private System.Windows.Forms.RadioButton rbtn6688;
        private System.Windows.Forms.RadioButton rbtn6684;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtTracerOrWip;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBoxClass;
        private System.Windows.Forms.TextBox txtBoxTracer;
        private System.Windows.Forms.TextBox txtBoxWip;
        private System.Windows.Forms.RichTextBox rTxtBoxEJL;
        private System.Windows.Forms.DataGridView dgviFactory;
        private System.Windows.Forms.RadioButton rbtn6681;
        private System.Windows.Forms.RadioButton rbtn6682;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPathSCripts;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cBoxScripts;
        private System.Windows.Forms.Button btnGetScripts;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.CheckBox chBoxAutoOpenPangaea;
        private System.Windows.Forms.CheckBox chBoxAutoClosePangaea;
        private System.Windows.Forms.RadioButton rbtnNotePad;
        private System.Windows.Forms.RadioButton rbtnVisualStudio;
        private System.Windows.Forms.Button btnOpenScript;
        private System.Windows.Forms.Button btnTab1;
        private System.Windows.Forms.Button btnTab2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnShortCuts;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button btnPangaea01;
        private System.Windows.Forms.Button btnChirel01;
        private System.Windows.Forms.Button btnScriptsKits;
        private System.Windows.Forms.Button btnPangaea02;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtFindLogsVerifyAudit;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblDetails;
        private System.Windows.Forms.TextBox txtSearchFeature;
        private System.Windows.Forms.Label label11;
    }
}

