﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SSCOMonitor
{
    public partial class SideBar : Form
    {
        public SideBar(Point _CurrentLocation)
        {
            InitializeComponent();

            _location = _CurrentLocation;
        }

        Point _location;


        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        private void Form1_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void SideBar_Load(object sender, EventArgs e)
        {
            this.Width = 80;
            this.Height = 80;
            if (_location.X == 0 && _location.Y == 0)
            {
                this.DesktopLocation = new Point(Screen.PrimaryScreen.WorkingArea.Width - this.Width, 0); //970, 522 
            }
            else
            {
                this.DesktopLocation = _location;
           }

        
            
        }

        private void btnSideBar_Click(object sender, EventArgs e)
        {
            _location = this.DesktopLocation;
            this.Hide();
            Form1 _form1 = new Form1(_location);
            _form1.Show();
        }

        private void SideBar_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void btnSideBar_MouseDown(object sender, MouseEventArgs e)
        {
    
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }

           _location = this.Location;
        }

        private void EXIT_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
