﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using iFactoryInfo;

namespace SSCOMonitor
{
    public partial class Form1 : Form
    {
        public Form1(Point _CurrentLocation)
        {
            InitializeComponent();
            InicializarDataGridView();

            _location = _CurrentLocation;
        }


        //Globals
        Point _location;
        string _pathFeaturesDescription = @"\\mxchim0pangea01\diskbld\stdcore\feature.txt";
        string _pathFeats = @"\\mxchim0pangea01\diskbld\feats\Feat";
        string pathHML = @"\\mxchim0pangea01\HTML\Journal\MlnCUU\";

        const int WM_SYSCOMMAND = 0x112;
        const int MOUSE_MOVE = 0xF012;

        iFactoryInfo.iFactoryInfo _iFactoryInfo = new iFactoryInfo.iFactoryInfo();

        Color _mainColor = Color.FromArgb(16, 29, 37);

        void InicializarDataGridView()
        {
            //dgvFailures.Columns.Add("status", "Status");
            dgvStrings.Columns.Add("Classmc", "CLASS MC");
            dgvStrings.Columns.Add("String", "FEATURES STRING");

            dgvStrings.Columns["Classmc"].Width = 125;
            dgvStrings.Columns["String"].Width = 700;
            dgvStrings.RowHeadersVisible = false;

            dgvDescription.Columns.Add("Description", "DESCRIPTION");
            dgvDescription.Columns["Description"].Width = 700;
            dgvDescription.RowHeadersVisible = false;

            dgviFactory.Columns.Add("ArrivalTime", "ARRIVAL TIME");
            dgviFactory.Columns.Add("StepName", "STEP NAME");
            dgviFactory.Columns.Add("StepStatus", "STATUS");

            dgviFactory.Columns["ArrivalTime"].Width = 100;
            dgviFactory.Columns["StepName"].Width = 150;
            dgviFactory.Columns["StepStatus"].Width = 100;
            dgviFactory.RowHeadersVisible = false;

        }

        private void rBtn7350_Click(object sender, EventArgs e)
        {
            dgvStrings.Rows.Clear();
            tabControl2.SelectedTab = tabPageSettings;
            GetFeatsFile("7350");
        }

        private void rBtn7358_Click(object sender, EventArgs e)
        {
            dgvStrings.Rows.Clear();
            tabControl2.SelectedTab = tabPageSettings;
            GetFeatsFile("7358");
        }

        private void rBtn7360_Click(object sender, EventArgs e)
        {
            dgvStrings.Rows.Clear();
            tabControl2.SelectedTab = tabPageSettings;
            GetFeatsFile("7360");
        }

        private void rBtn7362_Click(object sender, EventArgs e)
        {
            dgvStrings.Rows.Clear();
            tabControl2.SelectedTab = tabPageSettings;
            GetFeatsFile("7362");
        }

        private void rbtn2043_Click(object sender, EventArgs e)
        {
            dgvStrings.Rows.Clear();
            tabControl2.SelectedTab = tabPageSettings;
            GetFeatsFile("2043");
        }

        private void rbtn6622_Click(object sender, EventArgs e)
        {
            dgvStrings.Rows.Clear();
            tabControl2.SelectedTab = tabPageSettings;
            GetFeatsFile("6622");
        }

        private void rbtn6623_Click(object sender, EventArgs e)
        {
            dgvStrings.Rows.Clear();
            tabControl2.SelectedTab = tabPageSettings;
            GetFeatsFile("6623");
        }

        private void rbtn6681_Click(object sender, EventArgs e)
        {
            dgvStrings.Rows.Clear();
            tabControl2.SelectedTab = tabPageSettings;
            GetFeatsFile("6681");
        }

        private void rbtn6682_Click(object sender, EventArgs e)
        {
            dgvStrings.Rows.Clear();
            tabControl2.SelectedTab = tabPageSettings;
            GetFeatsFile("6682");
        }

        private void rbtn6684_Click(object sender, EventArgs e)
        {
            dgvStrings.Rows.Clear();
            tabControl2.SelectedTab = tabPageSettings;
            GetFeatsFile("6684");
        }

        private void rbtn6688_Click(object sender, EventArgs e)
        {
            dgvStrings.Rows.Clear();
            tabControl2.SelectedTab = tabPageSettings;
            GetFeatsFile("6688");
        }

        void GetFeatsFile(string Class)
        {

            string[] _Lines = { "" };
            string[] _split = { "" };

            int i = 0;
            int _space = 15;

            try
            {
                _Lines = File.ReadAllLines(_pathFeats + Class);

                foreach (string _line in _Lines)
                {
                    if (!_line.Contains("#"))
                    {
                        _split = _line.Split(' ');
                        i = _space - _split[0].Length;


                        if (txtSearchFeature.Text != "")
                        {
                            if (_split[i].Contains(txtSearchFeature.Text.ToUpper()))
                            {
                                _mainColor = Color.IndianRed;
                            }
                            else
                            {
                                _mainColor = Color.FromArgb(16, 29, 37);
                            }

                        }


                        WriteDGV("dgvStrings", _split[0], _split[i], string.Empty, string.Empty, string.Empty, string.Empty);
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        void GetFeatsDecription(string ClassMC, string StringFeats)
        {
            string[] _FeatsDescription = { "" };
            string[] _split = { "" };
            string[] _splitClassMC = { "" };
            string _Result = string.Empty;
            List<string> _list = new List<string>();

            try
            {
                _splitClassMC = ClassMC.Split('-');
                ClassMC = _splitClassMC[0];

                _split = StringFeats.Split(new[] { ClassMC }, StringSplitOptions.None);

                foreach (string feat in _split)
                {
                    if (feat != "")
                    {
                        _Result = File.ReadAllLines(_pathFeaturesDescription).Where(x => x.Contains(feat.ToUpper() + " " + ClassMC)).FirstOrDefault();


                        if (_Result.Contains("US$"))
                        {
                            string INT = string.Empty;
                        }

                        if (_Result == null)
                        {
                            _list.Add(feat + " " + "NO DATA FOUND");
                            goto next;
                        }
                        _list.Add(_Result);

                        next: { };
                    }
                }

                foreach (string _description in _list.ToArray())
                {
                    WriteDGV("dgvDescription", string.Empty, string.Empty, _description, string.Empty, string.Empty, string.Empty);
                }

                tabControl2.SelectedTab = tabPageDesc;
            }
            catch (Exception ex)
            {

            }
        }


        void WriteDGV(string DGVID, string ClassMc, string FeatString, string Description, string ArrivalTime, string StepName, string StepStatus)
        {
            if (DGVID == "dgvDescription")
            {
                dgvDescription.Rows.Add(new Object[]
                     {
                          Description
                     });

                dgvDescription.ForeColor = Color.WhiteSmoke;
                dgvDescription.Rows[dgvDescription.Rows.Count - 1].DefaultCellStyle.BackColor = _mainColor;
                dgvDescription.CurrentCell = dgvDescription.Rows[dgvDescription.Rows.Count - 1].Cells[0];
                this.Update();
            }

            if (DGVID == "dgvStrings")
            {
                dgvStrings.Rows.Add(new Object[]
                      {
                          ClassMc, FeatString
                      });


                dgvStrings.ForeColor = Color.WhiteSmoke;
                dgvStrings.Rows[dgvStrings.Rows.Count - 1].DefaultCellStyle.BackColor = _mainColor;
                dgvStrings.CurrentCell = dgvStrings.Rows[dgvStrings.Rows.Count - 1].Cells[0];
                this.Update();
            }

            if (DGVID == "dgviFactory")
            {
                dgviFactory.Rows.Add(new Object[]
                     {
                          ArrivalTime, StepName, StepStatus
                     });

                Color _mainColor = Color.FromArgb(16, 29, 37);
                dgviFactory.ForeColor = Color.WhiteSmoke;
                dgviFactory.Rows[dgviFactory.Rows.Count - 1].DefaultCellStyle.BackColor = _mainColor;
                dgviFactory.CurrentCell = dgviFactory.Rows[dgviFactory.Rows.Count - 1].Cells[0];
                this.Update();
            }
        }

        private void txtTracerOrWip_KeyDown(object sender, KeyEventArgs e)
        {
            string _Tracer = string.Empty;

            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab)
            {
                _Tracer = GetInfoIfactory(txtTracerOrWip.Text);
                txtTracerOrWip.Clear();
                ReadEJLFromHTML(_Tracer);
                GetHistoryFromIfactory(_Tracer);
            }
        }

        string GetInfoIfactory(string tracerOrWip)
        {
            string[] _UnifInfo = { "" };
            string _result = string.Empty;

            if (tracerOrWip.Length == 8)
            {
                _UnifInfo = _iFactoryInfo.GetSCMC(tracerOrWip);
                txtBoxTracer.Text = "Tracer: " + tracerOrWip;
                txtBoxWip.Text = "Wip: " + _UnifInfo[0];
                txtBoxClass.Text = "Class: " + _UnifInfo[1] + "MC" + _UnifInfo[2];
                _result = tracerOrWip;
            }

            if (tracerOrWip.Length == 11)
            {
                _UnifInfo = _iFactoryInfo.GetWIPInfo(tracerOrWip);
                txtBoxTracer.Text = "Tracer: " + _UnifInfo[1];
                txtBoxWip.Text = "Wip: " + _UnifInfo[0];
                txtBoxClass.Text = "Class: " + _UnifInfo[3];
                _result = _UnifInfo[1];
            }
            txtTracerOrWip.Clear();
            return _result;
        }

        void ReadEJLFromHTML(string Tracer)
        {
            string _EjlFile = string.Empty;
            try
            {
                _EjlFile = File.ReadAllText(pathHML + Tracer + ".ejl");
                rTxtBoxEJL.Text = _EjlFile;
            }
            catch (Exception ex)
            {
                rTxtBoxEJL.Text = ex.Message;
            }

        }

        void GetHistoryFromIfactory(string Tracer)
        {
            DataSet _ds;
            DataTable _dt;
            string[] _unitInfo = { "" };
            int Loops = 0;
            int numSteps = 0;

            _unitInfo = _iFactoryInfo.GetSCMC(Tracer);

            _ds = _iFactoryInfo.GetHistory(_unitInfo[0]);

            _dt = _ds.Tables[0];

            numSteps = _dt.Rows.Count;
            numSteps = numSteps - 1;

            while (Loops <= numSteps)
            {
                var varArrival = _dt.Rows[Loops]["ArrivalTime"];
                string ArrivalTime = varArrival.ToString().Trim();

                var varStep = _dt.Rows[Loops]["ProcessName"];
                string StepName = varStep.ToString().Trim();

                var varStepStatus = _dt.Rows[Loops]["ProcessResult"];
                string StepStatus = varStepStatus.ToString();

                WriteDGV("dgviFactory", string.Empty, string.Empty, string.Empty, ArrivalTime, StepName, StepStatus);
                Loops = Loops + 1;
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            SideBar sideBar = new SideBar(_location);
            sideBar.Show();
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.Hide();
            SideBar sideBar = new SideBar(_location);
            sideBar.Show();
        }

        private void dgvStrings_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            string ClassMC = "";
            string StringFeats = "";

            dgvDescription.Rows.Clear();

            if (e.ColumnIndex == 0)
            {
                ClassMC = dgvStrings.Rows[e.RowIndex].Cells[0].Value.ToString();
                StringFeats = dgvStrings.Rows[e.RowIndex].Cells[1].Value.ToString();

                lblCurrentInfo.Text = "Current info: " + ClassMC;
                GetFeatsDecription(ClassMC, StringFeats);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            this.DesktopLocation = new Point(Screen.PrimaryScreen.WorkingArea.Width - this.Width, Screen.PrimaryScreen.WorkingArea.Height - this.Height); //970, 522
            lblVersion.Text = "1.0.0.4";

            tabControl1.DrawMode = TabDrawMode.OwnerDrawFixed;
            tabControl1.Region = new Region(new RectangleF(this.tabPage1.Left, this.tabPage1.Top, this.tabPage1.Width, this.tabPage1.Height));

            tabControl2.DrawMode = TabDrawMode.OwnerDrawFixed;
            tabControl2.Region = new Region(new RectangleF(this.tabPageSettings.Left, this.tabPageSettings.Top, this.tabPageSettings.Width, this.tabPageSettings.Height));

            //txtPathSCripts.Text = Properties.Settings.Default.PathScripts;
            //GetScriptsFromPath();
        }

        [System.Runtime.InteropServices.DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [System.Runtime.InteropServices.DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);

        private void moverForm()
        {
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, MOUSE_MOVE, 0);
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            moverForm();
        }


        string PangaeaFinancial = @"C:\Pangaea\PangaeaFinancial\GUI\PangaeaFinancial.exe";
        string PangaeaTestScripts = @"C:\Pangaea\PangaeaFinancial\GUI\TestScripts\";

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (cBoxScripts.Text == "")
                {
                    MessageBox.Show("Seleccione script a copiar...");
                    return;
                }

                if (chBoxAutoClosePangaea.Checked)
                {
                    CloseExe();
                }

                File.Copy(NCRTE.Properties.Settings.Default.PathScripts + cBoxScripts.Text, PangaeaTestScripts + cBoxScripts.Text, true);


                if (chBoxAutoOpenPangaea.Checked)
                {
                    OpenExe(PangaeaFinancial, string.Empty);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }




        string OpenExe(string FileName, string Args)
        {
            string _ProgStatus = "";
            Process _process = new Process();
            _process.StartInfo.FileName = FileName;
            _process.Start();
            _process.WaitForExit();
            return _ProgStatus;
        }

        void CloseExe()
        {
            Process[] _process = Process.GetProcessesByName("PangaeaFinancial");

            if (_process.Length > 0)
            {
                _process[0].Kill();
            }

        }

        void GetScriptsFromPath()
        {
            if (txtPathSCripts.Text == "")
            {
                MessageBox.Show("Agregar ruta de scripts para continuar....");
                return;
            }

            DirectoryInfo _directoryScripts = new DirectoryInfo(NCRTE.Properties.Settings.Default.PathScripts);

            if (!_directoryScripts.Exists)
            {
                MessageBox.Show("El path para los scripts seleccionado no existe...");
                return;
            }

            FileInfo[] _scripts = _directoryScripts.GetFiles("*.cs");

            foreach (FileInfo _Script in _scripts)
            {
                cBoxScripts.Items.Add(_Script.Name);
            }

        }

        private void btnGetScripts_Click(object sender, EventArgs e)
        {
            cBoxScripts.Items.Clear();
            GetScriptsFromPath();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {

        }

        private void btnTab1_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage1;
        }

        private void btnTab2_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage2;
        }

        private void btnShortCuts_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage4;
        }

        private void OpenFolder(string folderPath)
        {
            ProcessStartInfo startInto = new ProcessStartInfo();
            startInto.Arguments = folderPath;
            startInto.FileName = "explorer.exe";
            Process.Start(startInto);
        }

        private void btnChirel01_Click(object sender, EventArgs e)
        {
            OpenFolder(@"\\mxchim0rel01\NCR");
        }

        private void btnScriptsKits_Click(object sender, EventArgs e)
        {
            OpenFolder(@"\\mxchim0REL01\NCR\TEPrograms\SSCO\KITS SCRIPTS\");
        }

        private void btnPangaea01_Click(object sender, EventArgs e)
        {
            OpenFolder(@"\\mxchim0pangea01\");
        }

        private void btnPangaea02_Click(object sender, EventArgs e)
        {
            OpenFolder(@"\\mxchim0pangea02\");
        }

        int ExternalExe(string FileName, string Args, bool _waitForExit)
        {
            int _result = 0;
            Process _process = new Process();
            _process.StartInfo.FileName = FileName;
            _process.StartInfo.Arguments = Args;
            _process.StartInfo.WindowStyle = ProcessWindowStyle.Normal;
            _process.Start();
            if (_waitForExit) _process.WaitForExit();
            if (_waitForExit) _result = _process.ExitCode;
            return _result;
        }

        private void txtFindLogsVerifyAudit_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab)
            {
                if (txtFindLogsVerifyAudit.TextLength < 0) return;
                FindLogsVerifyAudit(txtFindLogsVerifyAudit.Text);




                 List<string> _listWin07 = new List<string>();
                 List<string> _listWin10 = new List<string>();
                string _ToAnalize = @"C:\ToAnalize\";
                try
                {

                    DirectoryInfo _directoryInfo = new DirectoryInfo(_ToAnalize);

                    FileInfo[] _filesInfo = _directoryInfo.GetFiles();


                    foreach (FileInfo _File in _filesInfo)
                    {
                        string FileRead = File.ReadAllText(_File.FullName);
                        string[] FileReadlINES = File.ReadAllLines(_File.FullName);

                        #region Filtrar por OS
                        if (FileRead.Contains("P099") || FileRead.Contains("P060") || FileRead.Contains("P999"))
                        {
                            _listWin07.Add(FileReadlINES[2] + " " + FileReadlINES[3] + " " + "WINDOWS 07");

                            File.Move(_File.FullName, @"C:\ToAnalize\WIN07\" + _File.Name);
                        }

                        if (FileRead.Contains("P100"))
                        {
                            _listWin10.Add(FileReadlINES[2] + " " + FileReadlINES[3] + " " + "WINDOWS 10");

                            File.Move(_File.FullName, @"C:\ToAnalize\WIN10\" + _File.Name);
                        }
                        #endregion
                    }


                    using (StreamWriter _sw = new StreamWriter(@"\\mxchim0pangea01\diskbld\!TempScripts\ToMike.txt"))
                    {
                        foreach (string list in _listWin07)
                        {
                            _sw.WriteLine(list);
                        }

                        foreach (string list in _listWin10)
                        {
                            _sw.WriteLine(list);
                        }
                        _sw.Close();
                    }


                    //string[] FromAra = File.ReadAllLines(@"\\mxchim0pangea01\diskbld\!TempScripts\ToAracelyRdz.txt");
                    //List<string> _SerialNumbers = new List<string>();

                    //foreach (string tracer in FromAra)
                    //{
                    //    if (!File.Exists(VerifyAndAuditPath + tracer + ".ejl")) goto skip;
                    //    string[] _linesFile = File.ReadAllLines(VerifyAndAuditPath + tracer + ".ejl");

                    //    _SerialNumbers.Add(_linesFile[1].Replace("SER NO. ", "57-"));



                    //    skip:
                    //    {

                    //    }
                    //}




                    //    using (StreamWriter _sw = new StreamWriter(@"\\mxchim0pangea01\diskbld\!TempScripts\TOAraNCR.txt"))
                    //    {
                    //        foreach(string list in _SerialNumbers)
                    //        {
                    //            _sw.WriteLine(list);
                    //        }

                    //        _sw.Close();
                    //    }
                    //}
                    //catch (Exception ex)
                    //{
                    //    MessageBox.Show("No se ha encontrado archivo");
                    //}

                }
                catch (Exception EX) { };
            }

            void FindLogsVerifyAudit(string Tracer)
            {
                string VerifyAndAuditPath = @"\\mxchim0pangea01\HTML\Journal\PangaeaTrial\VerifyAndAudit\";
                try
                {
                    //DirectoryInfo _dirInfo = new DirectoryInfo(VerifyAndAuditPath);
                    if (File.Exists(VerifyAndAuditPath + Tracer + ".ejl"))
                    {
                        object _file = VerifyAndAuditPath + Tracer + ".ejl";
                        ExternalExe("NOTEPAD.exe", _file.ToString(), false);
                        lblDetails.Text = string.Empty;
                    }
                    else lblDetails.Text = "No se encontro archivo";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("No se ha encontrado archivo");
                }
            }
        }
    }
}
