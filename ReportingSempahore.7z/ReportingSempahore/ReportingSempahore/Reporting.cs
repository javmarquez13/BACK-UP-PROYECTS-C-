﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReportingSempahore
{
    class Reporting
    {
        DataTable _tableXML;
        DataSet _ds;
        //string LOG = @"C:\XML\";
        string LOG = @"\\mxchim0pangea01\AUTOMATION_SSCO\Config Files\xml\";

        public void XMLSSCO()
        {
            _tableXML = new DataTable("SEMAPHORE_SSCO");
            _tableXML.Columns.Add("DATE");
            _tableXML.Columns.Add("TRACER");
            _tableXML.Columns.Add("CLASSMC");
            _tableXML.Columns.Add("SLOT");
            _tableXML.Columns.Add("IPADRESS");
            _tableXML.Columns.Add("STATUS");
            _tableXML.Columns.Add("COLOR");
        }

        public void CreateXML(DateTime DATE, string TRACER, string CLASSMC, string SLOT, string IPADRESS, string STATUS, string COLOR)
        {
            _tableXML.Rows.Add(DATE, TRACER, CLASSMC, SLOT, IPADRESS, STATUS, COLOR);

            _ds = new DataSet("SEMAPHORE");
            _ds.Tables.Add(_tableXML);
            string XML = _ds.GetXml();
            File.WriteAllText(LOG + TRACER + ".XML", XML);
            _ds.Tables.Remove(_tableXML);
        }
    }
}
