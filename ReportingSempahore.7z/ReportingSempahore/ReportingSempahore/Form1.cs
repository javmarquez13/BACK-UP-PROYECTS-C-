﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GetSerialClassMC;

namespace ReportingSempahore
{
    public partial class Form1 : Form
    {
        string Tracer;
        string ClassMC;
        string Status;
        string Color;
        string SlotID;
        string IpAdress;


        GetSerialClassMC.GetSerialClassMC GetSerialClassMC = new GetSerialClassMC.GetSerialClassMC();

        public Form1(string[] InputArgs)
        {
            InitializeComponent();

            Status = InputArgs[1];
            Color = InputArgs[2];
        }



        void GetInfoUnit()
        {
            Tracer = File.ReadLines(@"c:\build.typ").First();
            var item = GetSerialClassMC.GetSCMC(Tracer);
            ClassMC = item[1] + "-MC" + item[2];
        }

        void GetSlotInfo()
        {
            DirectoryInfo _dirInfo = new DirectoryInfo(@"C:\JABIL\UnitInfo\");
            FileInfo[] _filesInfo = _dirInfo.GetFiles();
            string[] _unitInfo = File.ReadAllLines(_filesInfo[0].FullName);
            SlotID = _unitInfo[3];
        }

        string GetLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }

            throw new Exception("No network adapters with an IPv4 address in the system!");
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
            this.Hide();
            GetInfoUnit();
            GetSlotInfo();
            IpAdress = GetLocalIPAddress();
            ReportingSemaphore(Tracer, ClassMC, SlotID, IpAdress, Status, Color);
            Environment.Exit(0);
        }


        void ReportingSemaphore(string TRACER, string CLASSMC, string SlotID, string IpAdress, string STATUS, string COLOR)
        {
            Reporting _reporting = new Reporting();
            _reporting.XMLSSCO();
            _reporting.CreateXML(DateTime.Now, TRACER, CLASSMC, SlotID, IpAdress, STATUS, COLOR);
        }

    }
}
