﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SemaphoreSSCOs;
using iFactoryInfo;

namespace NCR_SemaphorePreParser
{
    public partial class Form1 : Form
    {
        //Globales
        string _pathSSCO = @"\\mxchim0pangea01\AUTOMATION_SSCO\Config Files\xml\";
        string _pathSSCOProcessed = @"\\mxchim0pangea01\AUTOMATION_SSCO\Config Files\Processed\";

        //DB
        SemaphoreSSCOs.SemaphoreSSCOs _db = new SemaphoreSSCOs.SemaphoreSSCOs();
        iFactoryInfo.iFactoryInfo iFactoryInfo = new iFactoryInfo.iFactoryInfo();
        
        DataSet _ds = new DataSet();
        DataTable _dt = new DataTable();


        public Form1()
        {
            InitializeComponent();
            InicializarDataGridView();
            timer1.Start();

            
        }

        void InicializarDataGridView()
        {
            dgvSemaphore.Columns.Add("Date", "DATE");
            dgvSemaphore.Columns.Add("Tracer", "TRACER");
            dgvSemaphore.Columns.Add("Slot", "SLOT");
            dgvSemaphore.Columns.Add("IpAdress", "IP ADRESS");
            dgvSemaphore.Columns.Add("Status", "STATUS");
            dgvSemaphore.Columns.Add("Progress", "PROGRESS");
            dgvSemaphore.Columns["Date"].Width = 150;
            dgvSemaphore.Columns["Tracer"].Width = 70;
            dgvSemaphore.Columns["Slot"].Width = 50;
            dgvSemaphore.Columns["IpAdress"].Width = 80;
            dgvSemaphore.Columns["Status"].Width = 300;
            dgvSemaphore.Columns["Progress"].Width = 80;
            dgvSemaphore.RowHeadersVisible = false;
        }

        void SSCO()
        {
            DirectoryInfo directoryInfo = new DirectoryInfo(_pathSSCO);
            FileInfo[] archivos = directoryInfo.GetFiles("*.xml");
            FileInfo[] array = archivos;

            string _Date = string.Empty;
            string _Operator = string.Empty;
            string _Tracer = string.Empty;
            string _ClassMC = string.Empty;
            string _Slot = string.Empty;
            string _IpAdress = string.Empty;
            string _Status = string.Empty;
            string _Color = string.Empty;
            string _Progress = string.Empty;
            string[] _temp = { "" };

            if (0 < array.Length)
            {
                System.Threading.Thread.Sleep(100);
                _ds = new DataSet();
                _dt = new DataTable();
                _ds.ReadXml(archivos[0].FullName);
                _dt = _ds.Tables[0];

                var item = _dt.Rows[0]["DATE"];
                _Date = item.ToString();
                item = _dt.Rows[0]["OPERATOR"];
                _Operator = item.ToString().Trim();
                item = _dt.Rows[0]["TRACER"];
                _Tracer = item.ToString().Trim();
                item = _dt.Rows[0]["CLASSMC"];
                _ClassMC = item.ToString().Trim();
                item = _dt.Rows[0]["SLOT"];
                _Slot = item.ToString().Trim();
                item = _dt.Rows[0]["IPADRESS"];
                _IpAdress = item.ToString().Trim();
                item = _dt.Rows[0]["STATUS"];
                _Status = item.ToString().Trim();
                item = _dt.Rows[0]["COLOR"];
                _Color = item.ToString().Trim();
                item = _dt.Rows[0]["PROGRESS"];
                _Progress = item.ToString().Trim();

                _temp = iFactoryInfo.GetSCMC(_Tracer);
                _ClassMC = _temp[1] + "MC" + _temp[2];

                _ds = _db.SemaphoreStatus(_Slot, _Date, _Operator, _Tracer, _ClassMC, _Status, _Color, _Progress);

                WriteDGV_Sem(DateTime.Now.ToString(), _Tracer, _Slot, _IpAdress, _Status,_Progress);
                archivos[0].MoveTo(_pathSSCOProcessed + DateTime.Now.Year + "-" + DateTime.Now.Month + "-" + DateTime.Now.Hour + "-" + DateTime.Now.Minute + "-" + DateTime.Now.Second + "-" + archivos[0].Name);
            }
        }

        void WriteDGV_Sem(string _date, string _tracer, string _slot, string _ipAdress, string _status, string _progress)
        {
            dgvSemaphore.Rows.Add(new Object[]
                             {
                                  _date, _tracer, _slot, _ipAdress, _status, _progress
                             });
            dgvSemaphore.Rows[dgvSemaphore.Rows.Count - 1].DefaultCellStyle.BackColor = Color.White;
            dgvSemaphore.CurrentCell = dgvSemaphore.Rows[dgvSemaphore.Rows.Count - 1].Cells[0];
            this.Update();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                SSCO();
            }

            catch(Exception ex)
            {

            }
            
        }


    }

}
