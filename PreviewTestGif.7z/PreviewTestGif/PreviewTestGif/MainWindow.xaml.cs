﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace PreviewTestGif
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        string[] _InputArgs;

        public MainWindow(string[] InputArgs)
        {
            InitializeComponent();
            _InputArgs = InputArgs;
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {


            MediaElement.Source = new Uri(_InputArgs[0]);
            MediaElement.Play();
            lblTestTitle.Content = _InputArgs[1];
            List<string> _list = new List<string>();
                      
            int length = _InputArgs.Length;

            length = length - 1;

            for(int i = 0; i <= length; i++)
            {
                if(i >= 2) _list.Add(_InputArgs[i]);
            }

            string Instruction = string.Join(" ", _list.ToArray());

            lblTestInstruction.Content = new TextBlock() { Text = Instruction, TextWrapping = TextWrapping.Wrap };
            //lblTestInstruction.Content = Instruction.ToUpper();
        }

        private void BtnOk_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void MediaElement_MediaEnded(object sender, RoutedEventArgs e)
        {
            MediaElement.Position = new TimeSpan(0, 0, 1);
            MediaElement.Play();
        }

        private void MediaElement_MouseWheel(object sender, MouseWheelEventArgs e)
        {

        }

        private void MediaElement_MouseLeave(object sender, MouseEventArgs e)
        {

        }
    }
}
